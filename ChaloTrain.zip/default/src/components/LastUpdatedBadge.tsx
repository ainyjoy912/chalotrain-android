import { Clock } from 'lucide-react';

interface LastUpdatedBadgeProps {
  /** ISO date string or human-readable label, e.g. "2 min ago" or new Date().toISOString() */
  label?: string;
  /** If true, shows a green pulsing dot to indicate live data */
  live?: boolean;
}

export default function LastUpdatedBadge({ label, live = false }: LastUpdatedBadgeProps) {
  const displayLabel = label ?? 'Data refreshed in real-time';

  return (
    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs text-slate-500">
      {live ? (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
        </span>
      ) : (
        <Clock size={11} className="text-slate-400" />
      )}
      <span>{displayLabel}</span>
    </div>
  );
}
