import { type LucideIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface PageHeroProps {
  icon: LucideIcon;
  title: string;
  subtitle: string;
  badge?: string;
  breadcrumb?: { label: string; href: string }[];
  accentColor?: 'blue' | 'sky' | 'indigo' | 'violet' | 'cyan' | 'orange';
}

const accentMap = {
  blue:   { glow: 'bg-blue-400/12',   icon: 'bg-white/15 border-white/20' },
  sky:    { glow: 'bg-sky-400/12',    icon: 'bg-white/15 border-white/20' },
  indigo: { glow: 'bg-indigo-400/12', icon: 'bg-white/15 border-white/20' },
  violet: { glow: 'bg-violet-400/12', icon: 'bg-white/15 border-white/20' },
  cyan:   { glow: 'bg-cyan-400/12',   icon: 'bg-white/15 border-white/20' },
  orange: { glow: 'bg-orange-400/12', icon: 'bg-white/15 border-white/20' },
};

export default function PageHero({ icon: Icon, title, subtitle, badge, breadcrumb, accentColor = 'blue' }: PageHeroProps) {
  const accent = accentMap[accentColor];

  return (
    <section className="relative overflow-hidden hero-gradient text-white py-10 md:py-14">
      {/* Dot pattern */}
      <div className="absolute inset-0 dot-pattern" />
      {/* Radial glow */}
      <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[250px] ${accent.glow} rounded-full blur-[60px] pointer-events-none`} />

      <div className="relative container mx-auto px-4 text-center">
        {/* Breadcrumb */}
        {breadcrumb && breadcrumb.length > 0 && (
          <nav aria-label="Breadcrumb" className="flex items-center justify-center gap-1.5 text-blue-300/70 text-xs mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            {breadcrumb.map((crumb) => (
              <span key={crumb.href} className="flex items-center gap-1.5">
                <ChevronRight size={11} />
                {crumb.href === '#' ? (
                  <span className="text-white/80">{crumb.label}</span>
                ) : (
                  <Link to={crumb.href} className="hover:text-white transition-colors">{crumb.label}</Link>
                )}
              </span>
            ))}
          </nav>
        )}

        {badge && (
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-xs font-semibold mb-4 backdrop-blur-sm text-white/90">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            {badge}
          </div>
        )}

        <div className={`w-14 h-14 rounded-2xl ${accent.icon} border flex items-center justify-center mx-auto mb-4 shadow-[0_0_24px_hsl(0_0%_100%/0.10)]`}>
          <Icon size={26} className="text-white" />
        </div>

        <h1 className="text-3xl md:text-4xl font-bold mb-2.5 tracking-tight">
          {title}
        </h1>
        <p className="text-blue-200/85 text-base md:text-lg max-w-lg mx-auto leading-relaxed">{subtitle}</p>
      </div>

      {/* Wave */}
      <div className="relative h-10 overflow-hidden mt-8">
        <svg viewBox="0 0 1440 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="absolute bottom-0 w-full" preserveAspectRatio="none">
          <path d="M0 40L60 33C120 27 240 13 360 10C480 7 600 13 720 17C840 20 960 20 1080 17C1200 13 1320 7 1380 3L1440 0V40H0Z" fill="#f5f7ff" />
        </svg>
      </div>
    </section>
  );
}
