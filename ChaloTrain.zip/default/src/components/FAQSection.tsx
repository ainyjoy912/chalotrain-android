/**
 * FAQSection — Accordion FAQ for SEO. Each tool page passes its own FAQ items.
 */
import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface FAQItem {
  question: string;
  answer: string;
}

interface FAQSectionProps {
  items: FAQItem[];
  className?: string;
}

export default function FAQSection({ items, className = '' }: FAQSectionProps) {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className={`bg-white rounded-2xl border border-blue-100/60 overflow-hidden shadow-[0_2px_12px_hsl(221_79%_48%/0.06)] ${className}`}>
      <div className="px-5 py-4 border-b border-blue-50 bg-gradient-to-r from-blue-50/60 to-indigo-50/40">
        <h2 className="font-bold text-slate-800" style={{ fontFamily: 'var(--font-heading)' }}>
          Frequently Asked Questions
        </h2>
      </div>
      <div className="divide-y divide-slate-50">
        {items.map((item, idx) => (
          <div key={idx}>
            <button
              onClick={() => setOpen(open === idx ? null : idx)}
              className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left hover:bg-blue-50/30 transition-colors"
              aria-expanded={open === idx}
            >
              <span className="text-sm font-semibold text-slate-800 leading-snug">{item.question}</span>
              <ChevronDown
                size={15}
                className={`text-slate-400 shrink-0 transition-transform duration-200 ${open === idx ? 'rotate-180 text-primary' : ''}`}
              />
            </button>
            <AnimatePresence initial={false}>
              {open === idx && (
                <motion.div
                  key="answer"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2, ease: 'easeOut' as const }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-4 text-sm text-slate-600 leading-relaxed border-t border-slate-50 pt-3">{item.answer}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}
