/**
 * AdBanner — Placeholder ad slot component.
 * Replace the inner content with your actual AdSense <ins> tag once approved.
 *
 * Usage:
 *   <AdBanner slot="homepage-hero" size="leaderboard" />
 *   <AdBanner slot="results-mid" size="rectangle" label="Advertisement" />
 */

interface AdBannerProps {
  /** Unique identifier for this ad placement (used as data-ad-slot reference) */
  slot: string;
  /** Visual size variant */
  size?: 'leaderboard' | 'rectangle' | 'banner' | 'square';
  /** Optional label shown above the ad */
  label?: string;
  className?: string;
}

const sizeClasses: Record<NonNullable<AdBannerProps['size']>, string> = {
  leaderboard: 'w-full h-[90px] max-w-[728px]',   // 728×90
  rectangle:   'w-full h-[250px] max-w-[336px]',   // 336×280
  banner:      'w-full h-[60px]',                   // full-width banner
  square:      'w-[250px] h-[250px]',               // 250×250
};

export default function AdBanner({
  slot,
  size = 'leaderboard',
  label = 'Advertisement',
  className = '',
}: AdBannerProps) {
  return (
    <div
      className={`flex flex-col items-center justify-center ${className}`}
      data-ad-slot={slot}
      aria-label="Advertisement"
    >
      {label && (
        <p className="text-[10px] font-medium text-slate-400 uppercase tracking-widest mb-1 select-none">
          {label}
        </p>
      )}
      {/* ── Replace this div with your AdSense <ins> tag ── */}
      <div
        className={`${sizeClasses[size]} mx-auto flex items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-100 text-slate-400 text-xs font-medium select-none`}
      >
        Ad Slot · {slot}
      </div>
    </div>
  );
}
