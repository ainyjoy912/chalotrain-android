/**
 * RelatedTools — Internal linking grid shown on every tool page.
 * Pass `currentHref` to exclude the current page from the list.
 */
import { Link } from 'react-router-dom';
import { Ticket, Train, ArrowLeftRight, Armchair, Clock, IndianRupee, ChevronRight } from 'lucide-react';

const ALL_TOOLS = [
  { icon: Ticket,         title: 'PNR Status',            desc: 'Check CNF / RAC / WL status.',  href: '/pnr-status',        color: 'bg-blue-50 text-blue-600'    },
  { icon: Train,          title: 'Live Train Status',      desc: 'Real-time train tracking.',     href: '/live-status',       color: 'bg-indigo-50 text-indigo-600'},
  { icon: ArrowLeftRight, title: 'Train Between Stations', desc: 'Find trains on your route.',    href: '/train-search',      color: 'bg-sky-50 text-sky-600'      },
  { icon: Armchair,       title: 'Seat Availability',      desc: 'Check availability by class.',  href: '/seat-availability', color: 'bg-violet-50 text-violet-600'},
  { icon: Clock,          title: 'Train Schedule',         desc: 'Full timetable & all stops.',   href: '/train-schedule',    color: 'bg-cyan-50 text-cyan-600'    },
  { icon: IndianRupee,    title: 'Fare Inquiry',           desc: 'Compare fares & quotas.',       href: '/fare-inquiry',      color: 'bg-orange-50 text-orange-600'},
];

interface RelatedToolsProps {
  currentHref: string;
  className?: string;
}

export default function RelatedTools({ currentHref, className = '' }: RelatedToolsProps) {
  const tools = ALL_TOOLS.filter((t) => t.href !== currentHref);

  return (
    <div className={`bg-white rounded-2xl border border-blue-100/60 overflow-hidden shadow-[0_2px_12px_hsl(221_79%_48%/0.06)] ${className}`}>
      <div className="px-5 py-3.5 border-b border-blue-50 bg-gradient-to-r from-blue-50/60 to-indigo-50/40">
        <h3 className="font-bold text-slate-800 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
          More Railway Tools
        </h3>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 divide-y divide-slate-50">
        {tools.map(({ icon: Icon, title, desc, href, color }) => (
          <Link
            key={href}
            to={href}
            className="flex items-center gap-3 px-5 py-3.5 hover:bg-blue-50/40 transition-colors group border-b border-slate-50 last:border-b-0"
          >
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${color}`}>
              <Icon size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-slate-800 group-hover:text-primary transition-colors leading-tight truncate">
                {title}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 truncate">{desc}</div>
            </div>
            <ChevronRight size={14} className="text-slate-300 group-hover:text-primary transition-all group-hover:translate-x-0.5 shrink-0" />
          </Link>
        ))}
      </div>
    </div>
  );
}
