interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md' | 'lg';
}

export function getStatusColor(status: string): string {
  const s = status.toUpperCase();
  if (s === 'CNF' || s === 'CONFIRMED' || s === 'AVAILABLE' || s === 'ON TIME') {
    return 'bg-green-100 text-green-700 border-green-200';
  }
  if (s === 'RAC') {
    return 'bg-yellow-100 text-yellow-700 border-yellow-200';
  }
  if (s.startsWith('WL') || s === 'WAITLIST' || s === 'DELAYED') {
    return 'bg-red-100 text-red-700 border-red-200';
  }
  if (s === 'DEPARTED' || s === 'ARRIVED') {
    return 'bg-blue-100 text-blue-700 border-blue-200';
  }
  return 'bg-slate-100 text-slate-600 border-slate-200';
}

export default function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const sizeClass = size === 'sm' ? 'text-xs px-2 py-0.5' : size === 'lg' ? 'text-base px-4 py-1.5 font-bold' : 'text-sm px-3 py-1';
  return (
    <span
      className={`inline-flex items-center rounded-full border font-semibold ${sizeClass} ${getStatusColor(status)}`}
    >
      {status}
    </span>
  );
}
