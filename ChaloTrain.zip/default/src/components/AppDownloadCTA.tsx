import { MessageCircle, Send } from 'lucide-react';

interface AppDownloadCTAProps {
  variant?: 'banner' | 'inline';
}

export default function AppDownloadCTA({ variant = 'banner' }: AppDownloadCTAProps) {
  if (variant === 'inline') {
    return (
      <div className="flex flex-wrap items-center gap-3">
        <a
          href="https://wa.me/919170477270?text=Hi%20I%20need%20help%20with%20train%20info"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#25D366] text-white text-sm font-semibold hover:opacity-90 transition-opacity"
        >
          <MessageCircle size={16} />
          WhatsApp Us
        </a>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-gradient-to-br from-primary to-blue-800 text-white p-6 md:p-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Send size={20} className="text-orange-300" />
            <h3 className="text-lg font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
              Stay Updated on the Go
            </h3>
          </div>
          <p className="text-blue-100 text-sm leading-relaxed max-w-md">
            Get instant train alerts, PNR updates, and travel tips directly on WhatsApp. No app download needed.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 shrink-0">
          <a
            href="https://wa.me/919170477270?text=Hi%20I%20need%20help%20with%20train%20info"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#25D366] text-white text-sm font-bold hover:opacity-90 transition-opacity shadow-md"
          >
            <MessageCircle size={18} />
            WhatsApp Us
          </a>
        </div>
      </div>
    </div>
  );
}
