import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  message?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function LoadingSpinner({ message = 'Loading...', size = 'md' }: LoadingSpinnerProps) {
  const sizeClasses = { sm: 'w-5 h-5', md: 'w-8 h-8', lg: 'w-12 h-12' };

  return (
    <div className="flex flex-col items-center justify-center py-14">
      <div className="relative">
        <div className={`${sizeClasses[size]} rounded-full border-2 border-blue-100`} />
        <Loader2 className={`${sizeClasses[size]} text-primary animate-spin absolute inset-0`} />
      </div>
      <p className="text-sm text-slate-500 mt-4 font-medium">{message}</p>
    </div>
  );
}
