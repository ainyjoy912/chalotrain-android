/**
 * FAQSchemaLD — injects FAQ JSON-LD structured data into <head>
 * Drop this anywhere in a page component alongside your FAQSection.
 * Google uses this for rich results (FAQ dropdowns in SERPs).
 */

export interface FAQSchemaItem {
  question: string;
  answer: string;
}

interface FAQSchemaLDProps {
  items: FAQSchemaItem[];
}

export default function FAQSchemaLD({ items }: FAQSchemaLDProps) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}
