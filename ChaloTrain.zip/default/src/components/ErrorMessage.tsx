import { AlertCircle, RefreshCw, Clock } from 'lucide-react';

interface ErrorMessageProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  showHelpText?: boolean;
}

export default function ErrorMessage({
  title = 'Unable to fetch data',
  message,
  onRetry,
  showHelpText = true,
}: ErrorMessageProps) {
  const isTemporary = message.toLowerCase().includes('temporarily') ||
                      message.toLowerCase().includes('try again later') ||
                      message.toLowerCase().includes('high traffic');

  return (
    <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center shadow-[0_4px_16px_hsl(38_92%_50%/0.10)]">
      <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center mx-auto mb-3">
        {isTemporary ? <Clock size={22} className="text-amber-600" /> : <AlertCircle size={22} className="text-amber-600" />}
      </div>
      <h3 className="text-base font-bold text-amber-900 mb-1">{title}</h3>
      <p className="text-sm text-amber-700 leading-relaxed mb-3">{message}</p>

      {showHelpText && isTemporary && (
        <p className="text-xs text-amber-600 mb-4 leading-relaxed">
          Our service is experiencing high demand. Your request will work once traffic reduces.
        </p>
      )}

      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 px-4 py-2 bg-amber-600 text-white text-sm font-semibold rounded-xl hover:bg-amber-700 transition-all hover:-translate-y-0.5 shadow-sm"
        >
          <RefreshCw size={14} />
          Try Again
        </button>
      )}
    </div>
  );
}
