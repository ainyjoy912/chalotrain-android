import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Clock, Train as TrainIcon, ArrowLeftRight } from 'lucide-react';
import PageHero from '@/components/PageHero';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection, { type FAQItem } from '@/components/FAQSection';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorMessage from '@/components/ErrorMessage';
import EmptyState from '@/components/EmptyState';
import { getTrainsByStation, validateStationCode, type TrainsByStationResponse } from '@/lib/api-client';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
};

const FAQ_ITEMS: FAQItem[] = [
  { question: 'How do I find trains between two stations?', answer: 'Simply enter your source (starting) station and destination station in the search form. You can also select a specific date and quota (General, Tatkal, etc.). Click "Search Trains" to see all available trains on that route with timings, duration, and availability.' },
  { question: 'What is the difference between General and Tatkal quota?', answer: 'General quota is the regular booking quota available up to 120 days in advance. Tatkal quota opens 1 day before departure (10 AM for AC classes, 11 AM for non-AC) and has limited seats at higher fares. Premium Tatkal has dynamic pricing.' },
  { question: 'Can I see seat availability for all classes?', answer: 'Yes! Each train result shows availability across all classes (1A, 2A, 3A, SL, 2S, CC, EC). Green indicates available seats, yellow shows RAC/Waitlist, and red means fully booked. Click on any train for detailed class-wise availability.' },
  { question: 'What do the train types mean (Rajdhani, Shatabdi, etc.)?', answer: 'Rajdhani trains are premium long-distance trains connecting state capitals to Delhi. Shatabdi trains are high-speed day trains. Duronto are non-stop long-distance trains. Express trains have fewer stops than Passenger trains. Each type has different fare structures and amenities.' },
  { question: 'Why are some trains not showing for my route?', answer: 'Trains may not appear if they don\'t run on the selected date (some trains run specific days only), if they\'re temporarily cancelled, or if the route doesn\'t have direct trains. Try checking alternate dates or nearby stations.' },
];

export default function TrainSearchPage() {
  const [station, setStation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TrainsByStationResponse | null>(null);
  const [validationError, setValidationError] = useState<{ station?: string }>({});

  const doSearch = async (code: string) => {
    setError(null);
    setValidationError({});
    setResult(null);

    const v = validateStationCode(code.trim());
    if (!v.valid) {
      setValidationError({ station: v.error });
      return;
    }

    setLoading(true);
    try {
      const data = await getTrainsByStation(code.trim().toUpperCase());
      setResult(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : '';
      if (msg.includes('Too many requests') || msg.includes('Rate limit') || msg.includes('429')) {
        setError('Train Search service temporarily unavailable due to high traffic. Please try again in a few minutes.');
      } else if (msg.includes('Network error') || msg.includes('Could not reach')) {
        setError('Unable to connect to railway data service. Please check your internet connection and try again.');
      } else if (msg.includes('not yet configured') || msg.includes('not configured')) {
        setError('Train Search service is currently being set up. Please try again shortly.');
      } else if (msg.includes('No trains found') || msg.includes('not found')) {
        setError('No trains found for this station code. Please verify the station code and try again.');
      } else {
        setError('Train Search service temporarily unavailable. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    doSearch(station);
  };

  const handleRetry = () => {
    setError(null);
    doSearch(station);
  };

  return (
    <>
      <Helmet>
        <title>Train Between Stations — Find Trains & Check Seat Availability | ChaloTrain</title>
        <meta name="description" content="Find all trains between any two stations in India. Compare timings, journey duration, fares, and seat availability across all classes and quotas." />
        <meta name="keywords" content="train between stations, trains from Delhi to Mumbai, find trains, train search, IRCTC train search, Indian Railways trains, seat availability" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Train Between Stations — Find Trains & Check Seat Availability | ChaloTrain" />
        <meta property="og:description" content="Find all trains between any two stations in India. Compare timings, fares, and seat availability across all classes and quotas." />
        <meta property="og:url" content="https://chalotrain.com/train-search" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Train Between Stations — Find Trains & Check Seat Availability | ChaloTrain" />
        <meta name="twitter:description" content="Find all trains between any two stations in India. Compare timings, fares, and seat availability." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/train-search" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'Train Between Stations Search — ChaloTrain',
          url: 'https://chalotrain.com/train-search',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'All',
          description: 'Find all trains between any two Indian Railway stations with seat availability and fare comparison.',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
          provider: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'Train Between Stations', item: 'https://chalotrain.com/train-search' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        title="Train Between Stations"
        subtitle="Find trains connecting any two stations with live availability"
        icon={ArrowLeftRight}
        badge="Compare & Book"
      />
      {/* Visually-hidden h1 for SEO — PageHero renders the visible heading */}
      <h1 className="sr-only">Train Between Stations — Find Trains at Any Indian Railway Station</h1>

      <section className="py-10 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-blue-100/60 p-6 mb-6 shadow-[0_2px_12px_hsl(221_79%_48%/0.06)]">
            <h2 className="text-xl font-bold text-slate-900 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              Find Trains Between Any Two Stations in India
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Planning a train journey? ChaloTrain's Train Between Stations tool helps you discover all available trains connecting your source and destination. Whether you're traveling for business, vacation, or visiting family, find the perfect train with complete schedule, fare, and availability information.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Our comprehensive search covers all Indian Railways routes and train types — from premium Rajdhani and Shatabdi Express to regular Mail/Express and Passenger trains. Compare departure times, journey duration, available classes, and seat availability across multiple trains to choose the best option for your travel needs.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>How to use:</strong> Enter your starting station (source) and destination station. Select your journey date and preferred quota (General, Tatkal, Ladies, etc.). Click "Search Trains" to see all trains on that route with availability, timings, and fare details. You can filter by train type, class, and departure time to find your ideal train.
            </p>
          </motion.div>

          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <form onSubmit={handleSearch} className="bg-white rounded-2xl border border-blue-100/60 p-6 shadow-[0_4px_20px_hsl(221_79%_48%/0.08)]">
              <div className="mb-4">
                <label htmlFor="station-code-input" className="block text-sm font-semibold text-slate-700 mb-2">Station Code</label>
                <input
                  id="station-code-input"
                  type="text"
                  value={station}
                  onChange={(e) => {
                    setStation(e.target.value.toUpperCase());
                    setValidationError({});
                  }}
                  placeholder="e.g., NDLS, KNP, HWH"
                  maxLength={7}
                  autoComplete="off"
                  className={`w-full px-4 py-3 border rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm uppercase min-h-[44px] ${
                    validationError.station ? 'border-red-300 bg-red-50' : 'border-slate-200'
                  }`}
                />
                {validationError.station && <p className="text-xs text-red-600 mt-1" role="alert">{validationError.station}</p>}
                <p className="text-xs text-slate-400 mt-1">Enter the station code to see all trains passing through it.</p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
              >
                <Search size={16} aria-hidden="true" />
                Search Trains
              </button>
            </form>
          </motion.div>

          <AnimatePresence mode="wait">
            {loading && (
              <motion.div key="loading" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <LoadingSpinner message="Searching trains..." />
              </motion.div>
            )}

            {error && !loading && (
              <motion.div key="error" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <ErrorMessage title="Unable to Search Trains" message={error} onRetry={handleRetry} />
              </motion.div>
            )}

            {result && !loading && !error && (
              <motion.div key="results" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6 space-y-4">
                {result.data.length === 0 ? (
                  <EmptyState
                    icon={<TrainIcon size={32} />}
                    title="No Trains Found"
                    message={`No trains found at station ${result.stationCode}. Please verify the station code and try again.`}
                    action={{ label: 'Search Again', onClick: () => setResult(null) }}
                  />
                ) : (
                  <>
                    <div className="bg-white rounded-xl border border-blue-100/60 p-4">
                      <p className="text-sm text-slate-600">
                        Found <strong className="text-slate-900">{result.data.length} trains</strong> at station{' '}
                        <strong className="text-primary">{result.stationCode}</strong>
                      </p>
                    </div>

                    {result.data.map((train, index) => (
                      <motion.div
                        key={`${train.trainNumber}-${index}`}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.04 }}
                        className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="text-base font-bold text-slate-900">{train.trainName}</h3>
                            <p className="text-sm text-slate-500">#{train.trainNumber}{train.trainType ? ` • ${train.trainType}` : ''}</p>
                          </div>
                          {train.trainType && (
                            <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">
                              {train.trainType}
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-3 gap-3">
                          {train.arrivalTime && (
                            <div>
                              <p className="text-xs text-slate-400 mb-1">Arrival</p>
                              <p className="text-base font-bold text-slate-900">{train.arrivalTime}</p>
                            </div>
                          )}
                          {train.departureTime && (
                            <div>
                              <p className="text-xs text-slate-400 mb-1">Departure</p>
                              <p className="text-base font-bold text-slate-900">{train.departureTime}</p>
                            </div>
                          )}
                          {train.haltTime && (
                            <div>
                              <p className="text-xs text-slate-400 mb-1">Halt</p>
                              <div className="flex items-center gap-1">
                                <Clock size={13} className="text-slate-400" />
                                <p className="text-sm font-semibold text-slate-700">{train.haltTime}</p>
                              </div>
                            </div>
                          )}
                        </div>

                        {(train.source || train.destination) && (
                          <div className="mt-3 pt-3 border-t border-slate-100 flex gap-4 text-xs text-slate-500">
                            {train.source && <span>From: <strong className="text-slate-700">{train.source}</strong></span>}
                            {train.destination && <span>To: <strong className="text-slate-700">{train.destination}</strong></span>}
                            {train.distance != null && <span>Distance: <strong className="text-slate-700">{train.distance} km</strong></span>}
                          </div>
                        )}
                      </motion.div>
                    ))}
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <RelatedTools currentHref="/train-search" />
          </motion.div>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <SocialShareBar
              title="Find trains between stations on ChaloTrain — Compare timings & availability"
              url="https://chalotrain.com/train-search"
            />
          </motion.div>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <FAQSection items={FAQ_ITEMS} />
          </motion.div>

          {/* Learn more */}
          <div className="container mx-auto px-4 pb-2 mt-3">
            <div className="max-w-2xl mx-auto">
              <p className="text-sm text-slate-500">
                Want to learn more?{' '}
                <Link to="/blog/best-trains-delhi-to-mumbai" className="text-primary hover:underline font-medium">
                  Read our complete guide →
                </Link>
              </p>
            </div>
          </div>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> This website is not affiliated with IRCTC or Indian Railways and provides railway information for general purposes only. Please verify critical information from official sources.
              </p>
            </div>
          </motion.div>

        </div>
      </section>
    </>
  );
}
