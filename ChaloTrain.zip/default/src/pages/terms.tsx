import { motion } from 'motion/react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { FileText, MapPin } from 'lucide-react';
import PageHero from '@/components/PageHero';
import { Link } from 'react-router-dom';

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="mb-8">
    <h2
      className="text-lg font-bold text-slate-900 mb-3 pb-2 border-b border-slate-200"
      style={{ fontFamily: 'var(--font-heading)' }}
    >
      {title}
    </h2>
    <div className="text-sm text-slate-600 leading-relaxed space-y-3">{children}</div>
  </div>
);

export default function TermsPage() {
  return (
    <>
      <Helmet>
        <title>Terms of Service — ChaloTrain</title>
        <meta name="description" content="Read ChaloTrain's Terms of Service. Understand the rules and conditions for using our railway information platform operated by ChaloTrain Technologies Private Limited." />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Terms of Service — ChaloTrain" />
        <meta property="og:description" content="Read ChaloTrain's Terms of Service. Understand the rules and conditions for using our railway information platform." />
        <meta property="og:url" content="https://chalotrain.com/terms" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Terms of Service — ChaloTrain" />
        <meta name="twitter:description" content="Read ChaloTrain's Terms of Service. Understand the rules and conditions for using our railway information platform." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/terms" />
      </Helmet>

      <PageHero
        icon={FileText}
        title="Terms of Service"
        subtitle="Please read these terms carefully before using ChaloTrain."
        badge="Last updated: May 2026"
      />

      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-10"
          >

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-8 text-sm text-amber-800">
              By accessing or using ChaloTrain (chalotrain.com), you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please discontinue use of the website immediately.
            </div>

            <Section title="1. Acceptance of Terms">
              <p>These Terms of Service ("Terms") constitute a legally binding agreement between you ("User") and <strong>ChaloTrain Technologies Private Limited</strong> ("ChaloTrain", "we", "us", or "our"), governing your access to and use of the ChaloTrain website at <strong>chalotrain.com</strong> and all associated services.</p>
              <p>By accessing or using our platform, you confirm that you are at least 18 years of age (or have obtained parental or guardian consent if you are a minor), and that you agree to comply with and be bound by these Terms and all applicable laws and regulations.</p>
            </Section>

            <Section title="2. Description of Service">
              <p>ChaloTrain provides an independent railway information service including but not limited to:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>PNR status checking and passenger information</li>
                <li>Live train running status and real-time tracking</li>
                <li>Train search between stations</li>
                <li>Seat availability information across classes and quotas</li>
                <li>Train schedules, timetables, and halt information</li>
                <li>Fare inquiry and comparison across classes</li>
                <li>Railway guides, articles, and informational content</li>
              </ul>
              <p>ChaloTrain is an <strong>information-only</strong> platform. We do not sell railway tickets, process bookings, or handle any financial transactions related to railway travel.</p>
            </Section>

            <Section title="3. Accuracy of Information">
              <p>While we strive to provide accurate and up-to-date information, <strong>ChaloTrain does not guarantee</strong> the completeness, accuracy, reliability, or timeliness of any data displayed on the platform. All railway data — including PNR status, train schedules, live running status, seat availability, and fare information — is sourced from third-party APIs and publicly available Indian Railways data feeds.</p>
              <p>Railway schedules, fares, seat availability, and operational details are subject to change by Indian Railways and IRCTC at any time without prior notice. Users should verify all critical information directly with <strong>IRCTC</strong> or <strong>Indian Railways</strong> before making any travel decisions, bookings, or financial commitments.</p>
            </Section>

            <Section title="4. No Ticket Booking or Financial Transactions">
              <p>ChaloTrain does not facilitate, process, or handle railway ticket bookings or any financial transactions. We are strictly an information aggregation and display service. For ticket booking, cancellation, or any financial transaction related to railway travel, please use the official <a href="https://www.irctc.co.in" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRCTC website</a> or authorized travel agents.</p>
            </Section>

            <Section title="5. Intellectual Property">
              <p>All original content on ChaloTrain — including but not limited to text, graphics, logos, icons, user interface design, software code, and blog articles — is the intellectual property of ChaloTrain Technologies Private Limited and is protected under applicable Indian and international intellectual property laws.</p>
              <p>You may not reproduce, distribute, modify, create derivative works from, publicly display, or commercially exploit any content from ChaloTrain without our prior written consent. Railway data displayed on this platform is sourced from third-party providers and remains the property of their respective owners.</p>
            </Section>

            <Section title="6. Prohibited Use">
              <p>You agree not to use ChaloTrain for any of the following:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Any unlawful purpose or in violation of any applicable laws or regulations</li>
                <li>Scraping, crawling, or systematically extracting data from the website using automated tools without prior written permission</li>
                <li>Attempting to gain unauthorized access to any part of the platform, its servers, or associated systems</li>
                <li>Transmitting any harmful, offensive, defamatory, or disruptive content</li>
                <li>Impersonating ChaloTrain, its employees, or any other person or entity</li>
                <li>Interfering with or disrupting the integrity or performance of the platform</li>
                <li>Using the platform to build a competing service or product</li>
                <li>Reverse engineering or attempting to extract the source code of the platform</li>
              </ul>
            </Section>

            <Section title="7. Limitation of Liability">
              <p>To the fullest extent permitted by applicable law, ChaloTrain Technologies Private Limited, its directors, officers, employees, and agents shall not be liable for any direct, indirect, incidental, special, consequential, or punitive damages arising from:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Your use of or inability to use our services</li>
                <li>Inaccurate, outdated, or incomplete information displayed on the platform</li>
                <li>Any travel decisions, bookings, or financial commitments made based on information from this website</li>
                <li>Unauthorized access to or alteration of your data or transmissions</li>
                <li>Train delays, cancellations, or schedule changes by Indian Railways</li>
                <li>Temporary or permanent unavailability of the platform or any of its features</li>
                <li>Any other matter relating to our services</li>
              </ul>
              <p>Our total liability to you for any claim arising from these Terms or your use of the platform shall not exceed INR 1,000 (Indian Rupees One Thousand).</p>
            </Section>

            <Section title="8. Third-Party Services and Links">
              <p>ChaloTrain relies on third-party data providers and APIs to deliver railway information. We are not responsible for the availability, accuracy, or reliability of these third-party services. Temporary unavailability of our tools may occur due to third-party service disruptions.</p>
              <p>Our platform may also contain links to third-party websites for user convenience. We are not responsible for the content, privacy practices, or terms of those external sites. Accessing them is entirely at your own risk.</p>
            </Section>

            <Section title="9. Privacy">
              <p>Your use of ChaloTrain is also governed by our <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>, which is incorporated into these Terms by reference. Please review our Privacy Policy to understand our practices regarding the collection and use of your information.</p>
            </Section>

            <Section title="10. Modifications to Terms">
              <p>ChaloTrain Technologies Private Limited reserves the right to modify, update, or replace these Terms at any time at our sole discretion. Updated Terms will be posted on this page with a revised "Last updated" date. It is your responsibility to review these Terms periodically. Continued use of ChaloTrain after any changes constitutes your acceptance of the revised Terms.</p>
            </Section>

            <Section title="11. Termination">
              <p>We reserve the right to suspend or terminate your access to ChaloTrain at any time, without notice, for conduct that we believe violates these Terms or is harmful to other users, us, third parties, or the integrity of the platform.</p>
            </Section>

            <Section title="12. Governing Law and Jurisdiction">
              <p>These Terms shall be governed by and construed in accordance with the laws of India, without regard to its conflict of law provisions. Any disputes arising out of or relating to these Terms or your use of ChaloTrain shall be subject to the exclusive jurisdiction of the competent courts in <strong>Mumbai, Maharashtra, India</strong>.</p>
            </Section>

            <Section title="13. Legal Information">
              <p>ChaloTrain is operated by a registered Indian private limited company. Our statutory registration details are as follows:</p>
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 mt-2">
                <p className="text-xs font-bold text-slate-700 mb-3">ChaloTrain Technologies Private Limited</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { label: 'CIN', value: 'U62099UP2026PTC246981' },
                    { label: 'PAN', value: 'AANCC7761J' },
                    { label: 'TAN', value: 'KNPC02496E' },
                  ].map(({ label, value }) => (
                    <div key={label} className="bg-white rounded-lg border border-slate-200 px-3 py-2">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">{label}</p>
                      <p className="text-xs font-mono font-semibold text-slate-800 tracking-wide">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Section>

            <Section title="14. Contact & Registered Addresses">
              <p>For questions, concerns, or legal notices regarding these Terms of Service, please contact us:</p>
              <p><strong>Email:</strong> <a href="mailto:chalotrain@chalotrain.com" className="text-primary hover:underline">chalotrain@chalotrain.com</a></p>
              <p><strong>Phone:</strong> <a href="tel:+919170477270" className="text-primary hover:underline">+91 91704 77270</a></p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin size={14} className="text-primary flex-shrink-0" />
                    <p className="text-xs font-bold text-slate-700 uppercase tracking-wide">Registered Office</p>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ChaloTrain Technologies Private Limited<br />
                    C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                    Ragaul Tahsil, Hamirpur,<br />
                    Uttar Pradesh — 210507, India
                  </p>
                </div>
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin size={14} className="text-indigo-500 flex-shrink-0" />
                    <p className="text-xs font-bold text-slate-700 uppercase tracking-wide">Registered Office</p>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ChaloTrain Technologies Private Limited<br />
                    C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                    Ragaul Tahsil, Hamirpur,<br />
                    Uttar Pradesh — 210507, India
                  </p>
                </div>
              </div>
            </Section>

            <div className="pt-4 border-t border-slate-200 flex flex-wrap gap-4 text-sm">
              <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>
              <Link to="/disclaimer" className="text-primary hover:underline">Disclaimer</Link>
              <Link to="/contact" className="text-primary hover:underline">Contact Us</Link>
            </div>

          </motion.div>
        </div>
      </section>
    </>
  );
}
