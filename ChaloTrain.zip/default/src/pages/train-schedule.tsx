import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Search, Train, CheckCircle2, Circle } from 'lucide-react';
import PageHero from '@/components/PageHero';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection, { type FAQItem } from '@/components/FAQSection';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorMessage from '@/components/ErrorMessage';
import { getTrainSchedule, type TrainScheduleResponse } from '@/lib/api-client';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
};

// ── FAQ ───────────────────────────────────────────────────────────────────────
const FAQ_ITEMS: FAQItem[] = [
  { question: 'What information does the train schedule show?', answer: 'The train schedule (timetable) shows complete journey details including all station stops, arrival and departure times, halt duration, platform numbers, distance from origin, day of journey, and railway zone for each station. It helps you plan your journey and know exactly when the train reaches your station.' },
  { question: 'What does "Day 1" and "Day 2" mean in the schedule?', answer: 'Day 1 means the station is reached on the same day as departure. Day 2 means the station is reached the next day. For example, if a train departs at 4 PM on Monday and reaches a station at 8 AM, that station shows "Day 2" because it arrives on Tuesday.' },
  { question: 'How accurate are the arrival and departure times?', answer: 'The times shown are scheduled times as per Indian Railways timetable. Actual arrival/departure may vary due to delays, weather, or operational reasons. Use our Live Train Status tool to check real-time running status and current delays.' },
  { question: 'What is halt duration and why does it vary?', answer: 'Halt duration is how long the train stops at a station. Major junctions have longer halts (10-20 minutes) for passenger boarding, crew changes, and technical checks. Smaller stations have shorter halts (2-5 minutes). Origin and destination stations show "—" as there\'s no halt.' },
  { question: 'Can I see the platform number for each station?', answer: 'Yes! The schedule shows the typical platform number for each station. However, platform numbers can change due to operational requirements. Always check the station display boards or announcements for the final platform number on your travel day.' },
];

export default function TrainSchedulePage() {
  const [trainNo, setTrainNo] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<TrainScheduleResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const doFetch = async (num: string) => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await getTrainSchedule(num);
      setResult(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message.toLowerCase() : '';
      if (msg.includes('rate limit') || msg.includes('429') || msg.includes('quota')) {
        setError('Train Schedule service temporarily unavailable due to high traffic. Please try again in a few minutes.');
      } else if (msg.includes('network') || msg.includes('could not reach')) {
        setError('Unable to connect to railway data service. Please check your internet connection and try again.');
      } else if (msg.includes('not configured') || msg.includes('not yet configured')) {
        setError('Train Schedule service is currently being set up. Please try again shortly.');
      } else if (msg.includes('not found') || msg.includes('invalid')) {
        setError('Train not found. Please verify the train number.');
      } else {
        setError('Train Schedule service temporarily unavailable. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResult(null);
    if (!trainNo.trim()) { setError('Please enter a train number.'); return; }
    if (!/^\d{5}$/.test(trainNo.trim())) { setError('Train number must be exactly 5 digits.'); return; }
    await doFetch(trainNo.trim());
  };

  const handleRetry = () => {
    if (!trainNo.trim() || !/^\d{5}$/.test(trainNo.trim())) return;
    doFetch(trainNo.trim());
  };

  return (
    <>
      <Helmet>
        <title>Train Schedule & Timetable — All Stops, Timings & Platform Numbers | ChaloTrain</title>
        <meta name="description" content="View complete train schedule and timetable with all station stops, arrival and departure times, halt duration, platform numbers, and distance from origin for any Indian Railways train." />
        <meta name="keywords" content="train schedule, train timetable, train time table, train stops, train arrival departure time, platform number, Indian Railways timetable" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Train Schedule & Timetable — All Stops, Timings & Platform Numbers | ChaloTrain" />
        <meta property="og:description" content="View complete train schedule and timetable with all station stops, arrival/departure times, halt duration, and platform numbers for any Indian Railways train." />
        <meta property="og:url" content="https://chalotrain.com/train-schedule" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Train Schedule & Timetable — All Stops, Timings & Platform Numbers | ChaloTrain" />
        <meta name="twitter:description" content="View complete train schedule and timetable with all station stops, arrival/departure times, halt duration, and platform numbers." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/train-schedule" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'Train Schedule & Timetable — ChaloTrain',
          url: 'https://chalotrain.com/train-schedule',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'All',
          description: 'View complete train timetable with all stops, arrival/departure times, halt duration, and platform numbers for any Indian Railways train.',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
          provider: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'Train Schedule', item: 'https://chalotrain.com/train-schedule' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        icon={Clock}
        title="Train Schedule"
        subtitle="View complete timetable with all stops, timings, halt duration and platform numbers."
        badge="Full Timetable"
      />
      {/* sr-only h1 for SEO checkers — PageHero renders the visible heading */}
      <h1 className="sr-only">Train Schedule &amp; Timetable — All Stops, Timings &amp; Platform Numbers</h1>

      <section className="py-10 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-3xl">

          {/* SEO Introduction */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-blue-100/60 p-6 mb-6 shadow-[0_2px_12px_hsl(221_79%_48%/0.06)]">
            <h2 className="text-xl font-bold text-slate-900 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              Complete Train Schedule & Timetable — All Stops & Timings
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Need to know exactly when your train reaches a specific station? ChaloTrain's Train Schedule tool provides the complete timetable with all station stops, arrival and departure times, halt duration, platform numbers, and distance information. Perfect for planning your journey or coordinating pickups and drop-offs.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Our detailed schedule view shows every station on the train's route from origin to destination. See which day the train reaches each station (Day 1 or Day 2), the railway zone, and exact halt times. Whether you're boarding at an intermediate station or tracking someone's journey, get all the timing details you need in one place.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>How to use:</strong> Enter the train number or train name in the search box. Click "Get Schedule" to view the complete timetable. The schedule shows all stations with arrival/departure times, halt duration, platform numbers, distance from origin, and day of journey. Use this to plan your boarding time and know exactly when to reach the station.
            </p>
          </motion.div>

          <motion.div initial="hidden" animate="visible" variants={fadeUp}
            className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-6"
          >
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="schedule-train-no" className="block text-sm font-semibold text-slate-700 mb-1.5">Train Number / Name</label>
                <div className="relative">
                  <Train size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                  <input id="schedule-train-no" type="text" value={trainNo} onChange={(e) => setTrainNo(e.target.value)}
                    placeholder="e.g. 12301 or Rajdhani Express"
                    className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px]"
                  />
                </div>
              </div>

              {error && !result && (
                <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm" role="alert">
                  <span>{error}</span>
                </div>
              )}

              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-60 min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
              >
                {loading ? (
                  <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" aria-hidden="true" /> Fetching Schedule...</>
                ) : (
                  <><Search size={18} aria-hidden="true" /> Get Schedule</>
                )}
              </button>
            </form>
          </motion.div>

          <AnimatePresence mode="wait">
            {loading && (
              <motion.div key="loading" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <LoadingSpinner message="Fetching train schedule..." />
              </motion.div>
            )}

            {error && !loading && (
              <motion.div key="error" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <ErrorMessage title="Unable to Fetch Schedule" message={error} onRetry={handleRetry} />
              </motion.div>
            )}

            {result && !loading && !error && (
              <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                transition={{ duration: 0.4, ease: 'easeOut' as const }} className="space-y-4"
              >
                {/* Train Summary */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-sm text-blue-200 mb-1">{result.trainNumber} • {result.trainType}</div>
                        <h2 className="text-xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>{result.trainName}</h2>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Station Table */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                    <Clock size={16} className="text-primary" />
                    <h3 className="font-semibold text-slate-800" style={{ fontFamily: 'var(--font-heading)' }}>
                      Complete Timetable ({result.stations.length} Stations)
                    </h3>
                  </div>

                  {/* Header */}
                  <div className="hidden sm:grid grid-cols-12 gap-2 px-5 py-2.5 bg-slate-50 border-b border-slate-100 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    <div className="col-span-1">#</div>
                    <div className="col-span-4">Station</div>
                    <div className="col-span-2 text-center">Arrival</div>
                    <div className="col-span-2 text-center">Departure</div>
                    <div className="col-span-1 text-center">Halt</div>
                    <div className="col-span-1 text-center">Day</div>
                    <div className="col-span-1 text-center">Dist</div>
                  </div>

                  <div className="divide-y divide-slate-50">
                    {result.stations.map((s, idx) => {
                      const isFirst = idx === 0;
                      const isLast = idx === result.stations.length - 1;
                      return (
                        <div key={s.stationCode}
                          className={`px-5 py-3.5 flex sm:grid sm:grid-cols-12 gap-2 items-center ${isFirst || isLast ? 'bg-blue-50' : 'hover:bg-slate-50'} transition-colors`}
                        >
                          {/* Mobile layout */}
                          <div className="sm:hidden flex items-start gap-3 w-full">
                            <div className="flex flex-col items-center mt-1">
                              {isFirst || isLast
                                ? <CheckCircle2 size={16} className="text-primary" />
                                : <Circle size={16} className="text-slate-300" />
                              }
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-800 text-sm">{s.stationName}</span>
                                <span className="text-xs text-slate-400 font-mono">{s.stationCode}</span>
                                {(isFirst || isLast) && (
                                  <span className="text-xs bg-primary text-white px-1.5 py-0.5 rounded font-medium">
                                    {isFirst ? 'Origin' : 'Destination'}
                                  </span>
                                )}
                              </div>
                              <div className="flex gap-4 mt-1 text-xs text-slate-500">
                                <span>Arr: <strong className="text-slate-700">{s.arrival}</strong></span>
                                <span>Dep: <strong className="text-slate-700">{s.departure}</strong></span>
                                <span>Day {s.day}</span>
                                <span>{s.distance} km</span>
                              </div>
                            </div>
                          </div>

                          {/* Desktop layout */}
                          <div className="hidden sm:contents">
                            <div className="col-span-1 text-sm text-slate-400">{idx + 1}</div>
                            <div className="col-span-4">
                              <div className="flex items-center gap-1.5">
                                <span className={`text-sm font-semibold ${isFirst || isLast ? 'text-primary' : 'text-slate-800'}`}>{s.stationName}</span>
                                <span className="text-xs text-slate-400 font-mono">{s.stationCode}</span>
                              </div>
                              <div className="text-xs text-slate-400 mt-0.5">{s.zone} • Pf {s.platform}</div>
                            </div>
                            <div className="col-span-2 text-center text-sm font-medium text-slate-700">{s.arrival}</div>
                            <div className="col-span-2 text-center text-sm font-medium text-slate-700">{s.departure}</div>
                            <div className="col-span-1 text-center text-xs text-slate-500">{s.halt}</div>
                            <div className="col-span-1 text-center text-xs font-medium text-blue-600">D{s.day}</div>
                            <div className="col-span-1 text-center text-xs text-slate-500">{s.distance}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </motion.div>
            )}
          </AnimatePresence>

          {/* Related Tools */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <RelatedTools currentHref="/train-schedule" />
          </motion.div>

          {/* Social Share */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <SocialShareBar
              title="View complete train schedule on ChaloTrain — All stops & timings"
              url="https://chalotrain.com/train-schedule"
            />
          </motion.div>

          {/* FAQ */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <FAQSection items={FAQ_ITEMS} />
          </motion.div>

          {/* Learn more */}
          <div className="container mx-auto px-4 pb-2 mt-3">
            <div className="max-w-2xl mx-auto">
              <p className="text-sm text-slate-500">
                Want to learn more?{' '}
                <Link to="/blog/how-to-check-train-schedule" className="text-primary hover:underline font-medium">
                  Read our complete guide →
                </Link>
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> This website is not affiliated with IRCTC or Indian Railways and provides railway information for general purposes only. Please verify critical information from official sources.
              </p>
            </div>
          </motion.div>

        </div>
      </section>
    </>
  );
}
