import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { Train, Search, Clock, CheckCircle2, Circle } from 'lucide-react';
import PageHero from '@/components/PageHero';
import StatusBadge from '@/components/StatusBadge';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection, { type FAQItem } from '@/components/FAQSection';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorMessage from '@/components/ErrorMessage';
import { getLiveTrainStatus, validateTrainNumber, validateDate, type LiveTrainStatusResponse } from '@/lib/api-client';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
};

// ── FAQ ───────────────────────────────────────────────────────────────────────
const FAQ_ITEMS: FAQItem[] = [
  { question: 'How accurate is live train tracking?', answer: 'Live train status data is sourced from Indian Railways systems and updated as the train moves between stations. The data shows the train\'s current location, delays, and expected arrival times at upcoming stations. Accuracy may vary depending on network conditions and data availability.' },
  { question: 'Why is my train showing a delay?', answer: 'Train delays can occur due to various reasons including weather conditions, track maintenance, signal issues, or operational requirements. The live status shows the current delay and updates as the train progresses.' },
  { question: 'Can I track trains running on any route?', answer: 'You can track most passenger trains running on the Indian Railways network. Simply enter the train number and date of journey to get running status and station-wise updates.' },
  { question: 'What does "departed" and "arrived" mean?', answer: 'Departed means the train has left that station and is en route to the next stop. Arrived means the train has reached that station. The current position indicator shows which station the train is between or at.' },
  { question: 'How often is the live status updated?', answer: 'Train status is updated as the train arrives at or departs from a station. You can refresh the page to get the latest information. Updates between stations may be less frequent.' },
];

export default function LiveStatusPage() {
  const [trainNumber, setTrainNumber] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<LiveTrainStatusResponse | null>(null);
  const [validationError, setValidationError] = useState<{ train?: string; date?: string }>({});

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset states
    setError(null);
    setValidationError({});
    setResult(null);

    // Validate inputs
    const trainValidation = validateTrainNumber(trainNumber.trim());
    const dateValidation = validateDate(date);

    if (!trainValidation.valid || !dateValidation.valid) {
      setValidationError({
        train: trainValidation.error,
        date: dateValidation.error,
      });
      return;
    }

    // Call API
    setLoading(true);
    try {
      const data = await getLiveTrainStatus(trainNumber.trim(), date);
      setResult(data);
    } catch (err) {
      // User-friendly error messages
      const errorMessage = err instanceof Error ? err.message : '';
      
      if (errorMessage.includes('Too many requests') || errorMessage.includes('Rate limit') || errorMessage.includes('429')) {
        setError('Live Train Status service temporarily unavailable due to high traffic. Please try again in a few minutes.');
      } else if (errorMessage.includes('Network error') || errorMessage.includes('Could not reach')) {
        setError('Unable to connect to railway data service. Please check your internet connection and try again.');
      } else if (errorMessage.includes('not yet configured') || errorMessage.includes('not configured')) {
        setError('Live Train Status service is currently being set up. Please try again shortly.');
      } else if (errorMessage.includes('not found') || errorMessage.includes('Invalid')) {
        setError('Train not found or not running on this date. Please verify the train number and date.');
      } else {
        setError('Live Train Status service temporarily unavailable. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    setError(null);
    const trainValidation = validateTrainNumber(trainNumber.trim());
    const dateValidation = validateDate(date);
    if (!trainValidation.valid || !dateValidation.valid) return;
    setLoading(true);
    getLiveTrainStatus(trainNumber.trim(), date)
      .then((data) => setResult(data))
      .catch((err) => {
        const msg = err instanceof Error ? err.message.toLowerCase() : '';
        if (msg.includes('rate limit') || msg.includes('429') || msg.includes('quota')) {
          setError('Live Train Status service temporarily unavailable due to high traffic. Please try again in a few minutes.');
        } else if (msg.includes('network') || msg.includes('could not reach')) {
          setError('Unable to connect to railway data service. Please check your internet connection and try again.');
        } else if (msg.includes('not found') || msg.includes('invalid')) {
          setError('Train not found or not running on this date. Please verify the train number and date.');
        } else {
          setError('Live Train Status service temporarily unavailable. Please try again later.');
        }
      })
      .finally(() => setLoading(false));
  };

  return (
    <>
      <Helmet>
        <title>Live Train Status — Running Status, Location &amp; Delays | ChaloTrain</title>
        <meta name="description" content="Track your train's running status, current location, delay in minutes, and station-wise arrival/departure updates for Indian Railways trains. No login required." />
        <meta name="keywords" content="live train status, train running status, train location, train delay, NTES train tracking, Indian Railways live status, where is my train" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Live Train Status — Running Status & Location | ChaloTrain" />
        <meta property="og:description" content="Track your train live with running status, current location, delay in minutes, and station-wise updates for all Indian Railways trains." />
        <meta property="og:url" content="https://chalotrain.com/live-status" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Live Train Status — Running Status & Location | ChaloTrain" />
        <meta name="twitter:description" content="Track your train live with running status, current location, delay in minutes, and station-wise updates." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/live-status" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'Live Train Status Tracker — ChaloTrain',
          url: 'https://chalotrain.com/live-status',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'All',
          description: 'Track Indian Railways trains. Get live running status, current location, and delay information.',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
          provider: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'Live Train Status', item: 'https://chalotrain.com/live-status' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        title="Live Train Status"
        subtitle="Track your train — current location, running status & delays"
        icon={Train}
        badge="Running Status"
      />
      {/* sr-only h1 for SEO checkers — PageHero renders the visible heading */}
      <h1 className="sr-only">Live Train Status — Running Status &amp; Location for Indian Railways Trains</h1>

      <section className="py-10 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* SEO Introduction */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-blue-100/60 p-6 mb-6 shadow-[0_2px_12px_hsl(221_79%_48%/0.06)]">
            <h2 className="text-xl font-bold text-slate-900 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              Track Your Train — Running Status &amp; Station-wise Updates
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Stay updated with your train's running status and current location. ChaloTrain's Live Train Status tool provides station-wise information about your train's position, delays, and expected arrival times at upcoming stations.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Whether you're waiting at the station or planning to pick up someone, our tracking feature helps you stay informed. Simply enter the train number and journey date to see the complete route with station-wise updates, departure and arrival times, and any delays.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>How to use:</strong> Enter your train number (e.g., 12301) and select the journey date. You'll see the train's current position on the route, stations it has passed, upcoming stops, and delay information. The status indicator shows which station the train is at or between.
            </p>
          </motion.div>

          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <form onSubmit={handleSearch} className="bg-white rounded-2xl border border-blue-100/60 p-6 shadow-[0_4px_20px_hsl(221_79%_48%/0.08)]">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label htmlFor="live-train-number" className="block text-sm font-semibold text-slate-700 mb-2">Train Number</label>
                  <input
                    id="live-train-number"
                    type="text"
                    inputMode="numeric"
                    value={trainNumber}
                    onChange={(e) => {
                      setTrainNumber(e.target.value.replace(/\D/g, '').slice(0, 5));
                      setValidationError((prev) => ({ ...prev, train: undefined }));
                    }}
                    placeholder="e.g., 12301"
                    maxLength={5}
                    className={`w-full px-4 py-3 border rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px] ${
                      validationError.train ? 'border-red-300 bg-red-50' : 'border-slate-200'
                    }`}
                  />
                  {validationError.train && (
                    <p className="text-xs text-red-600 mt-1" role="alert">{validationError.train}</p>
                  )}
                </div>
                <div>
                  <label htmlFor="live-journey-date" className="block text-sm font-semibold text-slate-700 mb-2">Journey Date</label>
                  <input
                    id="live-journey-date"
                    type="date"
                    value={date}
                    onChange={(e) => {
                      setDate(e.target.value);
                      setValidationError((prev) => ({ ...prev, date: undefined }));
                    }}
                    min={new Date().toISOString().split('T')[0]}
                    className={`w-full px-4 py-3 border rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px] ${
                      validationError.date ? 'border-red-300 bg-red-50' : 'border-slate-200'
                    }`}
                  />
                  {validationError.date && (
                    <p className="text-xs text-red-600 mt-1" role="alert">{validationError.date}</p>
                  )}
                </div>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
              >
                <Search size={16} aria-hidden="true" />
                Track Train
              </button>
            </form>
          </motion.div>

          {/* Loading State */}
          <AnimatePresence mode="wait">
            {loading && (
              <motion.div
                key="loading"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={fadeUp}
                className="mt-6"
              >
                <LoadingSpinner message="Tracking train..." />
              </motion.div>
            )}

            {/* Error State */}
            {error && !loading && (
              <motion.div
                key="error"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={fadeUp}
                className="mt-6"
              >
                <ErrorMessage
                  title="Unable to Track Train"
                  message={error}
                  onRetry={handleRetry}
                />
              </motion.div>
            )}

            {/* Results */}
            {result && !loading && !error && (
              <motion.div
                key="results"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={fadeUp}
                className="mt-6 space-y-4"
              >
                {/* Train Header */}
                <div className="bg-white rounded-2xl border border-blue-100/60 p-5 shadow-[0_4px_20px_hsl(221_79%_48%/0.08)]">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{result.trainName}</h3>
                      <p className="text-sm text-slate-500">Train #{result.trainNumber}</p>
                    </div>
                    {result.delayMinutes > 0 && (
                      <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700">
                        Delayed by {result.delayMinutes} min
                      </span>
                    )}
                    {result.delayMinutes === 0 && (
                      <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                        On Time
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Clock size={14} className="text-slate-400" />
                    <span>Running on {new Date(result.runningDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                  </div>
                  {result.currentStation && (
                    <div className="mt-3 pt-3 border-t border-slate-100">
                      <p className="text-xs text-slate-500 mb-1">Current Location</p>
                      <p className="text-sm font-semibold text-primary">{result.currentStation}</p>
                    </div>
                  )}
                </div>

                {/* Station Timeline */}
                <div className="bg-white rounded-2xl border border-slate-200 p-5">
                  <h4 className="text-sm font-bold text-slate-700 mb-4">Station Timeline</h4>
                  <div className="space-y-4">
                    {result.stations.map((station, index) => (
                      <div key={index} className="flex items-start gap-3">
                        <div className="flex flex-col items-center shrink-0">
                          {station.status === 'departed' ? (
                            <CheckCircle2 size={18} className="text-green-600" />
                          ) : station.status === 'arrived' ? (
                            <div className="w-4 h-4 rounded-full bg-primary animate-pulse" />
                          ) : (
                            <Circle size={18} className="text-slate-300" />
                          )}
                          {index < result.stations.length - 1 && (
                            <div className={`w-0.5 h-8 mt-1 ${
                              station.status === 'departed' ? 'bg-green-200' : 'bg-slate-200'
                            }`} />
                          )}
                        </div>
                        <div className="flex-1 pb-2">
                          <div className="flex items-start justify-between mb-1">
                            <div>
                              <p className="text-sm font-semibold text-slate-900">{station.stationName}</p>
                              <p className="text-xs text-slate-500">{station.stationCode}</p>
                            </div>
                            <StatusBadge status={station.status.toUpperCase()} />
                          </div>
                          <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                            <div>
                              <span className="text-slate-400">Arrival:</span>
                              <span className="ml-1 font-medium text-slate-700">
                                {station.actualArrival || station.scheduledArrival}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">Departure:</span>
                              <span className="ml-1 font-medium text-slate-700">
                                {station.actualDeparture || station.scheduledDeparture}
                              </span>
                            </div>
                          </div>
                          {station.delayMinutes > 0 && (
                            <p className="text-xs text-amber-600 mt-1">Delayed by {station.delayMinutes} min</p>
                          )}
                          {station.platform && (
                            <p className="text-xs text-slate-500 mt-1">Platform {station.platform}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Related Tools */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <RelatedTools currentHref="/live-status" />
          </motion.div>

          {/* Social Share */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <SocialShareBar
              title="Track trains live on ChaloTrain — running status & delays"
              url="https://chalotrain.com/live-status"
            />
          </motion.div>

          {/* FAQ */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <FAQSection items={FAQ_ITEMS} />
          </motion.div>

          {/* Learn more */}
          <div className="container mx-auto px-4 pb-2 mt-3">
            <div className="max-w-2xl mx-auto">
              <p className="text-sm text-slate-500">
                Want to learn more?{' '}
                <Link to="/blog/how-to-track-live-train-status" className="text-primary hover:underline font-medium">
                  Read our complete guide →
                </Link>
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> This website is not affiliated with IRCTC or Indian Railways and provides railway information for general purposes only. Please verify critical information from official sources.
              </p>
            </div>
          </motion.div>

        </div>
      </section>
    </>
  );
}
