import { useState, useRef, useEffect, useCallback } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import {
  Plane, ArrowLeftRight, Calendar, Search, ArrowRight,
  Filter, TrendingDown, AlertCircle, Loader2, ChevronRight,
  MapPin, Train, Luggage, RefreshCw, Clock, Users, X,
  CheckCircle2, Info,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAutocomplete } from '../hooks/useAutocomplete';

// ── Types ──────────────────────────────────────────────────────────────────────
interface AirportResult {
  id: string;
  name: string;
  iata: string;
  city: string;
  country: string;
  type: string;
  subTitle: string;
}

interface FlightSegment {
  origin: string;
  originName: string;
  destination: string;
  destinationName: string;
  departure: string;
  arrival: string;
  durationMins: number;
  carrier: string;
  carrierCode: string;
  flightNumber: string;
  cabinClass: string;
}

interface FlightLeg {
  origin: string;
  originName: string;
  destination: string;
  destinationName: string;
  departure: string;
  arrival: string;
  durationMins: number;
  stopCount: number;
  carriers: string[];
  carrierCodes: string[];
  flightNumbers: string[];
  segments: FlightSegment[];
}

interface FlightItinerary {
  id: string;
  price: number;
  priceFormatted: string;
  currency: string;
  legs: FlightLeg[];
  deepLink: string;
  isRefundable: boolean;
  baggageAllowance: string;
}

// ── Helpers ────────────────────────────────────────────────────────────────────
function formatTime(iso: string) {
  if (!iso) return '--:--';
  try {
    return new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false });
  } catch { return iso.slice(11, 16) || '--:--'; }
}

function formatDuration(mins: number) {
  if (!mins) return '--';
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function formatPrice(price: number, formatted?: string) {
  if (formatted && formatted !== '—') return formatted;
  if (!price) return '—';
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(price);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// ── Airline logo ───────────────────────────────────────────────────────────────
function AirlineLogo({ code, name, size = 'md' }: { code: string; name: string; size?: 'sm' | 'md' }) {
  const [err, setErr] = useState(false);
  const dim = size === 'sm' ? 'w-8 h-8' : 'w-10 h-10';
  const iconSize = size === 'sm' ? 13 : 16;
  if (!code || err) {
    return (
      <div className={`${dim} rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center shrink-0`}>
        <Plane size={iconSize} className="text-sky-400" />
      </div>
    );
  }
  return (
    <img
      src={`https://content.airhex.com/content/logos/thumbnails_200_200_${code.toUpperCase()}_s.png`}
      alt={name}
      className={`${dim} rounded-xl object-contain bg-white border border-slate-100 shrink-0 p-1`}
      onError={() => setErr(true)}
      loading="lazy"
      width={size === 'sm' ? 32 : 40}
      height={size === 'sm' ? 32 : 40}
    />
  );
}

// ── Airport dropdown ───────────────────────────────────────────────────────────
function AirportDropdown({
  results, loading, onSelect, visible,
}: {
  results: AirportResult[];
  loading: boolean;
  onSelect: (r: AirportResult) => void;
  visible: boolean;
}) {
  if (!visible) return null;
  return (
    <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-2xl shadow-[0_16px_48px_hsl(0_0%_0%/0.16)] border border-slate-100 z-50 overflow-hidden">
      {loading && (
        <div className="flex items-center gap-2 px-4 py-3 text-sm text-slate-500">
          <Loader2 size={13} className="animate-spin text-sky-500 shrink-0" /> Searching airports…
        </div>
      )}
      {!loading && results.length === 0 && (
        <div className="px-4 py-3 text-sm text-slate-400 flex items-center gap-2">
          <Info size={13} className="text-slate-300" /> No airports found. Try a city name.
        </div>
      )}
      {!loading && results.map((r) => (
        <button key={r.id} onClick={() => onSelect(r)}
          className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-sky-50 active:bg-sky-100 transition-colors text-left border-b border-slate-50 last:border-0"
        >
          <div className="w-8 h-8 rounded-lg bg-sky-50 border border-sky-100 flex items-center justify-center shrink-0">
            {r.type === 'CITY' ? <MapPin size={12} className="text-sky-500" /> : <Plane size={12} className="text-sky-500" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-slate-800 truncate">{r.name}</div>
            <div className="text-xs text-slate-400 truncate">{r.subTitle}</div>
          </div>
          {r.iata && (
            <span className="shrink-0 text-[10px] font-bold text-sky-600 bg-sky-50 border border-sky-100 px-1.5 py-0.5 rounded-md tabular-nums">
              {r.iata}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

// ── Stop badge ─────────────────────────────────────────────────────────────────
function StopBadge({ count }: { count: number }) {
  if (count === 0) return (
    <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-green-700 bg-green-50 border border-green-100 px-1.5 py-0.5 rounded-full">
      <CheckCircle2 size={8} /> Non-stop
    </span>
  );
  return (
    <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-100 px-1.5 py-0.5 rounded-full">
      {count} stop{count > 1 ? 's' : ''}
    </span>
  );
}

// ── Flight card skeleton ───────────────────────────────────────────────────────
function FlightCardSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-4 overflow-hidden relative"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="animate-pulse">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-200 shrink-0" />
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-3">
              <div className="h-6 w-16 bg-slate-200 rounded-lg" />
              <div className="flex-1 h-px bg-slate-100" />
              <div className="h-3 w-12 bg-slate-100 rounded" />
              <div className="flex-1 h-px bg-slate-100" />
              <div className="h-6 w-16 bg-slate-200 rounded-lg" />
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-24 bg-slate-100 rounded" />
              <div className="h-4 w-14 bg-slate-100 rounded-full" />
            </div>
          </div>
          <div className="text-right shrink-0 pl-3 space-y-1.5">
            <div className="h-6 w-20 bg-slate-200 rounded-lg" />
            <div className="h-3 w-14 bg-slate-100 rounded" />
            <div className="h-7 w-16 bg-slate-100 rounded-lg" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Flight card ────────────────────────────────────────────────────────────────
function FlightCard({ itin, rank }: { itin: FlightItinerary; rank: number }) {
  const leg = itin.legs[0];
  if (!leg) return null;
  const carrier = leg.carriers[0] ?? 'Unknown Airline';
  const code = leg.carrierCodes[0] ?? '';
  const multiCarrier = leg.carriers.length > 1;
  const isCheapest = rank === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(rank * 0.035, 0.3), duration: 0.28, ease: 'easeOut' as const }}
      className={`bg-white rounded-2xl border transition-all duration-200 group ${
        isCheapest
          ? 'border-sky-200 shadow-[0_4px_24px_hsl(207_90%_54%/0.13)]'
          : 'border-slate-100 hover:border-sky-200 hover:shadow-[0_4px_20px_hsl(0_0%_0%/0.07)]'
      }`}
    >
      {/* Cheapest banner */}
      {isCheapest && (
        <div className="flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-sky-600 to-sky-500 rounded-t-2xl">
          <TrendingDown size={10} className="text-sky-200" />
          <span className="text-[10px] font-bold text-white uppercase tracking-wider">Cheapest Option</span>
        </div>
      )}

      <div className="p-4">
        <div className="flex items-center gap-3">
          {/* Airline logo */}
          <AirlineLogo code={code} name={carrier} />

          {/* Route + times */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              {/* Departure */}
              <div className="text-center shrink-0">
                <div className="text-[22px] font-bold text-slate-900 leading-none tabular-nums tracking-tight">
                  {formatTime(leg.departure)}
                </div>
                <div className="text-[11px] font-bold text-slate-500 mt-0.5 tracking-wide">{leg.origin}</div>
              </div>

              {/* Duration line */}
              <div className="flex-1 flex flex-col items-center gap-1 min-w-0 px-1">
                <div className="text-[10px] text-slate-400 font-medium flex items-center gap-0.5 whitespace-nowrap">
                  <Clock size={8} /> {formatDuration(leg.durationMins)}
                </div>
                <div className="w-full flex items-center gap-0.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-300 shrink-0" />
                  <div className="flex-1 h-px bg-gradient-to-r from-slate-200 via-sky-200 to-slate-200" />
                  <Plane size={9} className="text-sky-400 shrink-0 -rotate-0" />
                  <div className="flex-1 h-px bg-gradient-to-r from-slate-200 via-sky-200 to-slate-200" />
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-300 shrink-0" />
                </div>
                <StopBadge count={leg.stopCount} />
              </div>

              {/* Arrival */}
              <div className="text-center shrink-0">
                <div className="text-[22px] font-bold text-slate-900 leading-none tabular-nums tracking-tight">
                  {formatTime(leg.arrival)}
                </div>
                <div className="text-[11px] font-bold text-slate-500 mt-0.5 tracking-wide">{leg.destination}</div>
              </div>
            </div>

            {/* Airline + extras row */}
            <div className="mt-2 flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] text-slate-400 font-medium">
                {multiCarrier ? leg.carriers.join(' · ') : carrier}
                {leg.flightNumbers[0] ? ` · ${leg.flightNumbers[0]}` : ''}
              </span>
              {itin.baggageAllowance && (
                <span className="flex items-center gap-0.5 text-[10px] text-slate-500 bg-slate-50 border border-slate-100 px-1.5 py-0.5 rounded-full">
                  <Luggage size={8} /> {itin.baggageAllowance}
                </span>
              )}
              {itin.isRefundable && (
                <span className="flex items-center gap-0.5 text-[10px] text-green-700 font-semibold bg-green-50 border border-green-100 px-1.5 py-0.5 rounded-full">
                  <RefreshCw size={8} /> Refundable
                </span>
              )}
            </div>
          </div>

          {/* Price + CTA */}
          <div className="text-right shrink-0 pl-3 border-l border-slate-100 ml-1 flex flex-col items-end gap-1.5">
            <div>
              <div className="text-[22px] font-bold text-slate-900 leading-none tabular-nums">
                {formatPrice(itin.price, itin.priceFormatted)}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">per person</div>
            </div>
            {itin.deepLink ? (
              <a href={itin.deepLink} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 active:bg-sky-800 px-3 py-1.5 rounded-lg transition-all duration-150 group-hover:shadow-sm"
                aria-label={`Book flight with ${carrier} for ${formatPrice(itin.price, itin.priceFormatted)}`}
              >
                Book <ChevronRight size={11} className="transition-transform group-hover:translate-x-0.5" />
              </a>
            ) : (
              <span className="text-[10px] text-slate-400 italic">No link</span>
            )}
          </div>
        </div>

        {/* Layover detail — only for connecting flights */}
        {leg.stopCount > 0 && leg.segments.length > 1 && (
          <div className="mt-3 pt-3 border-t border-slate-50 flex flex-wrap gap-1.5">
            {leg.segments.map((seg, i) => (
              <div key={i} className="flex items-center gap-1 text-[10px] text-slate-500 bg-slate-50 border border-slate-100 rounded-lg px-2 py-1">
                <span className="font-bold text-slate-700">{seg.origin}</span>
                <ArrowRight size={7} className="text-slate-400" />
                <span className="font-bold text-slate-700">{seg.destination}</span>
                {seg.carrier && <span className="text-slate-400 hidden sm:inline"> · {seg.carrier}</span>}
                {seg.flightNumber && <span className="text-slate-400"> · {seg.flightNumber}</span>}
              </div>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ── Popular routes ─────────────────────────────────────────────────────────────
const POPULAR_ROUTES = [
  { from: 'Delhi',     fromCode: 'DEL', to: 'Mumbai',    toCode: 'BOM' },
  { from: 'Mumbai',    fromCode: 'BOM', to: 'Bangalore', toCode: 'BLR' },
  { from: 'Delhi',     fromCode: 'DEL', to: 'Bangalore', toCode: 'BLR' },
  { from: 'Chennai',   fromCode: 'MAA', to: 'Delhi',     toCode: 'DEL' },
  { from: 'Kolkata',   fromCode: 'CCU', to: 'Mumbai',    toCode: 'BOM' },
  { from: 'Hyderabad', fromCode: 'HYD', to: 'Delhi',     toCode: 'DEL' },
];

// ── Main page ──────────────────────────────────────────────────────────────────
export default function FlightsPage() {
  const today = todayStr();

  const [originSelected, setOriginSelected] = useState<AirportResult | null>(null);
  const [originFocused, setOriginFocused]   = useState(false);
  const originAC = useAutocomplete<AirportResult>(async (q) => {
    const r = await fetch(`/api/flights/autocomplete?q=${encodeURIComponent(q)}`);
    const j = await r.json() as { results: AirportResult[] };
    return j.results ?? [];
  }, 220, 5 * 60 * 1000, 'flights-ac');

  const [destSelected, setDestSelected] = useState<AirportResult | null>(null);
  const [destFocused, setDestFocused]   = useState(false);
  const destAC = useAutocomplete<AirportResult>(async (q) => {
    const r = await fetch(`/api/flights/autocomplete?q=${encodeURIComponent(q)}`);
    const j = await r.json() as { results: AirportResult[] };
    return j.results ?? [];
  }, 220, 5 * 60 * 1000, 'flights-ac');

  const [date, setDate]             = useState(today);
  const [adults, setAdults]         = useState('1');
  const [cabinClass, setCabinClass] = useState('economy');

  const [itineraries, setItineraries] = useState<FlightItinerary[]>([]);
  const [totalCount, setTotalCount]   = useState(0);
  const [searching, setSearching]     = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [sortBy, setSortBy]           = useState<'price' | 'duration'>('price');

  const originRef = useRef<HTMLDivElement>(null);
  const destRef   = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (originRef.current && !originRef.current.contains(e.target as Node)) setOriginFocused(false);
      if (destRef.current   && !destRef.current.contains(e.target as Node))   setDestFocused(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const swapAirports = useCallback(() => {
    const tmpSel = originSelected;
    const tmpQ   = originAC.query;
    setOriginSelected(destSelected);
    originAC.setQuery(destAC.query);
    setDestSelected(tmpSel);
    destAC.setQuery(tmpQ);
  }, [originSelected, destSelected, originAC, destAC]);

  const canSearch = originSelected && destSelected && date;

  const handleSearch = useCallback(async () => {
    if (!canSearch) return;
    setSearching(true);
    setSearchError(null);
    setHasSearched(true);
    try {
      const params = new URLSearchParams({
        fromId: originSelected.id,
        toId:   destSelected.id,
        date,
        adults,
        cabinClass,
        currency: 'INR',
      });
      const r = await fetch(`/api/flights/search?${params.toString()}`);
      const j = await r.json() as { itineraries?: FlightItinerary[]; totalCount?: number; message?: string };
      if (!r.ok) throw new Error(j.message ?? `HTTP ${r.status}`);
      setItineraries(j.itineraries ?? []);
      setTotalCount(j.totalCount ?? (j.itineraries?.length ?? 0));
    } catch (e: unknown) {
      setSearchError(e instanceof Error ? e.message : 'Search failed. Please try again.');
      setItineraries([]);
    } finally {
      setSearching(false);
    }
  }, [canSearch, originSelected, destSelected, date, adults, cabinClass]);

  // Allow Enter key to trigger search
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && canSearch && !searching) handleSearch();
  }, [canSearch, searching, handleSearch]);

  const sorted = [...itineraries].sort((a, b) =>
    sortBy === 'price'
      ? a.price - b.price
      : (a.legs[0]?.durationMins ?? 0) - (b.legs[0]?.durationMins ?? 0)
  );

  const minPrice = itineraries.filter((i) => i.price > 0).reduce((m, i) => Math.min(m, i.price), Infinity);

  return (
    <>
      <Helmet>
        <title>Flight Search — Compare Domestic Flights | ChaloTrain</title>
        <meta name="description" content="Search and compare domestic flight prices across IndiGo, Air India, SpiceJet and more. Find the cheapest flights from ChaloTrain — India's railway travel companion." />
        <meta name="robots" content="noindex, nofollow" />
        <link rel="canonical" href="https://chalotrain.com/flights" />
        <meta property="og:title" content="Flight Search — Compare Domestic Flights | ChaloTrain" />
        <meta property="og:description" content="Search and compare domestic flight prices across IndiGo, Air India, SpiceJet and more. Find the cheapest flights from ChaloTrain." />
        <meta property="og:url" content="https://chalotrain.com/flights" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Flight Search — Compare Domestic Flights | ChaloTrain" />
        <meta name="twitter:description" content="Search and compare domestic flight prices across IndiGo, Air India, SpiceJet and more." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'ChaloTrain Flight Search',
          url: 'https://chalotrain.com/flights',
          description: 'Compare domestic flight prices across all major Indian airlines.',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'Web',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
        })}</script>
      </Helmet>

      {/* ── Hero ─────────────────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-[#0a1f4e] via-[#0e3a8a] to-sky-700 pt-10 pb-0 relative overflow-hidden">
        {/* Grid texture */}
        <div className="absolute inset-0 dot-pattern" />
        {/* Radial glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[250px] bg-sky-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative container mx-auto px-4">
          {/* Breadcrumb */}
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-sky-300/70 text-xs mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <ChevronRight size={12} />
            <span className="text-white/80">Flights</span>
          </nav>

          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="text-center mb-6">
            <div className="inline-flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-3 py-1 text-xs font-semibold text-white/90 mb-3 backdrop-blur-sm">
              <Plane size={11} className="text-sky-300" />
              Compare All Domestic Airlines
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-1.5 tracking-tight">Search Cheap Flights</h1>
            <p className="text-sky-200 text-sm max-w-md mx-auto">IndiGo · Air India · SpiceJet · Vistara · GoFirst and more</p>
          </motion.div>

          {/* Search card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="max-w-2xl mx-auto bg-white rounded-2xl shadow-[0_24px_64px_hsl(0_0%_0%/0.28)] overflow-visible mb-0"
          >
            <div className="p-5" onKeyDown={handleKeyDown}>
              {/* Origin / Swap / Destination */}
              <div className="grid grid-cols-[1fr_36px_1fr] gap-2 items-end mb-3">
                {/* Origin */}
                <div ref={originRef} className="relative">
                  <label htmlFor="flight-origin" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">From</label>
                  <div className={`flex items-center gap-1.5 px-3 py-2.5 border rounded-xl transition-all duration-150 ${originFocused ? 'border-sky-500 ring-2 ring-sky-500/20 bg-white shadow-sm' : 'border-slate-200 bg-slate-50 hover:border-slate-300'}`}>
                    <Plane size={13} className="text-slate-400 shrink-0" />
                    <input
                      id="flight-origin"
                      value={originSelected ? (originSelected.iata ? `${originSelected.iata} — ${originSelected.city || originSelected.name}` : originSelected.name) : originAC.query}
                      onChange={(e) => { setOriginSelected(null); originAC.setQuery(e.target.value); }}
                      onFocus={() => setOriginFocused(true)}
                      placeholder="City or airport"
                      className="flex-1 text-sm text-slate-700 placeholder-slate-400 bg-transparent focus:outline-none min-w-0"
                      autoComplete="off"
                      aria-label="Departure city or airport"
                      aria-expanded={originFocused && !originSelected && originAC.query.length >= 2}
                      aria-haspopup="listbox"
                    />
                    {originAC.loading && <Loader2 size={12} className="animate-spin text-sky-400 shrink-0" />}
                    {originSelected && (
                      <button onClick={() => { setOriginSelected(null); originAC.setQuery(''); }}
                        className="text-slate-300 hover:text-slate-600 transition-colors shrink-0 p-0.5 rounded"
                        aria-label="Clear origin"
                      >
                        <X size={12} />
                      </button>
                    )}
                  </div>
                  <AirportDropdown
                    results={originAC.results}
                    loading={originAC.loading}
                    visible={originFocused && !originSelected && originAC.query.length >= 2}
                    onSelect={(r) => { setOriginSelected(r); originAC.setQuery(r.iata || r.name); setOriginFocused(false); }}
                  />
                </div>

                {/* Swap */}
                <div className="flex items-end justify-center pb-0.5">
                  <button onClick={swapAirports}
                    className="w-8 h-8 rounded-full border-2 border-slate-200 flex items-center justify-center text-slate-400 hover:border-sky-400 hover:text-sky-500 hover:bg-sky-50 hover:rotate-180 transition-all duration-300"
                    aria-label="Swap origin and destination"
                  >
                    <ArrowLeftRight size={13} />
                  </button>
                </div>

                {/* Destination */}
                <div ref={destRef} className="relative">
                  <label htmlFor="flight-dest" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">To</label>
                  <div className={`flex items-center gap-1.5 px-3 py-2.5 border rounded-xl transition-all duration-150 ${destFocused ? 'border-sky-500 ring-2 ring-sky-500/20 bg-white shadow-sm' : 'border-slate-200 bg-slate-50 hover:border-slate-300'}`}>
                    <MapPin size={13} className="text-slate-400 shrink-0" />
                    <input
                      id="flight-dest"
                      value={destSelected ? (destSelected.iata ? `${destSelected.iata} — ${destSelected.city || destSelected.name}` : destSelected.name) : destAC.query}
                      onChange={(e) => { setDestSelected(null); destAC.setQuery(e.target.value); }}
                      onFocus={() => setDestFocused(true)}
                      placeholder="City or airport"
                      className="flex-1 text-sm text-slate-700 placeholder-slate-400 bg-transparent focus:outline-none min-w-0"
                      autoComplete="off"
                      aria-label="Destination city or airport"
                      aria-expanded={destFocused && !destSelected && destAC.query.length >= 2}
                      aria-haspopup="listbox"
                    />
                    {destAC.loading && <Loader2 size={12} className="animate-spin text-sky-400 shrink-0" />}
                    {destSelected && (
                      <button onClick={() => { setDestSelected(null); destAC.setQuery(''); }}
                        className="text-slate-300 hover:text-slate-600 transition-colors shrink-0 p-0.5 rounded"
                        aria-label="Clear destination"
                      >
                        <X size={12} />
                      </button>
                    )}
                  </div>
                  <AirportDropdown
                    results={destAC.results}
                    loading={destAC.loading}
                    visible={destFocused && !destSelected && destAC.query.length >= 2}
                    onSelect={(r) => { setDestSelected(r); destAC.setQuery(r.iata || r.name); setDestFocused(false); }}
                  />
                </div>
              </div>

              {/* Date + Adults + Cabin */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div>
                  <label htmlFor="flight-date" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Date</label>
                  <div className="flex items-center gap-1.5 px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 hover:border-slate-300 focus-within:border-sky-500 focus-within:ring-2 focus-within:ring-sky-500/20 focus-within:bg-white transition-all duration-150">
                    <Calendar size={12} className="text-slate-400 shrink-0" />
                    <input id="flight-date" type="date" value={date} min={today} onChange={(e) => setDate(e.target.value)}
                      className="flex-1 text-xs text-slate-700 bg-transparent focus:outline-none min-w-0"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="flight-adults" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Adults</label>
                  <div className="flex items-center gap-1.5 px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 hover:border-slate-300 focus-within:border-sky-500 focus-within:ring-2 focus-within:ring-sky-500/20 focus-within:bg-white transition-all duration-150">
                    <Users size={12} className="text-slate-400 shrink-0" />
                    <select id="flight-adults" value={adults} onChange={(e) => setAdults(e.target.value)}
                      className="flex-1 text-xs text-slate-700 bg-transparent focus:outline-none min-w-0"
                    >
                      {[1,2,3,4,5,6].map((n) => <option key={n} value={n}>{n} Adult{n > 1 ? 's' : ''}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="flight-class" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Class</label>
                  <select id="flight-class" value={cabinClass} onChange={(e) => setCabinClass(e.target.value)}
                    className="w-full px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 text-xs text-slate-700 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all duration-150"
                  >
                    <option value="economy">Economy</option>
                    <option value="premium_economy">Prem. Economy</option>
                    <option value="business">Business</option>
                    <option value="first">First</option>
                  </select>
                </div>
              </div>

              <button onClick={handleSearch} disabled={!canSearch || searching}
                className="w-full flex items-center justify-center gap-2 py-3 bg-sky-600 text-white text-sm font-bold rounded-xl hover:bg-sky-700 active:bg-sky-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-150 shadow-[0_4px_14px_hsl(199_89%_48%/0.35)] hover:shadow-[0_6px_20px_hsl(199_89%_48%/0.45)] hover:-translate-y-0.5"
                aria-label="Search flights"
              >
                {searching
                  ? <><Loader2 size={15} className="animate-spin" /> Searching flights…</>
                  : <><Search size={15} /> Search Flights <ArrowRight size={13} /></>
                }
              </button>

              {/* Train nudge */}
              <div className="flex items-center justify-center gap-1.5 mt-2.5 text-[11px] text-slate-400">
                <Train size={10} className="text-primary" />
                <span>Trains are often cheaper —</span>
                <Link to="/train-search" className="text-primary font-semibold hover:underline">compare train fares</Link>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Wave */}
        <div className="relative h-8 overflow-hidden mt-4">
          <svg viewBox="0 0 1440 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="absolute bottom-0 w-full" preserveAspectRatio="none">
            <path d="M0 32L60 26C120 21 240 10 360 8C480 5 600 10 720 13C840 16 960 16 1080 13C1200 10 1320 5 1380 2L1440 0V32H0Z" fill="#f5f7ff" />
          </svg>
        </div>
      </section>

      {/* ── Results ──────────────────────────────────────────────────────────── */}
      <section className="bg-background min-h-[40vh] py-8">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* Error */}
          <AnimatePresence>
            {searchError && (
              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl p-4 mb-6"
                role="alert"
              >
                <AlertCircle size={18} className="text-red-500 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-red-700">Search failed</div>
                  <div className="text-sm text-red-600 mt-0.5">{searchError}</div>
                  <button onClick={() => setSearchError(null)} className="mt-2 text-xs text-red-500 hover:text-red-700 underline">Dismiss</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Skeleton loading */}
          {searching && (
            <div className="space-y-3" aria-label="Loading flights" aria-busy="true">
              {[0,1,2,3,4].map((i) => <FlightCardSkeleton key={i} delay={i * 60} />)}
            </div>
          )}

          {/* Results */}
          {!searching && hasSearched && !searchError && (
            <>
              {itineraries.length > 0 && (
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-sm font-bold text-slate-800">
                      {totalCount > itineraries.length
                        ? `${itineraries.length} of ${totalCount.toLocaleString()}`
                        : itineraries.length} flights found
                    </div>
                    {minPrice < Infinity && (
                      <div className="flex items-center gap-1 text-xs text-green-700 font-semibold mt-0.5">
                        <TrendingDown size={11} /> From {formatPrice(minPrice)} per person
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Filter size={12} className="text-slate-400" />
                    <span className="text-xs text-slate-500 mr-0.5">Sort:</span>
                    {(['price', 'duration'] as const).map((s) => (
                      <button key={s} onClick={() => setSortBy(s)}
                        className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-all duration-150 ${sortBy === s ? 'bg-sky-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:border-sky-300 hover:text-sky-600'}`}
                      >
                        {s === 'price' ? 'Price' : 'Duration'}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {sorted.map((itin, i) => (
                  <FlightCard key={itin.id} itin={itin} rank={i} />
                ))}
              </div>

              {itineraries.length === 0 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-16">
                  <div className="w-16 h-16 rounded-2xl bg-sky-100 flex items-center justify-center mx-auto mb-4">
                    <Plane size={28} className="text-sky-400" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-700 mb-1">No flights found</h3>
                  <p className="text-slate-500 text-sm max-w-xs mx-auto">Try different dates or airports. Trains might be a better option for this route.</p>
                  <Link to="/train-search" className="inline-flex items-center gap-1.5 mt-4 text-sm font-bold text-primary hover:underline">
                    <Train size={14} /> Search trains instead
                  </Link>
                </motion.div>
              )}
            </>
          )}

          {/* Initial state — popular routes */}
          {!hasSearched && !searching && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="text-center py-8 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-sky-100 flex items-center justify-center mx-auto mb-3">
                  <Plane size={24} className="text-sky-500" />
                </div>
                <h2 className="text-base font-bold text-slate-700 mb-1">Search flights above</h2>
                <p className="text-slate-500 text-sm">Enter origin, destination and date to compare fares.</p>
              </div>

              {/* Popular routes */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingDown size={13} className="text-sky-500" />
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Popular Routes</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {POPULAR_ROUTES.map((route) => (
                    <button key={`${route.fromCode}-${route.toCode}`}
                      className="flex items-center gap-2 bg-white rounded-xl border border-slate-100 hover:border-sky-200 hover:shadow-sm px-3 py-2.5 transition-all duration-150 text-left group"
                      onClick={() => {
                        originAC.setQuery(route.fromCode);
                        destAC.setQuery(route.toCode);
                      }}
                    >
                      <div className="w-7 h-7 rounded-lg bg-sky-50 flex items-center justify-center shrink-0 group-hover:bg-sky-100 transition-colors">
                        <Plane size={12} className="text-sky-500" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-800 truncate">{route.from}</div>
                        <div className="flex items-center gap-0.5 text-[10px] text-slate-400">
                          <ArrowRight size={8} /> {route.to}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Train comparison nudge */}
              <div className="mt-6 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-4 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shrink-0">
                  <Train size={16} className="text-white" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-800 mb-0.5">Trains are often 3–5× cheaper</div>
                  <p className="text-xs text-slate-500 leading-relaxed">For routes under 600 km, trains offer better value with AC comfort. Compare before you book.</p>
                  <Link to="/train-search" className="inline-flex items-center gap-1 mt-2 text-xs font-bold text-primary hover:underline">
                    Search trains <ArrowRight size={11} />
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </section>
    </>
  );
}
