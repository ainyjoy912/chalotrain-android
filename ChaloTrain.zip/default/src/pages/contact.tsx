import { useState } from 'react';
import { motion } from 'motion/react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { MapPin, Mail, MessageCircle, Clock, Send, CheckCircle, HelpCircle } from 'lucide-react';
import PageHero from '@/components/PageHero';
import { Link } from 'react-router-dom';

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const faqs = [
  { q: 'Why is my PNR status not updating?', a: 'PNR status updates in real-time as chart preparation happens (4–6 hours before departure). If your train hasn\'t departed yet, the status may still show the booking status. Try refreshing after chart preparation.' },
  { q: 'Why is the live train status showing "No data"?', a: 'Some trains, especially short-distance passenger trains, may not have real-time GPS tracking. Live status is most reliable for long-distance express and mail trains. Also check that you\'ve entered the correct train number.' },
  { q: 'Is ChaloTrain affiliated with IRCTC?', a: 'No. ChaloTrain is an independent railway information portal and is not affiliated with IRCTC or Indian Railways. For booking tickets, please use the official IRCTC website.' },
  { q: 'Why are the tools showing "service unavailable"?', a: 'Our tools depend on third-party railway data APIs. Occasionally, these services experience high traffic or maintenance. Please try again after a few minutes. If the issue persists, contact us.' },
];

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Simulate form submission
    await new Promise((r) => setTimeout(r, 1000));
    setSubmitted(true);
    setSubmitting(false);
  };

  return (
    <>
      <Helmet>
        <title>Contact Us — ChaloTrain | Railway Information Support</title>
        <meta name="description" content="Get in touch with ChaloTrain. Have a question about our railway tools, found an issue, or want to provide feedback? We'd love to hear from you." />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Contact Us — ChaloTrain" />
        <meta property="og:description" content="Get in touch with ChaloTrain. Have a question about our railway tools, found an issue, or want to provide feedback? We'd love to hear from you." />
        <meta property="og:url" content="https://chalotrain.com/contact" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Contact Us — ChaloTrain" />
        <meta name="twitter:description" content="Get in touch with ChaloTrain. Have a question about our railway tools, found an issue, or want to provide feedback?" />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/contact" />
      </Helmet>

      <PageHero
        icon={Mail}
        title="Contact Us"
        subtitle="Have a question, found an issue, or want to share feedback? We're here to help."
        badge="Get In Touch"
      />
      <h1 className="sr-only">Contact Us — ChaloTrain</h1>

      <section className="py-12 bg-slate-50 min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-4xl">

          <motion.div initial="hidden" animate="visible" variants={stagger} className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[
              { icon: Mail,          title: 'Email Us',       desc: 'chalotrain@chalotrain.com', sub: 'We aim to respond as soon as possible',  color: 'bg-blue-50 text-blue-600'    },
              { icon: Clock,         title: 'Response Time',  desc: 'As soon as possible',        sub: 'Monday to Saturday',                    color: 'bg-green-50 text-green-600'  },
              { icon: MessageCircle, title: 'WhatsApp',       desc: '+91 91704 77270',             sub: 'Quick queries & feedback',              color: 'bg-emerald-50 text-emerald-600' },
            ].map(({ icon: Icon, title, desc, sub, color }) => (
              <motion.div key={title} variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-5 text-center">
                <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center mx-auto mb-3`}>
                  <Icon size={22} />
                </div>
                <h3 className="font-bold text-slate-800 mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{title}</h3>
                <p className="text-sm font-semibold text-slate-700">{desc}</p>
                <p className="text-xs text-slate-400 mt-0.5">{sub}</p>
              </motion.div>
            ))}
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">

            {/* Contact Form */}
            <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-6">
              <h2 className="text-xl font-bold text-slate-900 mb-5" style={{ fontFamily: 'var(--font-heading)' }}>Send Us a Message</h2>

              {submitted ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <CheckCircle size={48} className="text-green-500 mb-4" />
                  <h3 className="font-bold text-slate-800 text-lg mb-2">Message Sent!</h3>
                  <p className="text-sm text-slate-600">Thank you for reaching out. We'll get back to you within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Your Name</label>
                    <input
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Email Address</label>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="e.g. rahul@example.com"
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Subject</label>
                    <select
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      required
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm bg-white"
                    >
                      <option value="">Select a subject</option>
                      <option value="tool-issue">Tool not working</option>
                      <option value="wrong-data">Incorrect data / information</option>
                      <option value="feature-request">Feature request</option>
                      <option value="feedback">General feedback</option>
                      <option value="partnership">Partnership / advertising</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5">Message</label>
                    <textarea
                      required
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder="Please describe your question or issue in detail..."
                      rows={5}
                      className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full flex items-center justify-center gap-2 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-60"
                  >
                    <Send size={16} />
                    {submitting ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              )}
            </motion.div>

            {/* FAQ */}
            <motion.div initial="hidden" animate="visible" variants={fadeUp} className="space-y-4">
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <h2 className="text-xl font-bold text-slate-900 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Common Questions</h2>
                <div className="space-y-3">
                  {faqs.map((faq, i) => (
                    <details key={i} className="group border border-slate-200 rounded-xl overflow-hidden">
                      <summary className="flex items-center justify-between gap-2 px-4 py-3 cursor-pointer list-none text-sm font-semibold text-slate-800 hover:text-primary transition-colors">
                        <span className="flex items-center gap-2">
                          <HelpCircle size={14} className="text-primary flex-shrink-0" />
                          {faq.q}
                        </span>
                      </summary>
                      <div className="px-4 pb-3 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-2">
                        {faq.a}
                      </div>
                    </details>
                  ))}
                </div>
              </div>

              {/* Office Info */}
              <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
                <div>
                  <h3 className="font-bold text-slate-800 mb-2 flex items-center gap-2" style={{ fontFamily: 'var(--font-heading)' }}>
                    <MapPin size={16} className="text-primary flex-shrink-0" /> Registered Office
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    ChaloTrain Technologies Private Limited<br />
                    C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                    Ragaul Tahsil, Hamirpur,<br />
                    Uttar Pradesh — 210507<br />
                    India
                  </p>
                </div>
                <div className="border-t border-slate-100 pt-4">
                  <p className="text-xs text-slate-400 border-t border-slate-100 pt-3">
                    ChaloTrain is an independent railway information portal and is not affiliated with IRCTC or Indian Railways.
                  </p>
                </div>
              </div>

              {/* Quick Links */}
              <div className="bg-primary/5 border border-primary/20 rounded-2xl p-5">
                <h3 className="font-bold text-slate-800 mb-3 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>Quick Links</h3>
                <div className="space-y-2">
                  {[
                    { label: 'Privacy Policy', href: '/privacy' },
                    { label: 'Terms of Service', href: '/terms' },
                    { label: 'Disclaimer', href: '/disclaimer' },
                    { label: 'About ChaloTrain', href: '/about' },
                  ].map(({ label, href }) => (
                    <Link key={href} to={href} className="block text-sm text-primary hover:underline">
                      {label} →
                    </Link>
                  ))}
                </div>
              </div>

              {/* Helpful Articles */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5">
                <h3 className="font-bold text-slate-800 mb-3 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>Helpful Articles</h3>
                <div className="space-y-2">
                  {[
                    { label: 'How to check PNR status online', href: '/blog/how-to-check-pnr-status-online' },
                    { label: 'How to track live train status', href: '/blog/how-to-track-live-train-status' },
                    { label: 'Train ticket cancellation & refund rules', href: '/blog/train-ticket-cancellation-refund-rules' },
                    { label: 'Tatkal ticket booking tips', href: '/blog/tatkal-ticket-booking-tips' },
                  ].map(({ label, href }) => (
                    <Link key={href} to={href} className="block text-sm text-primary hover:underline">
                      {label} →
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>

          </div>

        </div>
      </section>
    </>
  );
}
