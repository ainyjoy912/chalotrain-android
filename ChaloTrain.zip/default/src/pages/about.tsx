import { motion } from 'motion/react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { Train, Zap, ShieldCheck, Smartphone, MapPin, Heart, BookOpen, Target, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const tools = [
  { name: 'PNR Status', href: '/pnr-status', desc: 'Instant booking status for all passengers' },
  { name: 'Live Train Status', href: '/live-status', desc: 'Live train tracking & delay info' },
  { name: 'Train Between Stations', href: '/train-search', desc: 'Find all trains on any route' },
  { name: 'Seat Availability', href: '/seat-availability', desc: 'Multi-date availability across all classes' },
  { name: 'Train Schedule', href: '/train-schedule', desc: 'Complete timetable with all stops' },
  { name: 'Fare Inquiry', href: '/fare-inquiry', desc: 'Compare fares across classes & quotas' },
];

const stats = [
  { icon: Train,  value: '13,000+', label: 'Trains Covered'    },
  { icon: MapPin, value: '7,000+',  label: 'Railway Stations'  },
  { icon: Zap,    value: '6',       label: 'Free Tools'        },
  { icon: Heart,  value: '100%',    label: 'Free to Use'       },
];

const values = [
  { icon: Zap,         title: 'Speed',         desc: 'We believe your time is precious. Every tool on ChaloTrain is built to deliver information quickly and without unnecessary steps.' },
  { icon: ShieldCheck, title: 'Accuracy',       desc: 'We source railway data from third-party APIs and make every effort to present it accurately. Always verify critical information from official sources.' },
  { icon: Smartphone,  title: 'Accessibility',  desc: 'ChaloTrain is designed mobile-first. Whether you\'re at home or on the platform, our tools work on any device.' },
  { icon: Heart,       title: 'Simplicity',     desc: 'Railway information can be complex. We strip away the complexity and present only what you need, when you need it.' },
];

export default function AboutPage() {
  return (
    <>
      <Helmet>
        <title>About ChaloTrain — Independent Railway Information Platform</title>
        <meta name="description" content="Learn about ChaloTrain — an independent railway information platform by ChaloTrain Technologies Private Limited. Free PNR status, live train tracking, seat availability, fare inquiry and more." />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="About ChaloTrain — Independent Railway Information Platform" />
        <meta property="og:description" content="Learn about ChaloTrain — an independent railway information platform by ChaloTrain Technologies Private Limited. Free PNR status, live train tracking, seat availability, fare inquiry and more." />
        <meta property="og:url" content="https://chalotrain.com/about" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="About ChaloTrain — Independent Railway Information Platform" />
        <meta name="twitter:description" content="Learn about ChaloTrain — an independent railway information platform by ChaloTrain Technologies Private Limited. Free PNR status, live train tracking, seat availability, fare inquiry and more." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/about" />
      </Helmet>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'repeating-linear-gradient(90deg,white 0,white 2px,transparent 2px,transparent 60px),repeating-linear-gradient(0deg,white 0,white 1px,transparent 1px,transparent 40px)' }} />
        <div className="relative container mx-auto px-4 max-w-4xl text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/10 border border-white/20 mb-6">
              <Train size={32} className="text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
              About ChaloTrain
            </h1>
            <p className="text-blue-100 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
              An independent railway information platform — making train information easier to access for every Indian traveler.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-14 bg-slate-50">
        <div className="container mx-auto px-4 max-w-4xl">

          {/* Our Story */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Our Story</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              ChaloTrain was born out of a simple frustration: checking train information in India was unnecessarily complicated. Travelers had to navigate multiple websites, deal with slow-loading pages, and wade through confusing interfaces just to find out if their train was running on time.
            </p>
            <p className="text-slate-600 leading-relaxed mb-4">
              We set out to build something better — a single, fast, and reliable platform that gives Indian travelers all the railway information they need in one place. No clutter, no confusion, just the information you need delivered quickly.
            </p>
            <p className="text-slate-600 leading-relaxed">
              ChaloTrain offers six free tools: PNR Status, Live Train Status, Train Between Stations, Seat Availability, Train Schedule, and Fare Inquiry — all free, all without requiring a login.
            </p>
          </motion.div>

          {/* Stats */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {stats.map(({ icon: Icon, value, label }) => (
              <motion.div key={label} variants={fadeUp}
                className="bg-white rounded-2xl border border-slate-200 p-5 text-center">
                <Icon size={24} className="text-primary mx-auto mb-2" />
                <div className="text-2xl font-bold text-slate-900 mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{value}</div>
                <div className="text-xs text-slate-500">{label}</div>
              </motion.div>
            ))}
          </motion.div>

          {/* Mission & Vision */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <motion.div variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                  <Target size={20} className="text-primary" />
                </div>
                <h2 className="text-lg font-bold text-slate-900" style={{ fontFamily: 'var(--font-heading)' }}>Our Mission</h2>
              </div>
              <p className="text-slate-600 leading-relaxed text-sm">
                To make Indian Railways information universally accessible — fast, accurate, and free for every traveler, regardless of their technical expertise or device. We believe that access to reliable travel information is a right, not a privilege.
              </p>
            </motion.div>
            <motion.div variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center">
                  <Eye size={20} className="text-indigo-600" />
                </div>
                <h2 className="text-lg font-bold text-slate-900" style={{ fontFamily: 'var(--font-heading)' }}>Our Vision</h2>
              </div>
              <p className="text-slate-600 leading-relaxed text-sm">
                To build a reliable, independent railway information platform that makes train journey planning easier for every Indian traveler.
              </p>
            </motion.div>
          </motion.div>

          {/* Our Values */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Our Values</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {values.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <Icon size={20} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{title}</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Our Tools */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Our Railway Tools</h2>
            <p className="text-slate-500 text-sm mb-6">Six free tools covering every aspect of your train journey.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {tools.map(({ name, href, desc }) => (
                <Link key={name} to={href}
                  className="group border border-slate-200 rounded-xl p-4 hover:border-primary/40 hover:shadow-sm transition-all">
                  <div className="font-bold text-slate-800 text-sm mb-1 group-hover:text-primary transition-colors" style={{ fontFamily: 'var(--font-heading)' }}>{name}</div>
                  <div className="text-xs text-slate-500">{desc}</div>
                </Link>
              ))}
            </div>
          </motion.div>

          {/* Blog */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                <BookOpen size={20} className="text-green-600" />
              </div>
              <h2 className="text-xl font-bold text-slate-900" style={{ fontFamily: 'var(--font-heading)' }}>Railway Knowledge Hub</h2>
            </div>
            <p className="text-slate-600 leading-relaxed text-sm mb-4">
              Beyond tools, ChaloTrain publishes in-depth guides and articles to help travelers navigate the complexities of Indian Railways. From understanding PNR status codes to mastering Tatkal booking, our blog covers everything you need to travel smarter.
            </p>
            <Link to="/blog" className="inline-flex items-center gap-2 text-primary font-semibold text-sm hover:underline">
              Browse our Railway Blog →
            </Link>
          </motion.div>

          {/* Office Address */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Registered Office</h2>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0 mt-0.5">
                <MapPin size={20} className="text-primary" />
              </div>
              <div>
                <p className="font-bold text-slate-800 text-sm mb-1" style={{ fontFamily: 'var(--font-heading)' }}>
                  ChaloTrain Technologies Private Limited
                </p>
                <p className="text-sm text-slate-600 leading-relaxed">
                  C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                  Ragaul Tahsil, Hamirpur,<br />
                  Uttar Pradesh — 210507<br />
                  India
                </p>
              </div>
            </div>
          </motion.div>

          {/* Legal Information */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8 mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>Legal Information</h2>
            <div className="bg-slate-50 rounded-xl border border-slate-200 p-5">
              <p className="text-sm font-bold text-slate-800 mb-4">ChaloTrain Technologies Private Limited</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { label: 'CIN', value: 'U62099UP2026PTC246981' },
                  { label: 'PAN', value: 'AANCC7761J' },
                  { label: 'TAN', value: 'KNPC02496E' },
                ].map(({ label, value }) => (
                  <div key={label} className="bg-white rounded-lg border border-slate-200 px-4 py-3">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{label}</p>
                    <p className="text-sm font-mono font-semibold text-slate-800 tracking-wide">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Disclaimer */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="bg-amber-50 border border-amber-200 rounded-2xl p-6">
            <h3 className="font-bold text-amber-900 mb-2">Disclaimer</h3>
            <p className="text-sm text-amber-800 leading-relaxed">
              ChaloTrain is an independent railway information portal and is <strong>not affiliated with, endorsed by, or connected to IRCTC, Indian Railways, or any government body</strong>. All information is provided for general reference purposes only. For official bookings, cancellations, and authoritative information, please use the official <a href="https://www.irctc.co.in" target="_blank" rel="noopener noreferrer" className="underline font-semibold">IRCTC website</a> or contact Indian Railways directly.
            </p>
          </motion.div>

        </div>
      </section>
    </>
  );
}
