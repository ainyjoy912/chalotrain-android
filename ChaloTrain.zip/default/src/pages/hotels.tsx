import { useState, useRef, useEffect, useCallback } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import {
  Building2, MapPin, Search, ArrowRight,
  Star, AlertCircle, Loader2, ChevronRight,
  Train, Zap, Filter, TrendingDown, Calendar,
  Users, Bed, X, Info,
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAutocomplete } from '../hooks/useAutocomplete';

// ── Types ──────────────────────────────────────────────────────────────────────
interface HotelDestination {
  destId: string;
  name: string;
  label: string;
  country: string;
  destType: string;
}

interface HotelPhoto {
  url: string;
  description: string;
}

interface HotelListing {
  id: string;
  name: string;
  starRating: number;
  reviewScore: number;
  reviewScoreWord: string;
  reviewCount: number;
  pricePerNight: number;
  currency: string;
  address: string;
  city: string;
  country: string;
  photo: HotelPhoto | null;
  dealBadge: string;
  distanceFromCenter: string;
  checkinFrom: string;
  checkoutUntil: string;
}

// ── Helpers ────────────────────────────────────────────────────────────────────
function formatPrice(price: number, currency = 'INR') {
  if (!price) return '—';
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(price);
}

function todayStr() { return new Date().toISOString().slice(0, 10); }
function tomorrowStr() {
  const d = new Date(); d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

function StarRow({ count }: { count: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`${count} star hotel`}>
      {[1,2,3,4,5].map((i) => (
        <Star key={i} size={10} className={i <= count ? 'text-amber-400 fill-amber-400' : 'text-slate-200 fill-slate-200'} />
      ))}
    </div>
  );
}

// ── Destination dropdown ───────────────────────────────────────────────────────
function DestDropdown({
  results, loading, onSelect, visible,
}: {
  results: HotelDestination[];
  loading: boolean;
  onSelect: (r: HotelDestination) => void;
  visible: boolean;
}) {
  if (!visible) return null;
  return (
    <div className="absolute top-full left-0 right-0 mt-1.5 bg-white rounded-2xl shadow-[0_16px_48px_hsl(0_0%_0%/0.16)] border border-slate-100 z-50 overflow-hidden">
      {loading && (
        <div className="flex items-center gap-2 px-4 py-3 text-sm text-slate-500">
          <Loader2 size={13} className="animate-spin text-violet-500 shrink-0" /> Searching destinations…
        </div>
      )}
      {!loading && results.length === 0 && (
        <div className="px-4 py-3 text-sm text-slate-400 flex items-center gap-2">
          <Info size={13} className="text-slate-300" /> No destinations found. Try a city name.
        </div>
      )}
      {!loading && results.map((r) => (
        <button key={r.destId} onClick={() => onSelect(r)}
          className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-violet-50 active:bg-violet-100 transition-colors text-left border-b border-slate-50 last:border-0"
        >
          <div className="w-8 h-8 rounded-lg bg-violet-50 border border-violet-100 flex items-center justify-center shrink-0">
            <Building2 size={12} className="text-violet-500" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold text-slate-800 truncate">{r.name}</div>
            <div className="text-xs text-slate-400 truncate">{r.label !== r.name ? r.label : r.country}</div>
          </div>
          <span className="ml-auto shrink-0 text-[10px] font-bold text-slate-400 uppercase bg-slate-100 px-1.5 py-0.5 rounded-md">
            {r.destType}
          </span>
        </button>
      ))}
    </div>
  );
}

// ── Hotel photo with lazy loading + fallback ───────────────────────────────────
function HotelImage({ photo, name }: { photo: HotelPhoto | null; name: string }) {
  const [err, setErr] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (!photo || err) {
    return (
      <div className="w-full h-full bg-gradient-to-br from-violet-100 to-purple-100 flex items-center justify-center">
        <Building2 size={22} className="text-violet-300" />
      </div>
    );
  }
  return (
    <>
      {!loaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-violet-100 to-purple-100 flex items-center justify-center">
          <div className="w-6 h-6 rounded-full border-2 border-violet-300 border-t-violet-500 animate-spin" />
        </div>
      )}
      <img
        src={photo.url}
        alt={photo.description || name}
        className={`w-full h-full object-cover transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        onError={() => setErr(true)}
        onLoad={() => setLoaded(true)}
        loading="lazy"
        decoding="async"
      />
    </>
  );
}

// ── Review score badge ─────────────────────────────────────────────────────────
function ReviewBadge({ score, word }: { score: number; word: string }) {
  const color =
    score >= 9 ? 'bg-green-600 text-white' :
    score >= 8 ? 'bg-green-500 text-white' :
    score >= 7 ? 'bg-blue-500 text-white' :
    score >= 6 ? 'bg-amber-500 text-white' : 'bg-slate-200 text-slate-600';
  return (
    <div className="flex items-center gap-1.5">
      <span className={`text-xs font-bold px-1.5 py-0.5 rounded-lg tabular-nums ${color}`}>{score.toFixed(1)}</span>
      {word && <span className="text-xs text-slate-500 font-medium">{word}</span>}
    </div>
  );
}

// ── Hotel card skeleton ────────────────────────────────────────────────────────
function HotelCardSkeleton({ delay = 0 }: { delay?: number }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex animate-pulse">
        <div className="w-28 sm:w-36 h-32 bg-slate-200 shrink-0" />
        <div className="flex-1 p-4 space-y-2.5">
          <div className="h-4 bg-slate-200 rounded-lg w-3/4" />
          <div className="h-3 bg-slate-100 rounded w-1/3" />
          <div className="flex items-center gap-1.5">
            <div className="h-5 w-8 bg-slate-200 rounded-lg" />
            <div className="h-3 w-16 bg-slate-100 rounded" />
          </div>
          <div className="h-3 bg-slate-100 rounded w-1/2" />
          <div className="flex items-end justify-between pt-1">
            <div className="space-y-1">
              <div className="h-5 bg-slate-200 rounded-lg w-20" />
              <div className="h-3 bg-slate-100 rounded w-12" />
            </div>
            <div className="h-7 bg-slate-100 rounded-lg w-14" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Hotel card ─────────────────────────────────────────────────────────────────
function HotelCard({
  hotel, checkIn, checkOut, adults, rank,
}: {
  hotel: HotelListing;
  checkIn: string;
  checkOut: string;
  adults: string;
  rank: number;
}) {
  const navigate = useNavigate();
  const detailsUrl = `/hotel-details?id=${hotel.id}&checkIn=${checkIn}&checkOut=${checkOut}&adults=${adults}&currency=${hotel.currency}`;
  const isBestValue = rank === 0 && hotel.reviewScore >= 7;

  // Night count for total price
  const nightCount = checkIn && checkOut
    ? Math.max(1, Math.round((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86400000))
    : 1;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(rank * 0.035, 0.3), duration: 0.28, ease: 'easeOut' as const }}
      onClick={() => navigate(detailsUrl)}
      className="bg-white rounded-2xl border border-slate-100 hover:border-violet-200 hover:shadow-[0_8px_28px_hsl(0_0%_0%/0.09)] transition-all duration-200 overflow-hidden group cursor-pointer"
      role="article"
      aria-label={`${hotel.name} — ${formatPrice(hotel.pricePerNight, hotel.currency)} per night`}
    >
      {isBestValue && (
        <div className="flex items-center gap-1.5 px-4 py-1.5 bg-gradient-to-r from-violet-600 to-violet-500 rounded-t-2xl">
          <Star size={9} className="text-violet-200 fill-violet-200" />
          <span className="text-[10px] font-bold text-white uppercase tracking-wider">Best Value</span>
        </div>
      )}

      <div className="flex gap-0">
        {/* Photo */}
        <div className="w-28 sm:w-36 shrink-0 relative overflow-hidden self-stretch min-h-[112px]">
          <HotelImage photo={hotel.photo} name={hotel.name} />
          {hotel.dealBadge && (
            <div className="absolute top-2 left-2 bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-md z-10 leading-tight shadow-sm">
              {hotel.dealBadge}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 p-3.5 min-w-0 flex flex-col justify-between">
          <div className="min-w-0">
            <h3 className="text-sm font-bold text-slate-900 group-hover:text-violet-700 transition-colors duration-150 leading-snug line-clamp-2">
              {hotel.name}
            </h3>
            {hotel.starRating > 0 && (
              <div className="mt-0.5"><StarRow count={hotel.starRating} /></div>
            )}
          </div>

          {hotel.reviewScore > 0 && (
            <div className="mt-1.5">
              <ReviewBadge score={hotel.reviewScore} word={hotel.reviewScoreWord} />
              {hotel.reviewCount > 0 && (
                <div className="text-[10px] text-slate-400 mt-0.5">{hotel.reviewCount.toLocaleString()} reviews</div>
              )}
            </div>
          )}

          {(hotel.city || hotel.address) && (
            <div className="flex items-center gap-1 mt-1.5 text-xs text-slate-500">
              <MapPin size={10} className="text-violet-400 shrink-0" />
              <span className="truncate">{hotel.city || hotel.address}</span>
            </div>
          )}

          <div className="flex items-end justify-between mt-2.5">
            <div>
              {hotel.pricePerNight > 0 ? (
                <>
                  <div className="text-base font-bold text-slate-900 leading-none tabular-nums">
                    {formatPrice(hotel.pricePerNight, hotel.currency)}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">per night</div>
                  {nightCount > 1 && (
                    <div className="text-[10px] text-violet-600 font-semibold mt-0.5">
                      ≈ {formatPrice(hotel.pricePerNight * nightCount, hotel.currency)} total
                    </div>
                  )}
                </>
              ) : (
                <div className="text-xs text-slate-400 italic">Price unavailable</div>
              )}
            </div>
            <span className="text-violet-600 text-xs font-bold inline-flex items-center gap-0.5 group-hover:gap-1.5 transition-all duration-150 bg-violet-50 group-hover:bg-violet-100 px-2.5 py-1.5 rounded-lg">
              View <ChevronRight size={11} />
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ── Nearby station quick-picks ─────────────────────────────────────────────────
const STATION_CITIES = [
  { city: 'New Delhi',  station: 'NDLS', badge: 'bg-blue-50 text-blue-700 border-blue-100' },
  { city: 'Mumbai',     station: 'CSTM', badge: 'bg-orange-50 text-orange-700 border-orange-100' },
  { city: 'Bangalore',  station: 'SBC',  badge: 'bg-green-50 text-green-700 border-green-100' },
  { city: 'Chennai',    station: 'MAS',  badge: 'bg-violet-50 text-violet-700 border-violet-100' },
  { city: 'Kolkata',    station: 'HWH',  badge: 'bg-rose-50 text-rose-700 border-rose-100' },
  { city: 'Hyderabad',  station: 'HYB',  badge: 'bg-amber-50 text-amber-700 border-amber-100' },
];

// ── Main page ──────────────────────────────────────────────────────────────────
export default function HotelsPage() {
  const today    = todayStr();
  const tomorrow = tomorrowStr();

  const [destSelected, setDestSelected] = useState<HotelDestination | null>(null);
  const [destFocused, setDestFocused]   = useState(false);
  const destRef = useRef<HTMLDivElement>(null);

  const destAC = useAutocomplete<HotelDestination>(async (q) => {
    const r = await fetch(`/api/hotels/autocomplete?q=${encodeURIComponent(q)}`);
    const j = await r.json() as { results: HotelDestination[] };
    return j.results ?? [];
  }, 220, 5 * 60 * 1000, 'hotels-ac');

  const [checkIn, setCheckIn]   = useState(today);
  const [checkOut, setCheckOut] = useState(tomorrow);
  const [adults, setAdults]     = useState('2');
  const [rooms, setRooms]       = useState('1');

  const [hotels, setHotels]           = useState<HotelListing[]>([]);
  const [totalCount, setTotalCount]   = useState(0);
  const [searching, setSearching]     = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [sortBy, setSortBy]           = useState<'price' | 'rating'>('price');

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (destRef.current && !destRef.current.contains(e.target as Node)) setDestFocused(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const canSearch = destSelected && checkIn && checkOut;

  const handleSearch = useCallback(async () => {
    if (!canSearch) return;
    setSearching(true);
    setSearchError(null);
    setHasSearched(true);
    try {
      const params = new URLSearchParams({
        destId:   destSelected.destId,
        destType: destSelected.destType || 'city',
        checkIn,
        checkOut,
        adults,
        rooms,
        currency: 'INR',
      });
      const r = await fetch(`/api/hotels/search?${params.toString()}`);
      const j = await r.json() as { hotels?: HotelListing[]; totalCount?: number; message?: string };
      if (!r.ok) throw new Error(j.message ?? `HTTP ${r.status}`);
      setHotels(j.hotels ?? []);
      setTotalCount(j.totalCount ?? (j.hotels?.length ?? 0));
    } catch (e: unknown) {
      setSearchError(e instanceof Error ? e.message : 'Search failed. Please try again.');
      setHotels([]);
    } finally {
      setSearching(false);
    }
  }, [canSearch, destSelected, checkIn, checkOut, adults, rooms]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && canSearch && !searching) handleSearch();
  }, [canSearch, searching, handleSearch]);

  const sorted = [...hotels].sort((a, b) =>
    sortBy === 'price'
      ? (a.pricePerNight || Infinity) - (b.pricePerNight || Infinity)
      : b.reviewScore - a.reviewScore
  );

  const minPrice = hotels.filter((h) => h.pricePerNight > 0).reduce((m, h) => Math.min(m, h.pricePerNight), Infinity);

  return (
    <>
      <Helmet>
        <title>Hotels Near Railway Stations — Search & Compare | ChaloTrain</title>
        <meta name="description" content="Find and compare hotels near Indian railway stations. Search by city, check ratings, photos and prices. Perfect for train travellers planning their stay." />
        <meta name="robots" content="noindex, nofollow" />
        <link rel="canonical" href="https://chalotrain.com/hotels" />
        <meta property="og:title" content="Hotels Near Railway Stations — Search & Compare | ChaloTrain" />
        <meta property="og:description" content="Find and compare hotels near Indian railway stations. Search by city, check ratings, photos and prices. Perfect for train travellers." />
        <meta property="og:url" content="https://chalotrain.com/hotels" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Hotels Near Railway Stations | ChaloTrain" />
        <meta name="twitter:description" content="Find hotels near Indian railway stations. Compare ratings, photos and prices." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'ChaloTrain Hotel Search',
          url: 'https://chalotrain.com/hotels',
          description: 'Find hotels near Indian railway stations. Compare ratings, photos and prices.',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'Web',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
        })}</script>
      </Helmet>

      {/* ── Hero ─────────────────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-[#1a0a3e] via-[#3b1a8f] to-violet-700 pt-10 pb-0 relative overflow-hidden">
        <div className="absolute inset-0 dot-pattern" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[200px] bg-violet-400/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative container mx-auto px-4">
          {/* Breadcrumb */}
          <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-violet-300/70 text-xs mb-4">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <ChevronRight size={12} />
            <span className="text-white/80">Hotels</span>
          </nav>

          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="text-center mb-6">
            <div className="inline-flex items-center gap-2 bg-white/10 border border-white/15 rounded-full px-3 py-1 text-xs font-semibold text-white/90 mb-3 backdrop-blur-sm">
              <Building2 size={11} className="text-violet-300" />
              Hotels Near Railway Stations
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-1.5 tracking-tight">Find Hotels for Train Travellers</h1>
            <p className="text-violet-200 text-sm max-w-md mx-auto">Walking distance from major stations — perfect for early morning departures.</p>
          </motion.div>

          {/* Search card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="max-w-2xl mx-auto bg-white rounded-2xl shadow-[0_24px_64px_hsl(0_0%_0%/0.28)] overflow-visible mb-0"
          >
            <div className="p-5" onKeyDown={handleKeyDown}>
              {/* Destination autocomplete */}
              <div ref={destRef} className="relative mb-3">
                <label htmlFor="hotel-dest" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Destination / City</label>
                <div className={`flex items-center gap-2 px-3 py-2.5 border rounded-xl transition-all duration-150 ${destFocused ? 'border-violet-500 ring-2 ring-violet-500/20 bg-white shadow-sm' : 'border-slate-200 bg-slate-50 hover:border-slate-300'}`}>
                  <MapPin size={14} className="text-slate-400 shrink-0" />
                  <input
                    id="hotel-dest"
                    value={destSelected ? destSelected.label || destSelected.name : destAC.query}
                    onChange={(e) => { setDestSelected(null); destAC.setQuery(e.target.value); }}
                    onFocus={() => setDestFocused(true)}
                    placeholder="Search city, area or destination…"
                    className="flex-1 text-sm text-slate-700 placeholder-slate-400 bg-transparent focus:outline-none"
                    autoComplete="off"
                    aria-label="Hotel destination"
                    aria-expanded={destFocused && !destSelected && destAC.query.length >= 2}
                    aria-haspopup="listbox"
                  />
                  {destAC.loading && <Loader2 size={13} className="animate-spin text-violet-400 shrink-0" />}
                  {destSelected && (
                    <button onClick={() => { setDestSelected(null); destAC.setQuery(''); }}
                      className="text-slate-300 hover:text-slate-600 transition-colors shrink-0 p-0.5 rounded"
                      aria-label="Clear destination"
                    >
                      <X size={13} />
                    </button>
                  )}
                </div>
                <DestDropdown
                  results={destAC.results}
                  loading={destAC.loading}
                  visible={destFocused && !destSelected && destAC.query.length >= 2}
                  onSelect={(r) => { setDestSelected(r); destAC.setQuery(r.label || r.name); setDestFocused(false); }}
                />
              </div>

              {/* Dates + guests */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                <div>
                  <label htmlFor="hotel-checkin" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Check-in</label>
                  <div className="flex items-center gap-1.5 px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 hover:border-slate-300 focus-within:border-violet-500 focus-within:ring-2 focus-within:ring-violet-500/20 focus-within:bg-white transition-all duration-150">
                    <Calendar size={12} className="text-slate-400 shrink-0" />
                    <input id="hotel-checkin" type="date" value={checkIn} min={today}
                      onChange={(e) => { setCheckIn(e.target.value); if (e.target.value >= checkOut) { const d = new Date(e.target.value); d.setDate(d.getDate() + 1); setCheckOut(d.toISOString().slice(0, 10)); } }}
                      className="flex-1 text-xs text-slate-700 bg-transparent focus:outline-none min-w-0"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="hotel-checkout" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Check-out</label>
                  <div className="flex items-center gap-1.5 px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 hover:border-slate-300 focus-within:border-violet-500 focus-within:ring-2 focus-within:ring-violet-500/20 focus-within:bg-white transition-all duration-150">
                    <Calendar size={12} className="text-slate-400 shrink-0" />
                    <input id="hotel-checkout" type="date" value={checkOut} min={checkIn} onChange={(e) => setCheckOut(e.target.value)}
                      className="flex-1 text-xs text-slate-700 bg-transparent focus:outline-none min-w-0"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="hotel-adults" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Adults</label>
                  <div className="flex items-center gap-1.5 px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 hover:border-slate-300 focus-within:border-violet-500 focus-within:ring-2 focus-within:ring-violet-500/20 focus-within:bg-white transition-all duration-150">
                    <Users size={12} className="text-slate-400 shrink-0" />
                    <select id="hotel-adults" value={adults} onChange={(e) => setAdults(e.target.value)}
                      className="flex-1 text-xs text-slate-700 bg-transparent focus:outline-none min-w-0"
                    >
                      {[1,2,3,4].map((n) => <option key={n} value={n}>{n} Adult{n > 1 ? 's' : ''}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="hotel-rooms" className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 block">Rooms</label>
                  <div className="flex items-center gap-1.5 px-2.5 py-2.5 border border-slate-200 rounded-xl bg-slate-50 hover:border-slate-300 focus-within:border-violet-500 focus-within:ring-2 focus-within:ring-violet-500/20 focus-within:bg-white transition-all duration-150">
                    <Bed size={12} className="text-slate-400 shrink-0" />
                    <select id="hotel-rooms" value={rooms} onChange={(e) => setRooms(e.target.value)}
                      className="flex-1 text-xs text-slate-700 bg-transparent focus:outline-none min-w-0"
                    >
                      {[1,2,3].map((n) => <option key={n} value={n}>{n} Room{n > 1 ? 's' : ''}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              <button onClick={handleSearch} disabled={!canSearch || searching}
                className="w-full flex items-center justify-center gap-2 py-3 bg-violet-600 text-white text-sm font-bold rounded-xl hover:bg-violet-700 active:bg-violet-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-150 shadow-[0_4px_14px_hsl(262_83%_58%/0.35)] hover:shadow-[0_6px_20px_hsl(262_83%_58%/0.45)] hover:-translate-y-0.5"
                aria-label="Search hotels"
              >
                {searching
                  ? <><Loader2 size={15} className="animate-spin" /> Searching hotels…</>
                  : <><Search size={15} /> Search Hotels <ArrowRight size={13} /></>
                }
              </button>

              {/* Train nudge */}
              <div className="flex items-center justify-center gap-1.5 mt-2.5 text-[11px] text-slate-400">
                <Train size={10} className="text-primary" />
                <span>Also check your</span>
                <Link to="/pnr-status" className="text-primary font-semibold hover:underline">PNR status</Link>
                <span>before you check in</span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Wave */}
        <div className="relative h-8 overflow-hidden mt-4">
          <svg viewBox="0 0 1440 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="absolute bottom-0 w-full" preserveAspectRatio="none">
            <path d="M0 32L60 26C120 21 240 10 360 8C480 5 600 10 720 13C840 16 960 16 1080 13C1200 10 1320 5 1380 2L1440 0V32H0Z" fill="#f5f7ff" />
          </svg>
        </div>
      </section>

      {/* ── Results ──────────────────────────────────────────────────────────── */}
      <section className="bg-background min-h-[40vh] py-8">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* Error */}
          <AnimatePresence>
            {searchError && (
              <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl p-4 mb-6"
                role="alert"
              >
                <AlertCircle size={18} className="text-red-500 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-red-700">Search failed</div>
                  <div className="text-sm text-red-600 mt-0.5">{searchError}</div>
                  <button onClick={() => setSearchError(null)} className="mt-2 text-xs text-red-500 hover:text-red-700 underline">Dismiss</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Skeleton loading */}
          {searching && (
            <div className="space-y-3" aria-label="Loading hotels" aria-busy="true">
              {[0,1,2,3].map((i) => <HotelCardSkeleton key={i} delay={i * 60} />)}
            </div>
          )}

          {/* Results */}
          {!searching && hasSearched && !searchError && (
            <>
              {hotels.length > 0 && (
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-sm font-bold text-slate-800">
                      {totalCount > hotels.length ? `${hotels.length} of ${totalCount.toLocaleString()}` : hotels.length} hotels found
                    </div>
                    {minPrice < Infinity && (
                      <div className="flex items-center gap-1 text-xs text-green-700 font-semibold mt-0.5">
                        <TrendingDown size={11} /> From {formatPrice(minPrice)} / night
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Filter size={12} className="text-slate-400" />
                    <span className="text-xs text-slate-500 mr-0.5">Sort:</span>
                    {(['price', 'rating'] as const).map((s) => (
                      <button key={s} onClick={() => setSortBy(s)}
                        className={`text-xs px-2.5 py-1 rounded-lg font-semibold transition-all duration-150 ${sortBy === s ? 'bg-violet-600 text-white shadow-sm' : 'bg-white text-slate-600 border border-slate-200 hover:border-violet-300 hover:text-violet-600'}`}
                      >
                        {s === 'price' ? 'Price' : 'Rating'}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {sorted.map((hotel, i) => (
                  <HotelCard key={hotel.id} hotel={hotel} checkIn={checkIn} checkOut={checkOut} adults={adults} rank={i} />
                ))}
              </div>

              {hotels.length === 0 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-16">
                  <div className="w-16 h-16 rounded-2xl bg-violet-100 flex items-center justify-center mx-auto mb-4">
                    <Building2 size={28} className="text-violet-400" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-700 mb-1">No hotels found</h3>
                  <p className="text-slate-500 text-sm max-w-xs mx-auto">Try a different city or adjust your dates.</p>
                </motion.div>
              )}
            </>
          )}

          {/* Initial state */}
          {!hasSearched && !searching && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="text-center py-8 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-violet-100 flex items-center justify-center mx-auto mb-3">
                  <Building2 size={24} className="text-violet-400" />
                </div>
                <h2 className="text-base font-bold text-slate-700 mb-1">Search hotels above</h2>
                <p className="text-slate-500 text-sm">Enter a city to find hotels near railway stations.</p>
              </div>

              {/* Station quick-picks */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Zap size={13} className="text-violet-500" />
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Hotels Near Major Stations</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {STATION_CITIES.map((s) => (
                    <button key={s.station}
                      className="flex items-center gap-2.5 bg-white rounded-xl border border-slate-100 hover:border-violet-200 hover:shadow-sm px-3 py-2.5 transition-all duration-150 text-left group"
                      onClick={() => { destAC.setQuery(s.city); setDestFocused(true); }}
                    >
                      <div className="w-7 h-7 rounded-lg bg-violet-50 flex items-center justify-center shrink-0 group-hover:bg-violet-100 transition-colors">
                        <Train size={12} className="text-violet-500" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-800 truncate">{s.city}</div>
                        <div className={`text-[10px] font-bold px-1.5 py-0.5 rounded border inline-block mt-0.5 ${s.badge}`}>{s.station}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Train nudge */}
              <div className="mt-6 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-4 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shrink-0">
                  <Train size={16} className="text-white" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-800 mb-0.5">Check your train first</div>
                  <p className="text-xs text-slate-500 leading-relaxed">Confirm your PNR status and train schedule before booking a hotel near the station.</p>
                  <div className="flex items-center gap-3 mt-2">
                    <Link to="/pnr-status" className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline">
                      PNR Status <ArrowRight size={11} />
                    </Link>
                    <Link to="/train-schedule" className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline">
                      Train Schedule <ArrowRight size={11} />
                    </Link>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </section>
    </>
  );
}
