import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Clock, AlertTriangle, CheckCircle, ArrowRight, Zap } from 'lucide-react';
import PageHero from '@/components/PageHero';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import AppDownloadCTA from '@/components/AppDownloadCTA';
import { BookOpen } from 'lucide-react';

const faqs = [
  {
    question: 'What time does Tatkal booking open on IRCTC?',
    answer: 'Tatkal booking opens at 10:00 AM for AC classes (1A, 2A, 3A, CC) and at 11:00 AM for non-AC classes (SL, 2S) — one day before the date of journey. For example, for a train on April 15, Tatkal booking opens on April 14 at 10 AM (AC) or 11 AM (non-AC).',
  },
  {
    question: 'How much extra does Tatkal charge?',
    answer: 'Tatkal charges vary by class and distance. For Sleeper class, it ranges from ₹100 to ₹200. For 3AC, it ranges from ₹300 to ₹400. For 2AC, it ranges from ₹400 to ₹500. The exact amount is shown during booking on IRCTC.',
  },
  {
    question: 'Can I cancel a Tatkal ticket?',
    answer: 'Tatkal tickets have very limited cancellation refunds. If cancelled more than 24 hours before departure, you get a partial refund minus the Tatkal charge. If cancelled within 24 hours of departure, no refund is provided. Tatkal tickets are generally non-refundable.',
  },
  {
    question: 'Is there a quota limit for Tatkal tickets?',
    answer: 'Yes, Indian Railways allocates a fixed Tatkal quota for each train — typically 10% of the total seats in each class. Once this quota is exhausted, no more Tatkal tickets can be booked for that train on that date.',
  },
  {
    question: 'What is the difference between Tatkal and Premium Tatkal?',
    answer: 'Tatkal has a fixed surcharge and fixed quota. Premium Tatkal (PQWL) uses dynamic pricing — fares increase as seats fill up, similar to airline pricing. Premium Tatkal tickets are non-cancellable and non-refundable under any circumstances.',
  },
];

const tips = [
  {
    icon: Clock,
    title: 'Be Ready Before 10 AM',
    desc: 'Log in to IRCTC at least 15 minutes before 10 AM. Pre-fill your journey details, passenger info, and have your payment method ready. Every second counts.',
    color: 'bg-blue-50 text-blue-600',
  },
  {
    icon: Zap,
    title: 'Use IRCTC iMudra Wallet',
    desc: 'Pre-load money into IRCTC iMudra wallet. It processes payments instantly without OTP delays — critical when competing for limited Tatkal seats.',
    color: 'bg-orange-50 text-orange-600',
  },
  {
    icon: CheckCircle,
    title: 'Add Passengers to Master List',
    desc: 'Save all frequent travellers in your IRCTC Master List. During Tatkal booking, select from the list instead of typing details — saves 30+ seconds.',
    color: 'bg-green-50 text-green-600',
  },
  {
    icon: AlertTriangle,
    title: 'Choose the Right Class',
    desc: 'AC classes (2A, 3A) open at 10 AM and have better availability. Non-AC Sleeper opens at 11 AM. If flexible, try AC classes first for higher success rate.',
    color: 'bg-purple-50 text-purple-600',
  },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats | ChaloTrain",
  "description": "Expert tips to successfully book Tatkal train tickets on IRCTC. Timing, class selection, payment methods, and common mistakes to avoid for confirmed Tatkal seats.",
  "url": "https://chalotrain.com/blog/tatkal-ticket-booking-tips",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/tatkal-ticket-booking-tips"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogTatkalPage() {
  return (
    <>
      <title>Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats | ChaloTrain</title>
      <meta
        name="description"
        content="Expert tips to successfully book Tatkal train tickets on IRCTC. Timing, class selection, payment methods, and common mistakes to avoid for confirmed Tatkal seats."
      />
      <meta name="keywords" content="Tatkal ticket booking, IRCTC Tatkal tips, how to book Tatkal ticket, confirmed Tatkal seat, Tatkal timing" />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats" />
      <meta property="og:description" content="Expert tips to successfully book Tatkal train tickets on IRCTC. Timing, class selection, payment methods, and common mistakes to avoid for confirmed Tatkal seats." />
      <meta property="og:url" content="https://chalotrain.com/blog/tatkal-ticket-booking-tips" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats" />
      <meta name="twitter:description" content="Expert tips to successfully book Tatkal train tickets on IRCTC. Timing, class selection, payment methods, and common mistakes to avoid for confirmed Tatkal seats." />
      <meta name="robots" content="noindex, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/tatkal-ticket-booking-complete-guide" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        icon={BookOpen}
        title="Tatkal Ticket Booking Tips"
        subtitle="How to Get Confirmed Tatkal Seats — Expert Strategies"
        badge="Booking Tips · 7 min read"
      />
      <h1 className="sr-only">Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats</h1>

      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-2xl border border-slate-200 p-6 md:p-10 mb-8"
          >
            <nav className="flex items-center gap-2 text-xs text-slate-400 mb-6">
              <Link to="/" className="hover:text-primary">Home</Link>
              <span>/</span>
              <Link to="/blog" className="hover:text-primary">Blog</Link>
              <span>/</span>
              <span className="text-slate-600">Tatkal Booking Tips</span>
            </nav>

            <div className="flex items-center gap-3 mb-6">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-orange-100 text-orange-700">Booking Tips</span>
              <span className="flex items-center gap-1 text-xs text-slate-400"><Clock size={11} /> 7 min read</span>
              <span className="text-xs text-slate-400">April 8, 2026</span>
            </div>

            <p className="text-slate-600 leading-relaxed mb-6">
              Tatkal tickets are a lifesaver when you need to travel urgently and regular quota tickets are sold out. But booking a Tatkal ticket on IRCTC is a race against thousands of other users — all trying to grab limited seats the moment booking opens. This guide gives you the edge you need.
            </p>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-8 text-sm text-amber-800">
              <strong>Key Timing:</strong> AC Tatkal opens at <strong>10:00 AM</strong> and Non-AC Tatkal opens at <strong>11:00 AM</strong> — one day before the journey date. Be logged in and ready before these times.
            </div>

            {/* What is Tatkal */}
            <h2 className="text-xl font-bold text-slate-900 mb-3 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              What is Tatkal Booking?
            </h2>
            <p className="text-slate-600 leading-relaxed mb-6">
              Tatkal (meaning "immediate" in Hindi) is a special quota introduced by Indian Railways for last-minute travellers. It allows you to book tickets one day before the journey date at a higher price. Each train has a fixed Tatkal quota — once it's gone, it's gone. The extra charge (Tatkal surcharge) is non-refundable in most cases.
            </p>

            {/* Tips */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Top Tips for Successful Tatkal Booking
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {tips.map((tip) => (
                <div key={tip.title} className="border border-slate-200 rounded-xl p-4">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${tip.color}`}>
                    <tip.icon size={18} />
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{tip.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">{tip.desc}</p>
                </div>
              ))}
            </div>

            {/* Step by step */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Step-by-Step Tatkal Booking Process
            </h2>
            <ol className="space-y-4 mb-8">
              {[
                { step: '1', title: 'Log in to IRCTC before 9:45 AM', desc: 'Open irctc.co.in and log in. If you wait until 10 AM, the server will be overloaded and login may fail.' },
                { step: '2', title: 'Search for your train', desc: 'Enter source, destination, and journey date. Select "Tatkal" quota from the quota dropdown before searching.' },
                { step: '3', title: 'Select your train and class', desc: 'Choose the train and class. Check Tatkal availability — it shows TQ (Tatkal Quota) seats available.' },
                { step: '4', title: 'Fill passenger details quickly', desc: 'Use the Master List to auto-fill passenger details. Avoid typing manually — it wastes precious seconds.' },
                { step: '5', title: 'Pay instantly with iMudra or UPI', desc: 'Select IRCTC iMudra wallet or a saved UPI ID for fastest payment. Avoid net banking — it redirects to bank pages and is slow.' },
                { step: '6', title: 'Complete CAPTCHA and confirm', desc: 'Solve the CAPTCHA quickly and click "Confirm Booking." Your ticket is booked once you see the confirmation page.' },
              ].map((item) => (
                <li key={item.step} className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-orange-500 text-white text-sm font-bold flex items-center justify-center shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900 text-sm mb-1">{item.title}</h4>
                    <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
                  </div>
                </li>
              ))}
            </ol>

            {/* Common mistakes */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Common Mistakes to Avoid
            </h2>
            <ul className="space-y-3 mb-8">
              {[
                'Waiting until exactly 10 AM to log in — IRCTC servers get overloaded. Log in 15 minutes early.',
                'Using net banking for payment — it redirects to your bank\'s site and takes too long.',
                'Not having the Master List set up — typing passenger details manually loses you 30-60 seconds.',
                'Selecting the wrong quota — make sure "Tatkal" is selected, not "General".',
                'Trying to book on mobile data — use a stable WiFi connection for faster page loads.',
                'Booking Premium Tatkal without understanding it\'s non-refundable under all circumstances.',
              ].map((mistake) => (
                <li key={mistake} className="flex items-start gap-2 text-sm text-slate-600">
                  <AlertTriangle size={15} className="text-red-400 mt-0.5 shrink-0" />
                  {mistake}
                </li>
              ))}
            </ul>

            {/* Check seat availability CTA */}
            <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl p-6 text-white text-center mb-8">
              <h3 className="text-lg font-bold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Check Seat Availability Before Booking</h3>
              <p className="text-orange-100 text-sm mb-4">See how many Tatkal seats are available before you start the booking process.</p>
              <Link to="/seat-availability" className="inline-flex items-center gap-2 px-6 py-2.5 bg-white text-orange-600 text-sm font-bold rounded-xl hover:bg-orange-50 transition-colors">
                Check Availability <ArrowRight size={14} />
              </Link>
            </div>

            <AppDownloadCTA />

            <SocialShareBar
              url="https://chalotrain.com/blog/tatkal-ticket-booking-tips"
              title="Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats"
            />
          </motion.article>

          <FAQSection items={faqs} />
          <RelatedTools currentHref="/blog/tatkal-ticket-booking-tips" />
        </div>
      </section>
    </>
  );
}
