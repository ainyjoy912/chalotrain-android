import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Armchair, CheckCircle, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'How far in advance can I check seat availability?', answer: 'You can check seat availability for up to 120 days in advance on IRCTC, though bookings open only 60 days before departure. ChaloTrain shows availability for the next 7 days from your selected date.' },
  { question: 'What does AVL 42 mean in seat availability?', answer: 'AVL 42 means 42 seats are currently available in that class and quota for that date. The number decreases as more passengers book. Book quickly when you see high availability numbers.' },
  { question: 'Is seat availability the same on all booking platforms?', answer: 'Yes. All authorized booking platforms (IRCTC, MakeMyTrip, Cleartrip, etc.) draw from the same Indian Railways inventory. The availability you see on ChaloTrain reflects the same data.' },
  { question: 'Can I check availability for multiple classes at once?', answer: 'Yes. ChaloTrain\'s Seat Availability tool shows a date-wise grid for your selected class. To compare multiple classes, run separate searches for each class (e.g., 3A, SL, 2A).' },
  { question: 'Why does seat availability change so quickly?', answer: 'Multiple users are booking simultaneously. Availability can drop from 50 to 0 within minutes on popular trains and dates. If you see availability, book immediately rather than waiting.' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Check Seat Availability in Indian Trains — Full Guide | ChaloTrain",
  "description": "Learn how to check seat availability for any Indian train across all classes and quotas. Understand AVL, RAC, WL statuses and plan your booking smartly.",
  "url": "https://chalotrain.com/blog/how-to-check-seat-availability",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-check-seat-availability"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogCheckSeatAvailability() {
  return (
    <>
      <title>How to Check Seat Availability in Indian Trains — Full Guide | ChaloTrain</title>
      <meta name="description" content="Learn how to check seat availability for any Indian train across all classes and quotas. Understand AVL, RAC, WL statuses and plan your booking smartly." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Check Seat Availability in Indian Trains — Full Guide" />
      <meta property="og:description" content="Learn how to check seat availability for any Indian train across all classes and quotas. Understand AVL, RAC, WL statuses and plan your booking smartly." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-check-seat-availability" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Check Seat Availability in Indian Trains — Full Guide" />
      <meta name="twitter:description" content="Learn how to check seat availability for any Indian train across all classes and quotas. Understand AVL, RAC, WL statuses and plan your booking smartly." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-check-seat-availability" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">How to Check Seat Availability</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-violet-100 text-violet-700 px-3 py-1 rounded-full font-semibold">Seat Availability</span>
              <span className="text-xs text-slate-400">May 2026 • 7 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              How to Check Seat Availability in Indian Trains — Full Guide
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              Checking seat availability before booking saves you from getting stuck with a waitlisted ticket. This guide explains how to check availability, what the status codes mean, and how to use the information to book smartly.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Why Check Seat Availability Before Booking?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Many travellers make the mistake of booking a ticket without checking availability first, only to end up with a high waitlist number that never gets confirmed. Checking availability in advance helps you:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li>Choose the best date with confirmed seats</li>
              <li>Compare availability across different classes (SL, 3A, 2A)</li>
              <li>Decide between General quota and Tatkal quota</li>
              <li>Find alternate trains if your preferred train is full</li>
              <li>Plan your journey without the anxiety of a waitlisted ticket</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Check Seat Availability on ChaloTrain</h2>
            <ol className="list-none space-y-3 mb-6">
              {[
                'Go to the Seat Availability page on ChaloTrain.',
                'Enter the 5-digit train number (e.g., 12301 for Howrah Rajdhani).',
                'Enter the source station code (e.g., HWH for Howrah) and destination station code (e.g., NDLS for New Delhi).',
                'Select your travel class (1A, 2A, 3A, SL, CC, 2S, or 3E).',
                'Select your quota (General, Tatkal, Ladies, Senior Citizen, etc.).',
                'Choose your journey date and click "Check Availability".',
                'View the date-wise availability grid showing status for the next 7 days.',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <span className="text-slate-600 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Understanding Availability Status Codes</h2>
            <div className="space-y-3 mb-6">
              {[
                { status: 'AVL 42', color: 'bg-green-50 border-green-200', badge: 'bg-green-100 text-green-700', title: 'Available', desc: 'Seats are available. The number indicates how many seats remain. Book immediately — availability can drop fast on popular trains.' },
                { status: 'RAC 5', color: 'bg-yellow-50 border-yellow-200', badge: 'bg-yellow-100 text-yellow-700', title: 'Reservation Against Cancellation', desc: 'No confirmed berths left, but RAC berths are available. You can board the train and share a side-lower berth. You may get a full berth if someone cancels.' },
                { status: 'WL 12', color: 'bg-red-50 border-red-200', badge: 'bg-red-100 text-red-700', title: 'Waitlist', desc: 'You are on the waiting list. For e-tickets, if the status remains WL at chart preparation, the ticket is auto-cancelled with a full refund. The lower the WL number, the better the chance of confirmation.' },
                { status: 'REGRET', color: 'bg-slate-50 border-slate-200', badge: 'bg-slate-100 text-slate-700', title: 'Fully Booked', desc: 'No seats, RAC, or waitlist available. Try a different date, class, or train.' },
              ].map(({ status, color, badge, title, desc }) => (
                <div key={status} className={`rounded-xl border p-4 ${color}`}>
                  <div className="flex items-start gap-3">
                    <CheckCircle size={18} className="text-slate-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${badge}`}>{status}</span>
                        <span className="font-semibold text-slate-800 text-sm">{title}</span>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Understanding Quotas</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Indian Railways divides seats into multiple quotas. Each quota has its own availability pool:
            </p>
            <div className="overflow-x-auto mb-6">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Quota</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Code</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Who Can Book</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Opens</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { quota: 'General', code: 'GN', who: 'All passengers', opens: '60 days before' },
                    { quota: 'Tatkal', code: 'TQ', who: 'All passengers (higher fare)', opens: '1 day before (10/11 AM)' },
                    { quota: 'Premium Tatkal', code: 'PT', who: 'All passengers (dynamic fare)', opens: '1 day before (10/11 AM)' },
                    { quota: 'Ladies', code: 'LD', who: 'Women passengers only', opens: '60 days before' },
                    { quota: 'Senior Citizen', code: 'SS', who: 'Men 60+, Women 58+', opens: '60 days before' },
                    { quota: 'Divyaang', code: 'HP', who: 'Persons with disability', opens: '60 days before' },
                  ].map(({ quota, code, who, opens }) => (
                    <tr key={code} className="hover:bg-slate-50">
                      <td className="p-3 border border-slate-200 font-medium text-slate-700">{quota}</td>
                      <td className="p-3 border border-slate-200 font-bold text-primary">{code}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{who}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{opens}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Smart Booking Strategies</h2>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li><strong>Book on Day 1:</strong> Set a reminder for exactly 60 days before your journey. Log in to IRCTC at 8 AM when bookings open.</li>
              <li><strong>Be flexible with dates:</strong> Use ChaloTrain's date-wise grid to find a date with better availability.</li>
              <li><strong>Try different classes:</strong> If 3A is full, check 2A or SL availability.</li>
              <li><strong>Use Tatkal as backup:</strong> If General quota is full, Tatkal opens 1 day before departure with guaranteed seats (at a higher fare).</li>
              <li><strong>Check multiple trains:</strong> Use <Link to="/train-search" className="text-primary underline font-medium">Train Search</Link> to find alternate trains on the same route.</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Check Seat Availability Now</p>
              <p className="text-sm text-slate-600 mb-3">View availability across all classes and dates before booking on IRCTC.</p>
              <Link to="/seat-availability" className="inline-flex items-center gap-2 bg-primary text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                <Armchair size={16} /> Check Seat Availability
              </Link>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="How to Check Seat Availability in Indian Trains — Full Guide" url="https://chalotrain.com/blog/how-to-check-seat-availability" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/how-to-check-seat-availability" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
