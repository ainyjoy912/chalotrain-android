import { motion } from 'motion/react';
import { Train, Users, Armchair, Sparkles, Shield } from 'lucide-react';
import PageHero from '@/components/PageHero';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import LastUpdatedBadge from '@/components/LastUpdatedBadge';
import AppDownloadCTA from '@/components/AppDownloadCTA';

const faqs = [
  { question: 'Which is the cheapest class in Indian Railways?', answer: 'Second Sitting (2S) is the cheapest class, followed by Sleeper Class (SL). 2S has cushioned seats without berths, while SL has sleeping berths but no AC. Both are budget-friendly options for short to medium journeys.' },
  { question: 'Is 3AC better than 2AC?', answer: '2AC is better than 3AC in terms of comfort. 2AC has only 4 berths per bay (more spacious), better bedding, and fewer passengers. 3AC has 6 berths per bay and is more crowded. However, 3AC is significantly cheaper and offers good value for money.' },
  { question: 'Can I upgrade my ticket to a higher class?', answer: 'Yes, you can upgrade your ticket at the reservation counter or through the IRCTC website/app, subject to availability. You need to pay the fare difference. Upgrades are not available for all trains and must be done before boarding.' },
  { question: 'Which class is best for overnight journeys?', answer: 'For overnight journeys, AC classes (3AC, 2AC, or 1AC) are recommended for comfort and security. 3AC offers the best value for money, while 2AC provides more space. Sleeper Class is also popular for budget travelers on overnight trips.' },
  { question: 'What is the difference between Chair Car and Executive Chair Car?', answer: 'Chair Car (CC) has standard cushioned seats with AC, suitable for day journeys. Executive Chair Car (EC) offers premium reclining seats with more legroom, better upholstery, and complimentary meals on some trains. EC is available only on select premium trains like Shatabdi and Vande Bharat.' },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained (2026)",
  "description": "Complete guide to Indian Railway classes: 1AC, 2AC, 3AC, Sleeper, Chair Car, and more. Compare facilities, fares, and choose the best class for your journey.",
  "url": "https://chalotrain.com/blog/indian-railway-classes-guide",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/indian-railway-classes-guide"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function IndianRailwayClassesGuidePage() {
  return (
    <>
      <title>Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained (2026)</title>
      <meta name="description" content="Complete guide to Indian Railway classes: 1AC, 2AC, 3AC, Sleeper, Chair Car, and more. Compare facilities, fares, and choose the best class for your journey." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/indian-railway-classes-guide" />
      
      {/* Open Graph */}
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained (2026)" />
      <meta property="og:description" content="Complete guide to Indian Railway classes: 1AC, 2AC, 3AC, Sleeper, Chair Car, and more. Compare facilities, fares, and choose the best class for your journey." />
      <meta property="og:url" content="https://chalotrain.com/blog/indian-railway-classes-guide" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained (2026)" />
      <meta name="twitter:description" content="Complete guide to Indian Railway classes: 1AC, 2AC, 3AC, Sleeper, Chair Car, and more. Compare facilities, fares, and choose the best class for your journey." />
      <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />

      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        title="Indian Railway Classes Guide"
        subtitle="Complete comparison of 1AC, 2AC, 3AC, Sleeper, and Chair Car classes"
        icon={Train}
      />
      <h1 className="sr-only">Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained (2026)</h1>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <motion.article
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          className="prose prose-slate max-w-none"
        >
          {/* Last Updated Badge */}
          <LastUpdatedBadge label="2026-04-20" />

          {/* Introduction */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8 border border-blue-100">
            <p className="text-lg text-slate-700 leading-relaxed mb-0">
              Indian Railways offers <strong>8 different travel classes</strong> to suit every budget and comfort preference. From luxurious 1AC to economical Sleeper Class, understanding the differences helps you choose the right class for your journey. This comprehensive guide covers facilities, fares, and tips for each class.
            </p>
          </div>

          {/* AC First Class (1AC) */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-amber-500 to-orange-500 p-3 rounded-xl">
                <Sparkles className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                AC First Class (1AC) - Premium Luxury
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-3">Facilities & Features</h3>
              <ul className="space-y-2 text-slate-700">
                <li>✅ <strong>Private cabins</strong> with 2 or 4 berths (lockable doors)</li>
                <li>✅ <strong>Premium bedding</strong> with pillows, blankets, and towels</li>
                <li>✅ <strong>Individual reading lights</strong> and charging points</li>
                <li>✅ <strong>Complimentary meals</strong> on Rajdhani/Shatabdi trains</li>
                <li>✅ <strong>Attendant service</strong> for assistance</li>
                <li>✅ <strong>Spacious luggage area</strong> under lower berth</li>
              </ul>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-6">
              <p className="text-sm text-amber-900 mb-2"><strong>💰 Fare Range:</strong> ₹3,000 - ₹6,000 (varies by distance and train type)</p>
              <p className="text-sm text-amber-900 mb-0"><strong>🎯 Best For:</strong> Business travelers, families seeking privacy, long-distance overnight journeys</p>
            </div>

            <p className="text-slate-700">
              <strong>1AC is the most luxurious class</strong> in Indian Railways, offering maximum privacy and comfort. Each cabin has only 2-4 passengers, making it ideal for families or those who value personal space. The fare is significantly higher than other classes, but the premium experience justifies the cost for long journeys.
            </p>
          </section>

          {/* AC 2-Tier (2AC) */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-blue-500 to-indigo-500 p-3 rounded-xl">
                <Shield className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                AC 2-Tier (2AC) - Comfort & Space
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-3">Facilities & Features</h3>
              <ul className="space-y-2 text-slate-700">
                <li>✅ <strong>Open bays</strong> with 4 berths per bay (2 lower, 2 upper)</li>
                <li>✅ <strong>Side berths</strong> available (2 per coach)</li>
                <li>✅ <strong>Good bedding</strong> with sheets, pillows, and blankets</li>
                <li>✅ <strong>Curtains for privacy</strong> on each berth</li>
                <li>✅ <strong>Charging points</strong> near each berth</li>
                <li>✅ <strong>More spacious</strong> than 3AC with fewer passengers</li>
              </ul>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-5 mb-6">
              <p className="text-sm text-blue-900 mb-2"><strong>💰 Fare Range:</strong> ₹1,500 - ₹3,500 (varies by distance and train type)</p>
              <p className="text-sm text-blue-900 mb-0"><strong>🎯 Best For:</strong> Comfortable overnight travel, senior citizens, solo travelers seeking space</p>
            </div>

            <p className="text-slate-700">
              <strong>2AC offers the best balance of comfort and value.</strong> With only 4 berths per bay, it's less crowded than 3AC. The curtains provide decent privacy, and the bedding quality is excellent. This class is popular among business travelers and families who want comfort without the premium 1AC price.
            </p>
          </section>

          {/* AC 3-Tier (3AC) */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-green-500 to-teal-500 p-3 rounded-xl">
                <Armchair className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                AC 3-Tier (3AC) - Best Value for Money
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-3">Facilities & Features</h3>
              <ul className="space-y-2 text-slate-700">
                <li>✅ <strong>Open bays</strong> with 6 berths per bay (3 tiers)</li>
                <li>✅ <strong>Side berths</strong> available (2 per coach)</li>
                <li>✅ <strong>Standard bedding</strong> with sheets and blankets</li>
                <li>✅ <strong>Curtains for privacy</strong> on each berth</li>
                <li>✅ <strong>Charging points</strong> available</li>
                <li>✅ <strong>Most popular AC class</strong> in India</li>
              </ul>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-xl p-5 mb-6">
              <p className="text-sm text-green-900 mb-2"><strong>💰 Fare Range:</strong> ₹1,000 - ₹2,500 (varies by distance and train type)</p>
              <p className="text-sm text-green-900 mb-0"><strong>🎯 Best For:</strong> Budget-conscious travelers, students, families, medium to long journeys</p>
            </div>

            <p className="text-slate-700">
              <strong>3AC is the most popular AC class</strong> due to its excellent value for money. While more crowded than 2AC (6 berths per bay), it still offers air conditioning, clean bedding, and decent comfort. The middle berth can be folded during the day, providing seating space. Ideal for overnight journeys when you want AC comfort without breaking the bank.
            </p>
          </section>

          {/* Sleeper Class (SL) */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-orange-500 to-red-500 p-3 rounded-xl">
                <Users className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Sleeper Class (SL) - Budget Friendly
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-3">Facilities & Features</h3>
              <ul className="space-y-2 text-slate-700">
                <li>✅ <strong>Open bays</strong> with 6 berths per bay (3 tiers)</li>
                <li>✅ <strong>Side berths</strong> available (2 per coach)</li>
                <li>✅ <strong>Basic bedding</strong> (sheets and thin blankets)</li>
                <li>✅ <strong>No air conditioning</strong> (fans and open windows)</li>
                <li>✅ <strong>Charging points</strong> available</li>
                <li>✅ <strong>Most economical</strong> for long-distance travel</li>
              </ul>
            </div>

            <div className="bg-orange-50 border border-orange-200 rounded-xl p-5 mb-6">
              <p className="text-sm text-orange-900 mb-2"><strong>💰 Fare Range:</strong> ₹300 - ₹800 (varies by distance)</p>
              <p className="text-sm text-orange-900 mb-0"><strong>🎯 Best For:</strong> Budget travelers, students, short to medium journeys, summer travel</p>
            </div>

            <p className="text-slate-700">
              <strong>Sleeper Class is the backbone of Indian Railways,</strong> carrying millions of passengers daily. While it lacks AC, it's clean, safe, and comfortable for most journeys. The open windows provide natural ventilation, making it pleasant during cooler months. Bedding is basic but adequate. This class offers the best value for budget-conscious travelers.
            </p>
          </section>

          {/* Chair Car (CC) */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Train className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Chair Car (CC) & Executive Chair Car (EC)
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-3">Chair Car (CC) Features</h3>
              <ul className="space-y-2 text-slate-700 mb-4">
                <li>✅ <strong>Cushioned seats</strong> with armrests</li>
                <li>✅ <strong>Air conditioning</strong> throughout</li>
                <li>✅ <strong>No sleeping berths</strong> (seating only)</li>
                <li>✅ <strong>Ideal for day journeys</strong> (4-8 hours)</li>
                <li>✅ <strong>Available on Shatabdi</strong> and intercity trains</li>
              </ul>

              <h3 className="text-lg font-semibold text-slate-800 mb-3">Executive Chair Car (EC) Features</h3>
              <ul className="space-y-2 text-slate-700">
                <li>✅ <strong>Premium reclining seats</strong> with extra legroom</li>
                <li>✅ <strong>Complimentary meals</strong> and beverages</li>
                <li>✅ <strong>Better upholstery</strong> and comfort</li>
                <li>✅ <strong>Individual reading lights</strong> and charging points</li>
                <li>✅ <strong>Available on select premium trains</strong> (Shatabdi, Vande Bharat)</li>
              </ul>
            </div>

            <div className="bg-purple-50 border border-purple-200 rounded-xl p-5 mb-6">
              <p className="text-sm text-purple-900 mb-2"><strong>💰 Fare Range:</strong> CC: ₹400-₹1,200 | EC: ₹800-₹2,000</p>
              <p className="text-sm text-purple-900 mb-0"><strong>🎯 Best For:</strong> Day journeys, business travel, intercity commutes</p>
            </div>

            <p className="text-slate-700">
              <strong>Chair Car classes are designed for day travel</strong> on premium trains like Shatabdi Express and Vande Bharat. CC offers comfortable seating with AC, while EC provides a premium experience with reclining seats and complimentary meals. These classes are not suitable for overnight journeys as there are no sleeping berths.
            </p>
          </section>

          {/* Comparison Table */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Quick Comparison Table
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse bg-white rounded-xl overflow-hidden shadow-sm">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                    <th className="px-4 py-3 text-left text-sm font-semibold">Class</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">AC</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Berths/Bay</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Privacy</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Fare</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">1AC</td>
                    <td className="px-4 py-3 text-slate-700">✅ Yes</td>
                    <td className="px-4 py-3 text-slate-700">2-4 (Private)</td>
                    <td className="px-4 py-3 text-slate-700">⭐⭐⭐⭐⭐</td>
                    <td className="px-4 py-3 text-slate-700">Highest</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">2AC</td>
                    <td className="px-4 py-3 text-slate-700">✅ Yes</td>
                    <td className="px-4 py-3 text-slate-700">4 (Open)</td>
                    <td className="px-4 py-3 text-slate-700">⭐⭐⭐⭐</td>
                    <td className="px-4 py-3 text-slate-700">High</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">3AC</td>
                    <td className="px-4 py-3 text-slate-700">✅ Yes</td>
                    <td className="px-4 py-3 text-slate-700">6 (Open)</td>
                    <td className="px-4 py-3 text-slate-700">⭐⭐⭐</td>
                    <td className="px-4 py-3 text-slate-700">Medium</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">SL</td>
                    <td className="px-4 py-3 text-slate-700">❌ No</td>
                    <td className="px-4 py-3 text-slate-700">6 (Open)</td>
                    <td className="px-4 py-3 text-slate-700">⭐⭐</td>
                    <td className="px-4 py-3 text-slate-700">Low</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">CC</td>
                    <td className="px-4 py-3 text-slate-700">✅ Yes</td>
                    <td className="px-4 py-3 text-slate-700">Seats Only</td>
                    <td className="px-4 py-3 text-slate-700">⭐⭐⭐</td>
                    <td className="px-4 py-3 text-slate-700">Medium</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">EC</td>
                    <td className="px-4 py-3 text-slate-700">✅ Yes</td>
                    <td className="px-4 py-3 text-slate-700">Seats Only</td>
                    <td className="px-4 py-3 text-slate-700">⭐⭐⭐⭐</td>
                    <td className="px-4 py-3 text-slate-700">High</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* Tips Section */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Tips for Choosing the Right Class
            </h2>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-blue-900 mb-3">For Overnight Journeys</h3>
                <ul className="space-y-2 text-blue-800 text-sm">
                  <li>✅ Choose AC classes (3AC, 2AC, or 1AC) for comfort</li>
                  <li>✅ 3AC offers best value for money</li>
                  <li>✅ 2AC if you prefer more space and less crowding</li>
                  <li>✅ Sleeper Class works well in winter months</li>
                </ul>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-green-900 mb-3">For Day Journeys</h3>
                <ul className="space-y-2 text-green-800 text-sm">
                  <li>✅ Chair Car (CC) is ideal for 4-8 hour journeys</li>
                  <li>✅ Executive Chair Car for premium comfort</li>
                  <li>✅ Second Sitting (2S) for short budget trips</li>
                  <li>✅ Avoid sleeper berths for day travel</li>
                </ul>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-orange-900 mb-3">For Budget Travel</h3>
                <ul className="space-y-2 text-orange-800 text-sm">
                  <li>✅ Sleeper Class offers best value for long journeys</li>
                  <li>✅ Book early to get confirmed tickets</li>
                  <li>✅ Travel during off-peak seasons for availability</li>
                  <li>✅ Consider 3AC for overnight comfort at reasonable cost</li>
                </ul>
              </div>

              <div className="bg-purple-50 border border-purple-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-purple-900 mb-3">For Families</h3>
                <ul className="space-y-2 text-purple-800 text-sm">
                  <li>✅ 1AC provides maximum privacy with lockable cabins</li>
                  <li>✅ 2AC offers good space with 4 berths per bay</li>
                  <li>✅ Book lower berths for elderly and children</li>
                  <li>✅ Side berths offer more privacy in AC classes</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Conclusion */}
          <section className="mb-12">
            <div className="bg-gradient-to-br from-blue-900 to-indigo-900 text-white rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                Final Recommendations
              </h2>
              <div className="space-y-3 text-blue-100">
                <p><strong className="text-white">Best Overall Value:</strong> 3AC - Perfect balance of comfort and affordability</p>
                <p><strong className="text-white">Most Comfortable:</strong> 1AC - Premium luxury with private cabins</p>
                <p><strong className="text-white">Budget Friendly:</strong> Sleeper Class - Economical for long journeys</p>
                <p><strong className="text-white">Day Travel:</strong> Chair Car (CC) - Comfortable seating for short trips</p>
                <p><strong className="text-white">Business Travel:</strong> 2AC or Executive Chair Car - Professional and comfortable</p>
              </div>
            </div>
          </section>

          {/* CTA */}
          <AppDownloadCTA />
        </motion.article>

        {/* Social Share */}
        <div className="mt-12">
          <SocialShareBar
            title="Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained"
            url="https://chalotrain.com/blog/indian-railway-classes-guide"
          />
        </div>

        {/* Related Tools */}
        <div className="mt-12">
          <RelatedTools currentHref="/blog" />
        </div>

        {/* FAQ Section */}
        <div className="mt-12">
          <FAQSection items={faqs} />
        </div>
      </div>
    </>
  );
}
