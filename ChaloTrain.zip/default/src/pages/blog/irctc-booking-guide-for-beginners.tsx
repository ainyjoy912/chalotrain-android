import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Clock, CheckCircle, ArrowRight, Shield, CreditCard } from 'lucide-react';
import PageHero from '@/components/PageHero';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import AppDownloadCTA from '@/components/AppDownloadCTA';
import { BookOpen } from 'lucide-react';

const faqs = [
  {
    question: 'Is IRCTC registration free?',
    answer: 'Yes, creating an IRCTC account is completely free. You just need a valid email address and mobile number for OTP verification. There are no registration fees or subscription charges for basic ticket booking.',
  },
  {
    question: 'How many tickets can I book per month on IRCTC?',
    answer: 'An individual IRCTC user can book up to 6 tickets per month without Aadhaar linking, and up to 12 tickets per month after linking their Aadhaar card. Each booking can include up to 6 passengers.',
  },
  {
    question: 'What payment methods does IRCTC accept?',
    answer: 'IRCTC accepts UPI (PhonePe, Google Pay, Paytm, BHIM), debit/credit cards (Visa, Mastercard, RuPay), net banking, IRCTC iMudra wallet, and EMI options. UPI and iMudra wallet are the fastest payment methods.',
  },
  {
    question: 'How do I download my e-ticket from IRCTC?',
    answer: 'After booking, go to IRCTC → "My Transactions" → "Booked Ticket History" → select your booking → click "Print E-Ticket." You can also find the ticket in your registered email. The e-ticket PDF is your valid travel document.',
  },
  {
    question: 'Can I book tickets for someone else on IRCTC?',
    answer: 'Yes, you can book tickets for family members, friends, or colleagues using your IRCTC account. Simply enter their details (name, age, gender, ID proof) in the passenger section. You can save frequent travellers in the Master List for quick booking.',
  },
];

const steps = [
  {
    step: '1',
    title: 'Create Your IRCTC Account',
    desc: 'Visit irctc.co.in and click "Register." Fill in your name, email, mobile number, and create a username and password. Verify your email and mobile via OTP. Your account is ready.',
    tips: ['Use a strong password with letters, numbers, and symbols', 'Keep your username simple — you\'ll type it often', 'Link your Aadhaar to increase monthly booking limit to 12'],
  },
  {
    step: '2',
    title: 'Search for Your Train',
    desc: 'Log in and click "Book Ticket." Enter your From station, To station, and journey date. Select your preferred class and quota. Click "Search Trains" to see all available options.',
    tips: ['Use station codes for faster search (e.g., NDLS for New Delhi)', 'Check "Flexible with Date" to see availability on nearby dates', 'Use ChaloTrain\'s Train Search for a faster overview'],
  },
  {
    step: '3',
    title: 'Select Your Train and Class',
    desc: 'Browse the list of trains. Each train shows availability across classes (SL, 3A, 2A, 1A, CC). Green means available, yellow means RAC, red means waitlisted. Click on your preferred train.',
    tips: ['Check the train\'s departure and arrival times carefully', 'Compare fares across classes — 3AC is often the best value', 'Avoid trains with very long WL numbers'],
  },
  {
    step: '4',
    title: 'Enter Passenger Details',
    desc: 'Add passenger details: name, age, gender, and berth preference (lower/middle/upper/side lower/side upper). You can add up to 6 passengers per booking. Use the Master List to save time.',
    tips: ['Name must match your government ID exactly', 'Senior citizens (60+) get discounts — select the correct category', 'Lower berth is preferred for elderly passengers'],
  },
  {
    step: '5',
    title: 'Choose Your Berth (Optional)',
    desc: 'IRCTC allows you to select a specific berth from the coach layout. This is optional but recommended if you have preferences. Lower berths are most popular and fill up quickly.',
    tips: ['Lower berth is easiest to access', 'Side lower berth has less privacy but more space during day', 'Upper berth is preferred by those who sleep early'],
  },
  {
    step: '6',
    title: 'Make Payment',
    desc: 'Select your payment method. UPI is the fastest — scan the QR code or enter your UPI ID. IRCTC iMudra wallet is even faster as it requires no OTP. Complete payment within the time limit (10 minutes).',
    tips: ['Pre-load iMudra wallet for Tatkal bookings', 'Have your UPI app open before starting payment', 'Avoid net banking — it\'s slower and times out more often'],
  },
  {
    step: '7',
    title: 'Download Your E-Ticket',
    desc: 'After successful payment, your e-ticket is generated. Download the PDF from "My Transactions" or check your email. Print it or save it on your phone — it\'s your valid travel document.',
    tips: ['Save the e-ticket offline in case of no internet at the station', 'Carry a valid photo ID matching the passenger name', 'The PNR number on the ticket is your booking reference'],
  },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "IRCTC Registration & First Booking Guide for Beginners 2026 | ChaloTrain",
  "description": "New to IRCTC? Complete beginner's guide: account creation, train search, seat selection, payment, and ticket download on IRCTC. Step-by-step with tips for 2026.",
  "url": "https://chalotrain.com/blog/irctc-booking-guide-for-beginners",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/irctc-booking-guide-for-beginners"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogIRCTCGuidePage() {
  return (
    <>
      <title>IRCTC Registration & First Booking Guide for Beginners 2026 | ChaloTrain</title>
      <meta
        name="description"
        content="New to IRCTC? Complete beginner's guide: account creation, train search, seat selection, payment, and ticket download on IRCTC. Step-by-step with tips for 2026."
      />
      <meta name="keywords" content="IRCTC booking guide, how to book train ticket IRCTC, IRCTC for beginners, IRCTC registration, online train ticket booking India" />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="IRCTC Registration & First Booking Guide for Beginners 2026" />
      <meta property="og:description" content="New to IRCTC? Complete beginner's guide: account creation, train search, seat selection, payment, and ticket download on IRCTC. Step-by-step with tips for 2026." />
      <meta property="og:url" content="https://chalotrain.com/blog/irctc-booking-guide-for-beginners" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="IRCTC Registration & First Booking Guide for Beginners 2026" />
      <meta name="twitter:description" content="New to IRCTC? Complete beginner's guide: account creation, train search, seat selection, payment, and ticket download on IRCTC. Step-by-step with tips for 2026." />
      <meta name="robots" content="noindex, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/irctc-complete-booking-guide" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        icon={BookOpen}
        title="IRCTC Booking Guide for Beginners"
        subtitle="Complete Step-by-Step Guide to Book Train Tickets Online in 2026"
        badge="Guides · 10 min read"
      />
      <h1 className="sr-only">IRCTC Registration &amp; First Booking Guide for Beginners 2026</h1>

      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-2xl border border-slate-200 p-6 md:p-10 mb-8"
          >
            <nav className="flex items-center gap-2 text-xs text-slate-400 mb-6">
              <Link to="/" className="hover:text-primary">Home</Link>
              <span>/</span>
              <Link to="/blog" className="hover:text-primary">Blog</Link>
              <span>/</span>
              <span className="text-slate-600">IRCTC Beginners Guide</span>
            </nav>

            <div className="flex items-center gap-3 mb-6">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">Guides</span>
              <span className="flex items-center gap-1 text-xs text-slate-400"><Clock size={11} /> 10 min read</span>
              <span className="text-xs text-slate-400">March 28, 2026</span>
            </div>

            <p className="text-slate-600 leading-relaxed mb-6">
              Booking train tickets online through IRCTC (Indian Railway Catering and Tourism Corporation) can seem overwhelming at first. The website has many options, the booking window is time-sensitive, and payment can be tricky. This complete guide walks you through every step — from creating your account to downloading your e-ticket.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              {[
                { icon: Shield, title: 'Safe & Official', desc: 'IRCTC is the official Indian Railways ticketing platform', color: 'bg-green-50 text-green-600' },
                { icon: CreditCard, title: 'Multiple Payments', desc: 'UPI, cards, net banking, and wallet options', color: 'bg-blue-50 text-blue-600' },
                { icon: Clock, title: 'Book 60 Days Early', desc: 'Advance booking opens 60 days before journey', color: 'bg-orange-50 text-orange-600' },
              ].map((item) => (
                <div key={item.title} className="border border-slate-200 rounded-xl p-4 text-center">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-2 ${item.color}`}>
                    <item.icon size={20} />
                  </div>
                  <h4 className="font-bold text-slate-900 text-sm mb-1">{item.title}</h4>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mb-6 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Step-by-Step IRCTC Booking Guide
            </h2>

            <div className="space-y-6 mb-8">
              {steps.map((s) => (
                <div key={s.step} className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="flex items-center gap-3 bg-slate-50 px-4 py-3 border-b border-slate-200">
                    <div className="w-8 h-8 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center shrink-0">
                      {s.step}
                    </div>
                    <h3 className="font-bold text-slate-900 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>{s.title}</h3>
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-slate-600 leading-relaxed mb-3">{s.desc}</p>
                    <div className="space-y-1.5">
                      {s.tips.map((tip) => (
                        <div key={tip} className="flex items-start gap-2 text-xs text-slate-500">
                          <CheckCircle size={12} className="text-green-500 mt-0.5 shrink-0" />
                          {tip}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Classes explained */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Train Classes Explained
            </h2>
            <div className="overflow-x-auto mb-8">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Class</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Full Name</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Best For</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { cls: '1A', name: 'First AC', best: 'Maximum privacy, 2-4 berths per cabin, premium comfort' },
                    { cls: '2A', name: 'Second AC', best: 'Good privacy, 4-6 berths, curtains, popular for long journeys' },
                    { cls: '3A', name: 'Third AC', best: 'Best value AC option, 6-8 berths, most popular class' },
                    { cls: 'SL', name: 'Sleeper Class', best: 'Budget travel, no AC, 8 berths per bay, good for short trips' },
                    { cls: 'CC', name: 'Chair Car', best: 'Day trains, Shatabdi/Vande Bharat, reclining seats' },
                    { cls: '2S', name: 'Second Sitting', best: 'Cheapest option, no reservation in some trains' },
                  ].map((row) => (
                    <tr key={row.cls} className="border-b border-slate-100">
                      <td className="p-3 border border-slate-200 font-bold text-primary">{row.cls}</td>
                      <td className="p-3 border border-slate-200 text-slate-700">{row.name}</td>
                      <td className="p-3 border border-slate-200 text-slate-500 text-xs">{row.best}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="bg-gradient-to-r from-green-600 to-green-700 rounded-2xl p-6 text-white text-center mb-8">
              <h3 className="text-lg font-bold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Use ChaloTrain to Plan Your Journey</h3>
              <p className="text-green-100 text-sm mb-4">Check PNR status, search trains, compare fares, and track live status — all for free.</p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link to="/train-search" className="inline-flex items-center gap-2 px-5 py-2.5 bg-white text-green-700 text-sm font-bold rounded-xl hover:bg-green-50 transition-colors">
                  Search Trains <ArrowRight size={14} />
                </Link>
                <Link to="/fare-inquiry" className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/10 border border-white/30 text-white text-sm font-bold rounded-xl hover:bg-white/20 transition-colors">
                  Check Fares
                </Link>
              </div>
            </div>

            <AppDownloadCTA />

            <SocialShareBar
              url="https://chalotrain.com/blog/irctc-booking-guide-for-beginners"
              title="IRCTC Booking Guide for Beginners — Step-by-Step 2026"
            />
          </motion.article>

          <FAQSection items={faqs} />
          <RelatedTools currentHref="/blog/irctc-booking-guide-for-beginners" />
        </div>
      </section>
    </>
  );
}
