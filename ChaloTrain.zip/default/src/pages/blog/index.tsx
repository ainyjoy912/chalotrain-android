import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { BookOpen, Clock, ArrowRight, Calendar, Ticket, Train, ArrowLeftRight, Armchair, IndianRupee } from 'lucide-react';
import PageHero from '@/components/PageHero';

export interface BlogPost {
  slug: string;
  title: string;
  description: string;
  category: string;
  readTime: string;
  date: string;
  tags: string[];
}

// Canonical category list
export const CATEGORIES = [
  'All',
  'PNR & Tickets',
  'Train Information',
  'Booking Guides',
  'Tatkal',
  'Train Routes',
  'Railway Travel Tips',
  'Refunds & Cancellation',
];

export const BLOG_POSTS: BlogPost[] = [
  // May 2026
  {
    slug: 'how-to-check-pnr-status-online-guide',
    title: 'How to Check PNR Status Online — Complete Guide 2026',
    description: 'Everything about PNR status — what it means, how to check it, understanding CNF/RAC/WL codes, and what to do if your ticket is waitlisted.',
    category: 'PNR & Tickets',
    readTime: '8 min read',
    date: 'May 7, 2026',
    tags: ['PNR Status', 'CNF', 'RAC', 'WL'],
  },
  {
    slug: 'irctc-complete-booking-guide',
    title: 'IRCTC Ticket Booking Complete Guide 2026 — Step by Step',
    description: 'Complete step-by-step guide to booking train tickets on IRCTC — account creation, train search, seat selection, payment, and ticket download.',
    category: 'Booking Guides',
    readTime: '10 min read',
    date: 'May 7, 2026',
    tags: ['IRCTC', 'Online Booking', 'Train Tickets'],
  },
  {
    slug: 'train-travel-tips-for-beginners',
    title: 'Train Travel Tips for Beginners — Complete India Rail Guide 2026',
    description: 'First time on an Indian train? Everything you need to know — booking, boarding, what to carry, berth etiquette, food, and safety tips.',
    category: 'Railway Travel Tips',
    readTime: '9 min read',
    date: 'May 7, 2026',
    tags: ['Travel Tips', 'Beginners', 'Indian Railways'],
  },
  {
    slug: 'how-to-read-train-ticket',
    title: 'How to Read Your Train Ticket — Every Field Explained',
    description: 'Decode every field on your Indian Railways ticket — PNR, coach, berth codes, quota, fare breakdown, and the difference between e-tickets and counter tickets.',
    category: 'Train Information',
    readTime: '7 min read',
    date: 'May 7, 2026',
    tags: ['Train Ticket', 'PNR', 'Berth Codes'],
  },
  {
    slug: 'how-to-check-seat-availability',
    title: 'How to Check Seat Availability in Indian Trains — Full Guide',
    description: 'Learn how to check seat availability for any train across all classes and quotas. Understand AVL, RAC, WL statuses and book smartly.',
    category: 'Booking Guides',
    readTime: '7 min read',
    date: 'May 7, 2026',
    tags: ['Seat Availability', 'AVL', 'RAC', 'WL'],
  },
  {
    slug: 'how-to-file-tdr',
    title: 'How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide',
    description: 'Step-by-step guide to filing TDR on IRCTC for cancelled trains, late trains, and other refund cases. Includes refund timelines and deadlines.',
    category: 'Refunds & Cancellation',
    readTime: '8 min read',
    date: 'May 7, 2026',
    tags: ['TDR', 'Refund', 'Cancelled Train'],
  },
  {
    slug: 'best-trains-delhi-to-mumbai',
    title: 'Best Trains from Delhi to Mumbai 2026 — Complete Guide',
    description: 'Compare the best trains on the Delhi–Mumbai route — Rajdhani, Duronto, Garib Rath, and more. Timings, fares, classes, and booking tips.',
    category: 'Train Routes',
    readTime: '8 min read',
    date: 'May 7, 2026',
    tags: ['Delhi Mumbai', 'Rajdhani', 'Train Routes'],
  },
  {
    slug: 'how-to-track-live-train-status',
    title: 'How to Track Live Train Status — Train Tracking Guide',
    description: 'Track your train in real time. Know where your train is, how late it is running, and when it will arrive at your station.',
    category: 'Train Information',
    readTime: '7 min read',
    date: 'May 7, 2026',
    tags: ['Live Status', 'Train Tracking', 'NTES'],
  },
  {
    slug: 'tatkal-ticket-booking-complete-guide',
    title: 'Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks',
    description: 'Master Tatkal booking — exact timing, charges by class, cancellation rules, and pro tips to successfully book Tatkal tickets every time.',
    category: 'Tatkal',
    readTime: '9 min read',
    date: 'May 7, 2026',
    tags: ['Tatkal', 'IRCTC', 'Last Minute Booking'],
  },
  {
    slug: 'how-to-check-train-schedule',
    title: 'How to Check Train Schedule — Complete Timetable Guide',
    description: 'Check the complete timetable for any Indian Railways train. Understand halt durations, platform numbers, day numbers, and plan your journey.',
    category: 'Train Information',
    readTime: '7 min read',
    date: 'May 7, 2026',
    tags: ['Train Schedule', 'Timetable', 'Indian Railways'],
  },
  // April 2026
  {
    slug: 'how-to-book-train-tickets-online',
    title: 'How to Book Train Tickets Online: Complete IRCTC Booking Guide 2026',
    description: 'Step-by-step guide to book train tickets online through IRCTC. Learn registration, payment methods, seat selection, and booking tips for confirmed tickets.',
    category: 'Booking Guides',
    readTime: '12 min read',
    date: 'April 20, 2026',
    tags: ['IRCTC', 'Online Booking', 'Train Tickets'],
  },
  {
    slug: 'train-ticket-cancellation-refund-rules',
    title: 'Train Ticket Cancellation & Refund Rules 2026 — Complete Guide',
    description: 'Complete guide to Indian Railways ticket cancellation and refund rules. Learn cancellation charges, refund timelines, and how to cancel tickets online.',
    category: 'Refunds & Cancellation',
    readTime: '10 min read',
    date: 'April 20, 2026',
    tags: ['Cancellation', 'Refund', 'IRCTC'],
  },
  {
    slug: 'indian-railway-classes-guide',
    title: 'Indian Railway Classes Guide: 1AC, 2AC, 3AC, SL Explained (2026)',
    description: 'Complete guide to Indian Railway classes: 1AC, 2AC, 3AC, Sleeper, Chair Car, and more. Compare facilities, fares, and choose the best class for your journey.',
    category: 'Train Information',
    readTime: '9 min read',
    date: 'April 20, 2026',
    tags: ['Railway Classes', '1AC', '2AC', '3AC', 'Sleeper'],
  },
  {
    slug: 'how-to-check-pnr-status-online',
    title: 'How to Check PNR Status Online — Complete Guide 2026',
    description: 'Learn how to check your Indian Railways PNR status online in seconds. Step-by-step guide covering all methods including IRCTC, SMS, and ChaloTrain.',
    category: 'PNR & Tickets',
    readTime: '5 min read',
    date: 'April 10, 2026',
    tags: ['PNR Status', 'IRCTC', 'Train Ticket'],
  },
  {
    slug: 'tatkal-ticket-booking-tips',
    title: 'Tatkal Ticket Booking Tips — How to Get Confirmed Tatkal Seats',
    description: 'Expert tips and tricks to successfully book Tatkal train tickets on IRCTC. Timing, class selection, payment methods, and common mistakes to avoid.',
    category: 'Tatkal',
    readTime: '7 min read',
    date: 'April 8, 2026',
    tags: ['Tatkal', 'IRCTC Booking', 'Train Tickets'],
  },
  {
    slug: 'how-to-get-confirmed-train-ticket',
    title: 'How to Get a Confirmed Train Ticket — 10 Proven Strategies',
    description: 'Struggling with waitlisted tickets? Discover 10 proven strategies to get a confirmed train ticket including quota tricks, alternate routes, and booking windows.',
    category: 'Booking Guides',
    readTime: '8 min read',
    date: 'April 5, 2026',
    tags: ['Confirmed Ticket', 'Waitlist', 'Train Booking'],
  },
  {
    slug: 'why-trains-run-late-in-india',
    title: 'Why Do Indian Trains Run Late? Top Reasons Explained',
    description: 'Ever wondered why your train is always delayed? We explain the top reasons Indian trains run late — from fog and track maintenance to cascading delays.',
    category: 'Train Information',
    readTime: '6 min read',
    date: 'April 2, 2026',
    tags: ['Train Delay', 'Indian Railways', 'Live Status'],
  },
  {
    slug: 'irctc-booking-guide-for-beginners',
    title: 'IRCTC Booking Guide for Beginners — Step-by-Step 2026',
    description: "New to IRCTC? This complete beginner's guide walks you through account creation, train search, seat selection, payment, and ticket download on IRCTC.",
    category: 'Booking Guides',
    readTime: '10 min read',
    date: 'March 28, 2026',
    tags: ['IRCTC', 'Beginners Guide', 'Online Booking'],
  },
];

const categoryColors: Record<string, string> = {
  'PNR & Tickets':          'bg-blue-100 text-blue-700',
  'Train Information':      'bg-purple-100 text-purple-700',
  'Booking Guides':         'bg-green-100 text-green-700',
  'Tatkal':                 'bg-orange-100 text-orange-700',
  'Train Routes':           'bg-indigo-100 text-indigo-700',
  'Railway Travel Tips':    'bg-cyan-100 text-cyan-700',
  'Refunds & Cancellation': 'bg-rose-100 text-rose-700',
};

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { duration: 0.35, ease: 'easeOut' as const, delay: i * 0.05 },
  }),
};

export default function BlogIndexPage() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filtered = activeCategory === 'All'
    ? BLOG_POSTS
    : BLOG_POSTS.filter((p) => p.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Railway Travel Blog — Tips, Guides &amp; Train Travel Advice | ChaloTrain</title>
        <meta name="description" content="Read expert articles on Indian Railways — PNR status, Tatkal booking tips, IRCTC guide, train delays, and more. Your go-to railway travel blog." />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Railway Travel Blog — Tips, Guides & Train Travel Advice | ChaloTrain" />
        <meta property="og:description" content="Read expert articles on Indian Railways — PNR status, Tatkal booking tips, IRCTC guide, train delays, and more. Your go-to railway travel blog." />
        <meta property="og:url" content="https://chalotrain.com/blog" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Railway Travel Blog — Tips, Guides & Train Travel Advice | ChaloTrain" />
        <meta name="twitter:description" content="Read expert articles on Indian Railways — PNR status, Tatkal booking tips, IRCTC guide, train delays, and more." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/blog" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'Blog',
          name: 'ChaloTrain Railway Travel Blog',
          url: 'https://chalotrain.com/blog',
          description: 'Expert guides, tips, and insights for smarter train travel in India.',
          publisher: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'Blog', item: 'https://chalotrain.com/blog' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        icon={BookOpen}
        title="Railway Travel Blog"
        subtitle="Expert guides, tips, and insights for smarter train travel in India"
        badge="Knowledge Hub"
      />
      {/* sr-only h1 for SEO checkers — PageHero renders the visible heading */}
      <h1 className="sr-only">Railway Travel Blog — Indian Railways Tips, Guides &amp; Advice</h1>

      <main>
        <section className="py-12 bg-slate-50 min-h-[60vh]">
          <div className="container mx-auto px-4 max-w-5xl">

            {/* Intro */}
            <motion.div
              initial="hidden" animate="visible" variants={fadeUp} custom={0}
              className="bg-white rounded-2xl border border-slate-200 p-6 mb-8"
            >
              <h2 className="text-xl font-bold text-slate-900 mb-2" style={{ fontFamily: 'var(--font-heading)' }}>
                Your Indian Railways knowledge hub
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Whether you're a frequent traveler or booking your first train ticket, our blog covers everything you need to know about Indian Railways. From step-by-step IRCTC guides to Tatkal booking tricks, PNR status checks, and understanding train delays — we've got you covered with practical, up-to-date advice.
              </p>
            </motion.div>

            {/* Category filter */}
            <motion.div
              initial="hidden" animate="visible" variants={fadeUp} custom={1}
              className="mb-6 overflow-x-auto pb-1"
            >
              <div className="flex gap-2 min-w-max sm:flex-wrap sm:min-w-0">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-all whitespace-nowrap ${
                      activeCategory === cat
                        ? 'bg-primary text-white border-primary'
                        : 'bg-white text-slate-600 border-slate-200 hover:border-primary hover:text-primary'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Post count */}
            <p className="text-xs text-slate-400 mb-4">
              {filtered.length} article{filtered.length !== 1 ? 's' : ''}
              {activeCategory !== 'All' ? ` in ${activeCategory}` : ''}
            </p>

            {/* Posts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map((post, i) => (
                <motion.article
                  key={post.slug}
                  initial="hidden" animate="visible" variants={fadeUp} custom={i + 2}
                >
                  <Link
                    to={`/blog/${post.slug}`}
                    className="group flex flex-col bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md hover:border-primary/30 transition-all h-full"
                  >
                    {/* Top row: category badge + read time */}
                    <div className="flex items-center justify-between mb-3 gap-2">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-semibold shrink-0 ${categoryColors[post.category] ?? 'bg-slate-100 text-slate-600'}`}>
                        {post.category}
                      </span>
                      <div className="flex items-center gap-1 text-xs text-slate-400 shrink-0">
                        <Clock size={11} />
                        <span>{post.readTime}</span>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-sm font-bold text-slate-900 mb-2 group-hover:text-primary transition-colors leading-snug" style={{ fontFamily: 'var(--font-heading)' }}>
                      {post.title}
                    </h3>

                    {/* Description */}
                    <p className="text-xs text-slate-500 leading-relaxed mb-4 line-clamp-3 flex-1">
                      {post.description}
                    </p>

                    {/* Bottom row: date + read more */}
                    <div className="flex items-center justify-between mt-auto pt-3 border-t border-slate-100">
                      <div className="flex items-center gap-1 text-xs text-slate-400">
                        <Calendar size={11} />
                        <time dateTime={post.date}>{post.date}</time>
                      </div>
                      <span className="text-xs font-semibold text-primary flex items-center gap-1 group-hover:gap-2 transition-all">
                        Read <ArrowRight size={11} />
                      </span>
                    </div>
                  </Link>
                </motion.article>
              ))}
            </div>

            {filtered.length === 0 && (
              <div className="text-center py-16 text-slate-400 text-sm">
                No articles in this category yet. Check back soon!
              </div>
            )}

            {/* Explore Our Tools */}
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={0}
              className="mt-10"
            >
              <h2 className="text-lg font-bold text-slate-900 mb-1" style={{ fontFamily: 'var(--font-heading)' }}>
                Explore Our Tools
              </h2>
              <p className="text-sm text-slate-500 mb-4">Free railway tools — no login required.</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { icon: Ticket,         title: 'PNR Status',            desc: 'Check CNF / RAC / WL status.',  href: '/pnr-status'        },
                  { icon: Train,          title: 'Live Train Status',      desc: 'Real-time train tracking.',     href: '/live-status'       },
                  { icon: ArrowLeftRight, title: 'Train Between Stations', desc: 'Find trains on your route.',    href: '/train-search'      },
                  { icon: Armchair,       title: 'Seat Availability',      desc: 'Check availability by class.',  href: '/seat-availability' },
                  { icon: Clock,          title: 'Train Schedule',         desc: 'Full timetable & all stops.',   href: '/train-schedule'    },
                  { icon: IndianRupee,    title: 'Fare Inquiry',           desc: 'Compare fares & quotas.',       href: '/fare-inquiry'      },
                ].map(({ icon: Icon, title, desc, href }) => (
                  <Link
                    key={href}
                    to={href}
                    className="group flex flex-col gap-2 bg-white border border-slate-200 rounded-2xl p-4 hover:border-primary/40 hover:shadow-sm transition-all"
                  >
                    <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
                      <Icon size={16} className="text-primary" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-800 group-hover:text-primary transition-colors leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
                        {title}
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">{desc}</div>
                    </div>
                  </Link>
                ))}
              </div>
            </motion.div>

            {/* CTA */}
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} custom={0}
              className="mt-10 bg-primary rounded-2xl p-6 text-white text-center"
            >
              <h3 className="text-lg font-bold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>
                Ready to check your train?
              </h3>
              <p className="text-blue-100 text-sm mb-4">Use our free tools to check PNR status, running status, and more.</p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link to="/pnr-status" className="px-5 py-2 bg-white text-primary text-sm font-bold rounded-xl hover:bg-blue-50 transition-colors">
                  Check PNR Status
                </Link>
                <Link to="/train-search" className="px-5 py-2 bg-white/10 border border-white/30 text-white text-sm font-bold rounded-xl hover:bg-white/20 transition-colors">
                  Search Trains
                </Link>
              </div>
            </motion.div>

          </div>
        </section>
      </main>
    </>
  );
}
