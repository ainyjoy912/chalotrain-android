import { motion } from 'motion/react';
import { Smartphone, CreditCard, CheckCircle, AlertCircle, Shield, Zap } from 'lucide-react';
import PageHero from '@/components/PageHero';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import LastUpdatedBadge from '@/components/LastUpdatedBadge';
import AppDownloadCTA from '@/components/AppDownloadCTA';

const faqs = [
  { question: 'Can I book train tickets without creating an IRCTC account?', answer: 'No, you need an IRCTC account to book train tickets online. Registration is free and takes only 5 minutes. You need a valid email ID, mobile number, and government ID proof (Aadhaar/PAN/Voter ID) to create an account.' },
  { question: 'How many tickets can I book in one transaction?', answer: 'You can book up to 6 passengers in a single transaction. For Tatkal tickets, the limit is 4 passengers. If you need to book for more people, you\'ll need to make multiple bookings.' },
  { question: 'What is the advance booking period for train tickets?', answer: 'General tickets can be booked 120 days in advance (excluding the date of journey). Tatkal tickets open 1 day before departure at 10 AM for AC classes and 11 AM for non-AC classes. Premium Tatkal opens 3 days in advance.' },
  { question: 'Can I book tickets using someone else\'s IRCTC account?', answer: 'Yes, you can book tickets for anyone using your IRCTC account. You just need to enter their correct name, age, and gender as per their ID proof. The passenger doesn\'t need their own IRCTC account.' },
  { question: 'What payment methods are accepted for train ticket booking?', answer: 'IRCTC accepts multiple payment methods: Credit/Debit Cards (Visa, Mastercard, RuPay), Net Banking, UPI (Google Pay, PhonePe, Paytm), IRCTC Wallet, and EMI options. All payments are secure and encrypted.' },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Book Train Tickets Online: Complete IRCTC Booking Guide 2026",
  "description": "Step-by-step guide to book train tickets online through IRCTC. Learn registration, payment methods, seat selection, and booking tips for confirmed tickets.",
  "url": "https://chalotrain.com/blog/how-to-book-train-tickets-online",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-book-train-tickets-online"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function HowToBookTrainTicketsOnlinePage() {
  return (
    <>
      <title>How to Book Train Tickets Online: Complete IRCTC Booking Guide 2026</title>
      <meta name="description" content="Step-by-step guide to book train tickets online through IRCTC. Learn registration, payment methods, seat selection, and booking tips for confirmed tickets." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-book-train-tickets-online" />
      
      {/* Open Graph */}
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Book Train Tickets Online: Complete IRCTC Booking Guide 2026" />
      <meta property="og:description" content="Step-by-step guide to book train tickets online through IRCTC. Learn registration, payment methods, seat selection, and booking tips for confirmed tickets." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-book-train-tickets-online" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Book Train Tickets Online: Complete IRCTC Booking Guide 2026" />
      <meta name="twitter:description" content="Step-by-step guide to book train tickets online through IRCTC. Learn registration, payment methods, seat selection, and booking tips for confirmed tickets." />
      <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />

      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        title="How to Book Train Tickets Online"
        subtitle="Complete step-by-step guide to IRCTC registration, booking, and payment"
        icon={Smartphone}
      />
      <h1 className="sr-only">How to Book Train Tickets Online: Complete IRCTC Booking Guide 2026</h1>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <motion.article
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          className="prose prose-slate max-w-none"
        >
          {/* Last Updated Badge */}
          <LastUpdatedBadge label="2026-04-20" />

          {/* Introduction */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8 border border-blue-100">
            <p className="text-lg text-slate-700 leading-relaxed mb-0">
              Booking train tickets online through <strong>IRCTC (Indian Railway Catering and Tourism Corporation)</strong> is fast, convenient, and secure. This comprehensive guide walks you through every step—from creating an account to making payment and getting confirmed tickets. Follow this guide to book your first train ticket online in 2026.
            </p>
          </div>

          {/* Prerequisites */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <Shield className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                What You Need Before Booking
              </h2>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <h3 className="text-lg font-semibold text-slate-800 mb-3">For IRCTC Registration</h3>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Valid <strong>email address</strong></li>
                  <li>✅ Active <strong>mobile number</strong></li>
                  <li>✅ Government ID proof (<strong>Aadhaar/PAN/Voter ID</strong>)</li>
                  <li>✅ Date of birth and address</li>
                </ul>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <h3 className="text-lg font-semibold text-slate-800 mb-3">For Booking Tickets</h3>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Passenger details (name, age, gender)</li>
                  <li>✅ Journey details (from, to, date)</li>
                  <li>✅ Payment method (card/UPI/net banking)</li>
                  <li>✅ Stable internet connection</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Step 1: IRCTC Registration */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-blue-500 to-indigo-500 p-3 rounded-xl">
                <Smartphone className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Step 1: Create IRCTC Account
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <div className="space-y-5">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">1</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Visit IRCTC Website</h4>
                    <p className="text-sm text-slate-600 mb-2">Go to <strong>www.irctc.co.in</strong> or download the <strong>IRCTC Rail Connect</strong> app from Play Store/App Store.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">2</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Click on "Register"</h4>
                    <p className="text-sm text-slate-600 mb-2">On the homepage, click the "Register" button in the top-right corner (or "Sign Up" in the app).</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">3</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Fill Registration Form</h4>
                    <p className="text-sm text-slate-600 mb-2">Enter your details:</p>
                    <ul className="text-sm text-slate-600 space-y-1 ml-4">
                      <li>• Username (unique, 3-10 characters)</li>
                      <li>• Password (strong, with uppercase, lowercase, numbers)</li>
                      <li>• Email address and mobile number</li>
                      <li>• Personal details (name, DOB, gender)</li>
                      <li>• Address and ID proof details</li>
                    </ul>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">4</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Verify Email & Mobile</h4>
                    <p className="text-sm text-slate-600 mb-2">Check your email and SMS for OTP codes. Enter them to verify your account.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">✓</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Account Created!</h4>
                    <p className="text-sm text-slate-600 mb-2">Your IRCTC account is now active. You can login and start booking tickets.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <AlertCircle className="text-amber-600 flex-shrink-0 mt-0.5" size={20} />
                <div>
                  <p className="text-sm text-amber-900 font-semibold mb-2">Important Tips:</p>
                  <ul className="text-sm text-amber-800 space-y-1 mb-0">
                    <li>• Choose a <strong>memorable username</strong> (you'll need it for every login)</li>
                    <li>• Use a <strong>strong password</strong> with mix of characters</li>
                    <li>• Verify email/mobile immediately (OTPs expire in 10 minutes)</li>
                    <li>• Keep your ID proof handy during registration</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Step 2: Search Trains */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-green-500 to-teal-500 p-3 rounded-xl">
                <Zap className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Step 2: Search for Trains
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <div className="space-y-5">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">1</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Login to IRCTC</h4>
                    <p className="text-sm text-slate-600 mb-2">Enter your username and password to login. Complete the captcha verification.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">2</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Enter Journey Details</h4>
                    <p className="text-sm text-slate-600 mb-2">Fill in the search form:</p>
                    <ul className="text-sm text-slate-600 space-y-1 ml-4">
                      <li>• <strong>From:</strong> Source station (e.g., New Delhi - NDLS)</li>
                      <li>• <strong>To:</strong> Destination station (e.g., Mumbai Central - BCT)</li>
                      <li>• <strong>Date:</strong> Journey date (up to 120 days in advance)</li>
                      <li>• <strong>Class:</strong> Select travel class (3AC, 2AC, SL, etc.)</li>
                      <li>• <strong>Quota:</strong> General, Tatkal, Ladies, etc.</li>
                    </ul>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">3</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">View Available Trains</h4>
                    <p className="text-sm text-slate-600 mb-2">Click "Find Trains" to see all available trains with:</p>
                    <ul className="text-sm text-slate-600 space-y-1 ml-4">
                      <li>• Train number and name</li>
                      <li>• Departure and arrival times</li>
                      <li>• Journey duration</li>
                      <li>• Seat availability (Available/RAC/Waitlist)</li>
                      <li>• Fare for selected class</li>
                    </ul>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">4</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Choose Your Train</h4>
                    <p className="text-sm text-slate-600 mb-2">Select a train with available seats. Click "Book Now" to proceed.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
              <p className="text-sm text-blue-900 font-semibold mb-2">Pro Tips for Finding Trains:</p>
              <ul className="text-sm text-blue-800 space-y-1 mb-0">
                <li>• Use <strong>station codes</strong> (NDLS, BCT) for faster search</li>
                <li>• Check <strong>alternate dates</strong> if your preferred date is full</li>
                <li>• Look for <strong>RAC tickets</strong> if waitlist is too long (high confirmation chance)</li>
                <li>• Premium trains (Rajdhani, Shatabdi) have better availability</li>
              </ul>
            </div>
          </section>

          {/* Step 3: Add Passengers */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-orange-500 to-red-500 p-3 rounded-xl">
                <CheckCircle className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Step 3: Add Passenger Details
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <div className="space-y-5">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-sm">1</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Enter Passenger Information</h4>
                    <p className="text-sm text-slate-600 mb-2">For each passenger, provide:</p>
                    <ul className="text-sm text-slate-600 space-y-1 ml-4">
                      <li>• <strong>Name:</strong> As per government ID (first name + last name)</li>
                      <li>• <strong>Age:</strong> Accurate age (affects fare for children/seniors)</li>
                      <li>• <strong>Gender:</strong> Male/Female/Transgender</li>
                      <li>• <strong>Berth Preference:</strong> Lower/Middle/Upper/Side Lower/Side Upper</li>
                      <li>• <strong>Nationality:</strong> Indian/Foreign</li>
                    </ul>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-sm">2</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Add Multiple Passengers</h4>
                    <p className="text-sm text-slate-600 mb-2">You can add up to 6 passengers (4 for Tatkal). Click "Add Passenger" to add more travelers.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-sm">3</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Enter Contact Details</h4>
                    <p className="text-sm text-slate-600 mb-2">Provide mobile number and email for ticket confirmation and updates.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-sm">4</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Review & Proceed</h4>
                    <p className="text-sm text-slate-600 mb-2">Double-check all details. Click "Continue" to proceed to payment.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <AlertCircle className="text-red-600 flex-shrink-0 mt-0.5" size={20} />
                <div>
                  <p className="text-sm text-red-900 font-semibold mb-2">Critical: Name Accuracy</p>
                  <p className="text-sm text-red-800 mb-0">Enter passenger names <strong>exactly as per ID proof</strong>. Incorrect names can lead to ticket cancellation or denial of boarding. TTE (Ticket Examiner) will verify ID during journey.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Step 4: Payment */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-purple-500 to-pink-500 p-3 rounded-xl">
                <CreditCard className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Step 4: Make Payment
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-4">Available Payment Methods</h3>
              
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="bg-blue-50 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-900 mb-2">💳 Cards</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Credit Cards (Visa, Mastercard, RuPay)</li>
                    <li>• Debit Cards (all major banks)</li>
                    <li>• International Cards accepted</li>
                  </ul>
                </div>

                <div className="bg-green-50 rounded-lg p-4">
                  <h4 className="font-semibold text-green-900 mb-2">📱 UPI</h4>
                  <ul className="text-sm text-green-800 space-y-1">
                    <li>• Google Pay, PhonePe, Paytm</li>
                    <li>• Any UPI app</li>
                    <li>• Instant payment confirmation</li>
                  </ul>
                </div>

                <div className="bg-purple-50 rounded-lg p-4">
                  <h4 className="font-semibold text-purple-900 mb-2">🏦 Net Banking</h4>
                  <ul className="text-sm text-purple-800 space-y-1">
                    <li>• All major banks supported</li>
                    <li>• Secure bank gateway</li>
                    <li>• Direct account debit</li>
                  </ul>
                </div>

                <div className="bg-orange-50 rounded-lg p-4">
                  <h4 className="font-semibold text-orange-900 mb-2">💰 Other Methods</h4>
                  <ul className="text-sm text-orange-800 space-y-1">
                    <li>• IRCTC Wallet (instant)</li>
                    <li>• EMI options available</li>
                    <li>• Pay Later services</li>
                  </ul>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center font-bold text-sm">1</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Select Payment Method</h4>
                    <p className="text-sm text-slate-600">Choose your preferred payment option from the list.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center font-bold text-sm">2</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Enter Payment Details</h4>
                    <p className="text-sm text-slate-600">Provide card/UPI/bank details as required. Complete OTP verification.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center font-bold text-sm">3</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Confirm Payment</h4>
                    <p className="text-sm text-slate-600">Review total amount and click "Pay Now". Wait for confirmation (don't refresh!).</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">✓</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Booking Confirmed!</h4>
                    <p className="text-sm text-slate-600">You'll receive ticket via SMS and email. PNR number will be sent immediately.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <Shield className="text-green-600 flex-shrink-0 mt-0.5" size={20} />
                <div>
                  <p className="text-sm text-green-900 font-semibold mb-2">Payment Security:</p>
                  <ul className="text-sm text-green-800 space-y-1 mb-0">
                    <li>• All payments are <strong>encrypted and secure</strong></li>
                    <li>• IRCTC uses <strong>PCI-DSS compliant</strong> payment gateway</li>
                    <li>• <strong>Never share OTP</strong> with anyone</li>
                    <li>• Check for <strong>HTTPS</strong> in URL before payment</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* After Booking */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              After Booking: What to Do Next
            </h2>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <CheckCircle className="text-blue-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">Check Your Ticket</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Save the <strong>PNR number</strong> (10 digits)</li>
                  <li>✅ Download ticket PDF from email</li>
                  <li>✅ Take screenshot of ticket</li>
                  <li>✅ Check booking status on IRCTC</li>
                  <li>✅ Verify passenger names and details</li>
                </ul>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <Smartphone className="text-green-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">Track Your PNR</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Check PNR status regularly</li>
                  <li>✅ Waitlist tickets may get confirmed</li>
                  <li>✅ Chart preparation 4 hours before departure</li>
                  <li>✅ Use ChaloTrain for instant PNR check</li>
                  <li>✅ Get SMS updates on status changes</li>
                </ul>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-purple-100 p-2 rounded-lg">
                    <AlertCircle className="text-purple-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">Before Journey</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Carry <strong>original ID proof</strong> (Aadhaar/PAN/DL)</li>
                  <li>✅ Keep ticket handy (print or digital)</li>
                  <li>✅ Reach station 30 minutes early</li>
                  <li>✅ Check platform number</li>
                  <li>✅ Verify coach and berth number</li>
                </ul>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-orange-100 p-2 rounded-lg">
                    <CreditCard className="text-orange-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">If Waitlisted</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Wait for chart preparation</li>
                  <li>✅ Auto-refund if not confirmed</li>
                  <li>✅ Book alternate train as backup</li>
                  <li>✅ Check RAC/WL movement daily</li>
                  <li>✅ Consider Tatkal if urgent</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Pro Tips */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Pro Tips for Successful Booking
            </h2>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-blue-900 mb-3">⚡ Speed Tips</h3>
                <ul className="space-y-2 text-blue-800 text-sm">
                  <li>✓ Login before booking time (for Tatkal)</li>
                  <li>✓ Save passenger details in IRCTC master list</li>
                  <li>✓ Use IRCTC wallet for instant payment</li>
                  <li>✓ Keep payment details ready</li>
                  <li>✓ Use fast internet connection</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-teal-50 border border-green-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-green-900 mb-3">💰 Money-Saving Tips</h3>
                <ul className="space-y-2 text-green-800 text-sm">
                  <li>✓ Book 120 days in advance for best prices</li>
                  <li>✓ Check dynamic pricing trains</li>
                  <li>✓ Use senior citizen/student concessions</li>
                  <li>✓ Travel in Sleeper Class for budget trips</li>
                  <li>✓ Avoid peak season travel</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-purple-900 mb-3">🎯 Confirmation Tips</h3>
                <ul className="space-y-2 text-purple-800 text-sm">
                  <li>✓ Choose trains with good availability</li>
                  <li>✓ Book RAC over long waitlist</li>
                  <li>✓ Check alternate dates/trains</li>
                  <li>✓ Premium trains have better confirmation</li>
                  <li>✓ Book early for festival seasons</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-red-50 border border-orange-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-orange-900 mb-3">🛡️ Safety Tips</h3>
                <ul className="space-y-2 text-orange-800 text-sm">
                  <li>✓ Book only on official IRCTC website/app</li>
                  <li>✓ Never share OTP or password</li>
                  <li>✓ Beware of fake booking sites</li>
                  <li>✓ Check HTTPS before payment</li>
                  <li>✓ Save booking confirmation immediately</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Conclusion */}
          <section className="mb-12">
            <div className="bg-gradient-to-br from-blue-900 to-indigo-900 text-white rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                Quick Recap: Booking Checklist
              </h2>
              <div className="grid md:grid-cols-2 gap-4 text-blue-100">
                <div>
                  <p className="font-semibold text-white mb-2">Before Booking:</p>
                  <ul className="space-y-1 text-sm">
                    <li>✓ Create IRCTC account</li>
                    <li>✓ Verify email & mobile</li>
                    <li>✓ Keep ID proof ready</li>
                    <li>✓ Check train availability</li>
                  </ul>
                </div>
                <div>
                  <p className="font-semibold text-white mb-2">During Booking:</p>
                  <ul className="space-y-1 text-sm">
                    <li>✓ Enter correct passenger names</li>
                    <li>✓ Choose berth preference</li>
                    <li>✓ Review all details</li>
                    <li>✓ Complete payment securely</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* CTA */}
          <AppDownloadCTA />
        </motion.article>

        {/* Social Share */}
        <div className="mt-12">
          <SocialShareBar
            title="How to Book Train Tickets Online: Complete IRCTC Guide 2026"
            url="https://chalotrain.com/blog/how-to-book-train-tickets-online"
          />
        </div>

        {/* Related Tools */}
        <div className="mt-12">
          <RelatedTools currentHref="/blog" />
        </div>

        {/* FAQ Section */}
        <div className="mt-12">
          <FAQSection items={faqs} />
        </div>
      </div>
    </>
  );
}
