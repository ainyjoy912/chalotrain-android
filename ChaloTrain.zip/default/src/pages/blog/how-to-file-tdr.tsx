import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, FileText, AlertCircle, Clock, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'How long does TDR refund take?', answer: 'TDR refunds typically take 60–90 days to process. The refund is credited to the original payment method. IRCTC sends an email notification once the refund is processed.' },
  { question: 'Can I file TDR for a train that was cancelled by Railways?', answer: 'If the train is cancelled by Indian Railways, you do not need to file a TDR. The refund is automatically processed to your original payment method within 7–10 working days.' },
  { question: 'What is the time limit for filing TDR?', answer: 'For e-tickets, TDR must be filed within 72 hours of the scheduled departure of the train. For counter tickets, the time limit varies by reason — typically within 3 hours to 10 days depending on the case.' },
  { question: 'Can I file TDR if I missed my train?', answer: 'No. TDR cannot be filed if you simply missed your train. TDR is only for cases where the train was late, cancelled, or you were unable to board due to a valid reason (like the train not stopping at your station).' },
  { question: 'What happens if my TDR is rejected?', answer: 'If your TDR is rejected, you will receive an email from IRCTC explaining the reason. You can appeal the decision by contacting IRCTC customer care or filing a complaint with the Railway Claims Tribunal.' },
];

const tdrReasons = [
  { reason: 'Train Cancelled by Railways', refund: '100% refund', notes: 'Auto-refund; no TDR needed for e-tickets' },
  { reason: 'Train Running Late by 3+ Hours', refund: 'Full refund if you choose not to travel', notes: 'File TDR before chart preparation' },
  { reason: 'Passenger Not Travelled (PNT)', refund: 'Partial refund after deductions', notes: 'File within 72 hours of departure' },
  { reason: 'Train Diverted / Short Terminated', refund: 'Proportional refund for untravelled portion', notes: 'File within 72 hours' },
  { reason: 'Difference in Fare (Downgraded)', refund: 'Difference in fare refunded', notes: 'File within 72 hours' },
  { reason: 'Waitlisted Ticket (Counter)', refund: 'Full refund minus cancellation charge', notes: 'Counter tickets only; e-tickets auto-cancelled' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide | ChaloTrain",
  "description": "Learn how to file a TDR (Ticket Deposit Receipt) on IRCTC for cancelled trains, late trains, and other refund cases. Step-by-step guide with refund timelines.",
  "url": "https://chalotrain.com/blog/how-to-file-tdr",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-file-tdr"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogFileTDR() {
  return (
    <>
      <title>How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide | ChaloTrain</title>
      <meta name="description" content="Learn how to file a TDR (Ticket Deposit Receipt) on IRCTC for cancelled trains, late trains, and other refund cases. Step-by-step guide with refund timelines." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide" />
      <meta property="og:description" content="Learn how to file a TDR (Ticket Deposit Receipt) on IRCTC for cancelled trains, late trains, and other refund cases. Step-by-step guide with refund timelines." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-file-tdr" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide" />
      <meta name="twitter:description" content="Learn how to file a TDR (Ticket Deposit Receipt) on IRCTC for cancelled trains, late trains, and other refund cases. Step-by-step guide with refund timelines." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-file-tdr" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">How to File TDR</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full font-semibold">Refunds & TDR</span>
              <span className="text-xs text-slate-400">May 2026 • 8 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              When your train is cancelled, significantly delayed, or you are unable to travel due to a valid reason, you are entitled to a refund. TDR (Ticket Deposit Receipt) is the formal process to claim this refund for e-tickets.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>What is TDR?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              TDR stands for <strong>Ticket Deposit Receipt</strong>. It is a formal refund request mechanism provided by Indian Railways for cases where a passenger is entitled to a refund but the standard online cancellation process does not apply. TDR is filed through IRCTC for e-tickets.
            </p>
            <p className="text-slate-600 leading-relaxed mb-6">
              Unlike a regular cancellation (where you cancel before departure and get an instant refund), TDR is filed after the scheduled departure time — for example, when a train is cancelled by Railways, running very late, or when you were unable to board due to circumstances beyond your control.
            </p>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <AlertCircle size={20} className="text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-amber-800 mb-1">Important Note</p>
                <p className="text-sm text-amber-700">If your train is cancelled by Indian Railways, you do NOT need to file a TDR. The refund is automatically processed to your original payment method. TDR is only needed for specific cases listed below.</p>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>When Can You File a TDR?</h2>
            <div className="overflow-x-auto mb-6">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Reason</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Refund Amount</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {tdrReasons.map(({ reason, refund, notes }) => (
                    <tr key={reason} className="hover:bg-slate-50">
                      <td className="p-3 border border-slate-200 text-slate-700 font-medium">{reason}</td>
                      <td className="p-3 border border-slate-200 text-green-700 font-semibold">{refund}</td>
                      <td className="p-3 border border-slate-200 text-slate-500 text-xs">{notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to File TDR on IRCTC — Step by Step</h2>
            <ol className="list-none space-y-4 mb-6">
              {[
                { title: 'Log in to IRCTC', desc: 'Go to irctc.co.in and log in with your username and password.' },
                { title: 'Go to "My Transactions"', desc: 'Click on "My Account" → "My Transactions" → "Booked Ticket History".' },
                { title: 'Find Your Ticket', desc: 'Locate the ticket for which you want to file TDR. Click on the PNR number to open the ticket details.' },
                { title: 'Click "File TDR"', desc: 'You will see a "File TDR" button if the ticket is eligible. Click it.' },
                { title: 'Select the Reason', desc: 'Choose the appropriate reason from the dropdown: Train Cancelled, Train Late by 3+ Hours, Passenger Not Travelled, etc.' },
                { title: 'Select Passengers', desc: 'If the ticket has multiple passengers, select which passengers the TDR is for.' },
                { title: 'Submit the TDR', desc: 'Review the details and click "Submit". You will receive a TDR reference number and a confirmation email.' },
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <div>
                    <p className="font-semibold text-slate-800 text-sm">{step.title}</p>
                    <p className="text-sm text-slate-600 leading-relaxed">{step.desc}</p>
                  </div>
                </li>
              ))}
            </ol>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>TDR Time Limits — Act Quickly</h2>
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
              <div className="flex items-start gap-3">
                <Clock size={20} className="text-red-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-red-800 mb-2">TDR Deadlines</p>
                  <ul className="space-y-1.5">
                    {[
                      'Train Cancelled: Within 72 hours of scheduled departure',
                      'Train Late 3+ Hours: Before departure or within 72 hours',
                      'Passenger Not Travelled: Within 72 hours of scheduled departure',
                      'Train Diverted/Short Terminated: Within 72 hours',
                    ].map((item) => (
                      <li key={item} className="text-sm text-red-700 flex items-start gap-1.5">
                        <span className="mt-0.5">•</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Track Your TDR Status</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              After filing a TDR, you can track its status on IRCTC:
            </p>
            <ol className="list-none space-y-3 mb-6">
              {[
                'Log in to IRCTC → My Account → My Transactions',
                'Click on "TDR History" or "TDR Filing Status"',
                'Find your TDR by PNR number or filing date',
                'Status will show: Filed, Under Process, Approved, or Rejected',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 text-slate-600 text-xs font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <span className="text-slate-600 text-sm leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Regular Cancellation vs TDR — Key Differences</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {[
                { title: 'Regular Cancellation', points: ['Done before chart preparation', 'Instant refund (minus cancellation charges)', 'You initiate the cancellation', 'Available for all ticket types'] },
                { title: 'TDR Filing', points: ['Done after scheduled departure', 'Refund takes 60–90 days', 'Filed when Railways is at fault', 'Only for specific valid reasons'] },
              ].map(({ title, points }) => (
                <div key={title} className="border border-slate-200 rounded-xl p-4">
                  <p className="font-semibold text-slate-800 text-sm mb-3">{title}</p>
                  <ul className="space-y-1.5">
                    {points.map((p) => (
                      <li key={p} className="text-xs text-slate-600 flex items-start gap-1.5">
                        <span className="text-primary mt-0.5">•</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Check Your Train Status</p>
              <p className="text-sm text-slate-600 mb-3">Before filing a TDR, check your train's live status to confirm delays or cancellations.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/live-status" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                  <FileText size={15} /> Check Live Status
                </Link>
                <Link to="/pnr-status" className="inline-flex items-center gap-2 bg-white border border-primary text-primary px-4 py-2 rounded-xl text-sm font-semibold hover:bg-primary/5 transition-colors">
                  Check PNR Status
                </Link>
              </div>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="How to File TDR for Cancelled or Late Trains — IRCTC Refund Guide" url="https://chalotrain.com/blog/how-to-file-tdr" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/how-to-file-tdr" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
