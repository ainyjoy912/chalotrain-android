import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Train, Lightbulb, ShieldCheck, Clock, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'How early should I arrive at the railway station?', answer: 'Arrive at least 30 minutes before departure for short-distance trains and 45–60 minutes for long-distance trains. This gives you time to find your platform, locate your coach, and settle in comfortably.' },
  { question: 'How do I find my coach and berth on the platform?', answer: 'The Railway Station displays a Coach Position Chart on the platform before the train arrives. You can also check the NTES app or ChaloTrain\'s Live Status for your train\'s coach composition. Coaches are labeled on the outside (e.g., S1, S2, B1, B2).' },
  { question: 'Can I carry food on Indian trains?', answer: 'Yes. You can carry home-cooked food and packaged snacks. Pantry cars are available on most long-distance trains. You can also order food via the IRCTC e-Catering app (ecatering.irctc.co.in) to your seat.' },
  { question: 'Is it safe to travel alone on Indian trains?', answer: 'Yes, Indian trains are generally safe. For solo women travelers, Ladies Coaches are available in every train. Keep your valuables secure, use the chain lock on your berth at night, and avoid sharing personal information with strangers.' },
  { question: 'What should I do if I miss my train?', answer: 'If you miss your train, your e-ticket is forfeited and no refund is given. For counter tickets, you can apply for a TDR (Ticket Deposit Receipt) within 3 hours of the train\'s departure from your station. Always arrive early to avoid missing your train.' },
];

const tips = [
  { icon: Clock, title: 'Book 60 Days in Advance', desc: 'IRCTC opens bookings 60 days before departure. Popular trains fill up fast — especially on weekends and holidays. Book as early as possible for confirmed seats.' },
  { icon: ShieldCheck, title: 'Carry Valid Photo ID', desc: 'For e-tickets, you must carry a government-issued photo ID (Aadhaar, PAN, Passport, Voter ID, or Driving License). The name must match your ticket exactly.' },
  { icon: Train, title: 'Check PNR Status Regularly', desc: 'If you have a waitlisted ticket, check your PNR status daily. Many WL tickets get confirmed as the journey date approaches, especially after chart preparation.' },
  { icon: Lightbulb, title: 'Download the NTES App', desc: 'The National Train Enquiry System (NTES) app by Indian Railways gives you real-time train running status, platform information, and arrival/departure updates.' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Train Travel Tips for Beginners — Complete India Rail Guide 2026 | ChaloTrain",
  "description": "First time travelling by Indian train? Our complete beginner's guide covers booking, boarding, what to carry, safety tips, and everything you need for a smooth journey.",
  "url": "https://chalotrain.com/blog/train-travel-tips-for-beginners",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/train-travel-tips-for-beginners"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogTrainTipsBeginners() {
  return (
    <>
      <title>Train Travel Tips for Beginners — Complete India Rail Guide 2026 | ChaloTrain</title>
      <meta name="description" content="First time travelling by Indian train? Our complete beginner's guide covers booking, boarding, what to carry, safety tips, and everything you need for a smooth journey." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Train Travel Tips for Beginners — Complete India Rail Guide 2026" />
      <meta property="og:description" content="First time travelling by Indian train? Our complete beginner's guide covers booking, boarding, what to carry, safety tips, and everything you need for a smooth journey." />
      <meta property="og:url" content="https://chalotrain.com/blog/train-travel-tips-for-beginners" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Train Travel Tips for Beginners — Complete India Rail Guide 2026" />
      <meta name="twitter:description" content="First time travelling by Indian train? Our complete beginner's guide covers booking, boarding, what to carry, safety tips, and everything you need for a smooth journey." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/train-travel-tips-for-beginners" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">Train Travel Tips for Beginners</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-orange-100 text-orange-700 px-3 py-1 rounded-full font-semibold">Travel Tips</span>
              <span className="text-xs text-slate-400">May 2026 • 9 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              Train Travel Tips for Beginners — Complete India Rail Guide 2026
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              Travelling by Indian Railways for the first time? With over 13,000 trains and 7,000 stations, the network can feel overwhelming. This guide covers everything a first-time traveller needs to know.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Before You Travel — Planning & Booking</h2>

            <h3 className="text-base font-bold text-slate-800 mb-2">1. Choose the Right Train</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              Indian Railways operates several types of trains. <strong>Rajdhani Express</strong> trains are the fastest and connect major cities to Delhi. <strong>Shatabdi Express</strong> trains are day trains for shorter distances. <strong>Duronto Express</strong> trains are non-stop between major cities. <strong>Mail/Express</strong> trains cover most routes and are more affordable. <strong>Superfast</strong> trains have fewer stops and charge a small superfast surcharge.
            </p>
            <p className="text-slate-600 leading-relaxed mb-4">
              Use ChaloTrain's <Link to="/train-search" className="text-primary underline font-medium">Train Search</Link> to find all trains between your source and destination, compare timings, and check availability before booking.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">2. Choose the Right Class</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              Indian trains offer multiple classes to suit every budget. <strong>Sleeper Class (SL)</strong> is the most affordable option for overnight journeys — open coaches with berths, no air conditioning. <strong>Third AC (3A)</strong> offers air-conditioned berths at a moderate price and is the most popular class. <strong>Second AC (2A)</strong> has wider berths with curtains for more privacy. <strong>First AC (1A)</strong> is the most premium with private cabins. For day journeys, <strong>Chair Car (CC)</strong> and <strong>Second Sitting (2S)</strong> are available.
            </p>
            <p className="text-slate-600 leading-relaxed mb-6">
              Read our detailed <Link to="/blog/indian-railway-classes-guide" className="text-primary underline font-medium">Indian Railway Classes Guide</Link> to understand which class suits your needs and budget.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">3. Book Early for Best Availability</h3>
            <p className="text-slate-600 leading-relaxed mb-6">
              IRCTC opens bookings 60 days before the journey date. Popular trains on routes like Delhi–Mumbai, Delhi–Kolkata, and Mumbai–Chennai fill up within hours of opening. Book as early as possible. If you miss the advance booking window, check <Link to="/seat-availability" className="text-primary underline font-medium">Seat Availability</Link> for RAC or waitlist options, or try the Tatkal quota which opens 1 day before departure.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {tips.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Icon size={18} className="text-primary" />
                    <span className="font-semibold text-slate-800 text-sm">{title}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>What to Pack for a Train Journey</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              {[
                { cat: 'Documents', items: ['E-ticket printout or mobile screenshot', 'Original photo ID (Aadhaar/PAN/Passport)', 'Booking confirmation SMS'] },
                { cat: 'Comfort Essentials', items: ['Neck pillow and light blanket (for SL class)', 'Earplugs and eye mask', 'Sanitizer and wet wipes'] },
                { cat: 'Food & Water', items: ['Water bottle (refillable at station taps)', 'Snacks and home-cooked food', 'Small cash for pantry car purchases'] },
                { cat: 'Safety & Security', items: ['Chain lock for your bag', 'Power bank for phone charging', 'Small padlock for luggage'] },
              ].map(({ cat, items }) => (
                <div key={cat} className="border border-slate-200 rounded-xl p-4">
                  <p className="font-semibold text-slate-800 text-sm mb-2">{cat}</p>
                  <ul className="space-y-1">
                    {items.map((item) => (
                      <li key={item} className="text-xs text-slate-600 flex items-start gap-1.5">
                        <span className="text-green-500 mt-0.5">✓</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>At the Station — Boarding Your Train</h2>

            <h3 className="text-base font-bold text-slate-800 mb-2">Finding Your Platform</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              Platform information is displayed on the departure board at the station. You can also check the NTES app or ChaloTrain's <Link to="/live-status" className="text-primary underline font-medium">Live Train Status</Link> for real-time platform information. Note that platform assignments can change, so always verify at the station.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">Finding Your Coach</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              A <strong>Coach Position Chart</strong> is displayed on the platform before the train arrives. It shows the order of coaches from the engine. Coaches are labeled on the outside — Sleeper coaches are labeled S1, S2, S3, etc.; AC 3-tier coaches are B1, B2, B3; AC 2-tier are A1, A2; First AC is H1. Find your coach label on your ticket and locate it on the chart.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">Checking the Reservation Chart</h3>
            <p className="text-slate-600 leading-relaxed mb-6">
              A printed reservation chart is pasted on each reserved coach 4–6 hours before departure. It lists all passengers' names, ages, and berth numbers. Check this chart to confirm your berth. If your name is not on the chart, contact the Train Ticket Examiner (TTE) immediately.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>During the Journey — Comfort & Safety</h2>

            <h3 className="text-base font-bold text-slate-800 mb-2">Berth Etiquette</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              Lower berths are generally preferred by elderly passengers and women. If you have an upper berth, you can use the lower berth as a seat during the day (6 AM to 10 PM). After 10 PM, lower berth passengers have the right to their berth. Always be considerate of fellow passengers.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">Ordering Food</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              Most long-distance trains have a pantry car serving meals, snacks, and beverages. You can also order food from local restaurants at major stations via the IRCTC e-Catering service. Food is delivered directly to your seat. Always check the price before ordering from vendors on the platform.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">Staying Safe</h3>
            <p className="text-slate-600 leading-relaxed mb-6">
              Keep your valuables in your bag and use the chain lock under your berth to secure luggage. Do not accept food or drinks from strangers. Keep your phone charged and share your journey details with family. In case of emergency, pull the emergency chain (only for genuine emergencies — misuse is a punishable offence).
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Plan Your Train Journey</p>
              <p className="text-sm text-slate-600 mb-3">Use ChaloTrain's free tools to search trains, check PNR status, and track your train live.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/train-search" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                  <Train size={15} /> Search Trains
                </Link>
                <Link to="/pnr-status" className="inline-flex items-center gap-2 bg-white border border-primary text-primary px-4 py-2 rounded-xl text-sm font-semibold hover:bg-primary/5 transition-colors">
                  Check PNR Status
                </Link>
              </div>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="Train Travel Tips for Beginners — Complete India Rail Guide 2026" url="https://chalotrain.com/blog/train-travel-tips-for-beginners" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/train-travel-tips-for-beginners" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
