import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Train, Info, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'What is the difference between boarding station and origin station on a ticket?', answer: 'The origin station is where the train starts its journey. The boarding station is where you will actually board the train. These can be different if you are joining the train at an intermediate station.' },
  { question: 'What does "Chart Not Prepared" mean on my ticket?', answer: '"Chart Not Prepared" means the reservation chart for your coach has not been finalized yet. Charts are typically prepared 4–6 hours before departure. Once prepared, your coach and berth number will be assigned.' },
  { question: 'What is the quota code on my train ticket?', answer: 'The quota code indicates which reservation quota your ticket was booked under. GN = General, TQ = Tatkal, PT = Premium Tatkal, LD = Ladies, SS = Senior Citizen, DF = Defence, HP = Divyaang (Persons with Disability).' },
  { question: 'Can I travel if my name is misspelled on the ticket?', answer: 'Minor spelling errors are generally acceptable as long as the TTE can identify you with your photo ID. However, if the name is completely different, you may be asked to deboard. Always double-check passenger names before confirming the booking.' },
  { question: 'What does the distance shown on the ticket mean?', answer: 'The distance in kilometres shown on the ticket is the railway distance between your boarding and destination stations. This is used to calculate the base fare. Railway distance may differ from road distance.' },
];

const ticketFields = [
  { field: 'PNR Number', location: 'Top-left corner', desc: 'Your unique 10-digit Passenger Name Record number. Use this to check booking status on ChaloTrain.' },
  { field: 'Train Number & Name', location: 'Top section', desc: 'The 5-digit train number and the official name of the train (e.g., 12301 HOWRAH RAJDHANI).' },
  { field: 'Date of Journey', location: 'Top section', desc: 'The date on which you will travel. Format is usually DD-MM-YYYY.' },
  { field: 'Class', location: 'Middle section', desc: 'Your travel class: 1A, 2A, 3A, SL, CC, 2S, etc. This determines your coach type and berth.' },
  { field: 'Boarding Station', location: 'Middle section', desc: 'The station where you will board the train, shown with the station code and scheduled departure time.' },
  { field: 'Destination Station', location: 'Middle section', desc: 'Your destination station with the station code and scheduled arrival time.' },
  { field: 'Coach & Berth Number', location: 'Middle section', desc: 'Assigned after chart preparation (4–6 hours before departure). Shows your exact coach (e.g., S4) and berth number (e.g., 32 LB for Lower Berth).' },
  { field: 'Passenger Details', location: 'Lower section', desc: 'Name, age, gender, and concession type for each passenger on the ticket.' },
  { field: 'Fare Breakdown', location: 'Bottom section', desc: 'Total fare paid including base fare, reservation charge, superfast charge (if applicable), and GST.' },
  { field: 'Quota Code', location: 'Near class', desc: 'GN (General), TQ (Tatkal), PT (Premium Tatkal), LD (Ladies), SS (Senior Citizen), etc.' },
];

const berthCodes = [
  { code: 'LB', name: 'Lower Berth', desc: 'Bottom berth — easiest to access, preferred by elderly and women' },
  { code: 'MB', name: 'Middle Berth', desc: 'Middle berth in 3-tier coaches — folds up during the day' },
  { code: 'UB', name: 'Upper Berth', desc: 'Top berth — most privacy but requires climbing' },
  { code: 'SL', name: 'Side Lower', desc: 'Lower side berth — used as seat during day, berth at night' },
  { code: 'SU', name: 'Side Upper', desc: 'Upper side berth — compact but private' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Read Your Train Ticket — Every Field Explained | ChaloTrain",
  "description": "Confused by your Indian Railways ticket? Learn what every field means — PNR, coach, berth codes, quota, fare breakdown, and more. Complete guide with examples.",
  "url": "https://chalotrain.com/blog/how-to-read-train-ticket",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-read-train-ticket"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogReadTrainTicket() {
  return (
    <>
      <title>How to Read Your Train Ticket — Every Field Explained | ChaloTrain</title>
      <meta name="description" content="Confused by your Indian Railways ticket? Learn what every field means — PNR, coach, berth codes, quota, fare breakdown, and more. Complete guide with examples." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Read Your Train Ticket — Every Field Explained" />
      <meta property="og:description" content="Confused by your Indian Railways ticket? Learn what every field means — PNR, coach, berth codes, quota, fare breakdown, and more. Complete guide with examples." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-read-train-ticket" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Read Your Train Ticket — Every Field Explained" />
      <meta name="twitter:description" content="Confused by your Indian Railways ticket? Learn what every field means — PNR, coach, berth codes, quota, fare breakdown, and more. Complete guide with examples." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-read-train-ticket" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">How to Read Your Train Ticket</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-semibold">Ticket Guide</span>
              <span className="text-xs text-slate-400">May 2026 • 7 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              How to Read Your Train Ticket — Every Field Explained
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              An Indian Railways ticket contains a lot of information packed into a small space. This guide decodes every field so you know exactly what your ticket is telling you.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>All Ticket Fields Explained</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Whether you have a printed counter ticket or an IRCTC e-ticket PDF, the information is largely the same. Here is what every field means:
            </p>

            <div className="space-y-3 mb-8">
              {ticketFields.map(({ field, location, desc }) => (
                <div key={field} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <Info size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="font-semibold text-slate-800 text-sm">{field}</span>
                        <span className="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded">{location}</span>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Understanding Berth Codes</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Once the chart is prepared, your ticket shows a berth code. Here is what each code means:
            </p>
            <div className="overflow-x-auto mb-6">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Code</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Berth Type</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Description</th>
                  </tr>
                </thead>
                <tbody>
                  {berthCodes.map(({ code, name, desc }) => (
                    <tr key={code} className="hover:bg-slate-50">
                      <td className="p-3 border border-slate-200 font-bold text-primary">{code}</td>
                      <td className="p-3 border border-slate-200 text-slate-700">{name}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{desc}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Understanding the Fare Breakdown</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              The total fare on your ticket is made up of several components:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-4 pl-2">
              <li><strong>Base Fare:</strong> Calculated based on distance and class of travel</li>
              <li><strong>Reservation Charge:</strong> Fixed charge for reserving a berth (₹15–₹50 depending on class)</li>
              <li><strong>Superfast Charge:</strong> ₹15–₹45 extra for trains running at average speed above 55 km/h</li>
              <li><strong>Tatkal Charge:</strong> Additional charge for Tatkal bookings (varies by class and distance)</li>
              <li><strong>GST:</strong> 5% GST on AC class tickets; no GST on non-AC tickets</li>
              <li><strong>IRCTC Convenience Fee:</strong> ₹15 (non-AC) or ₹30 (AC) per transaction for online bookings</li>
            </ul>
            <p className="text-slate-600 leading-relaxed mb-6">
              Use ChaloTrain's <Link to="/fare-inquiry" className="text-primary underline font-medium">Fare Inquiry</Link> tool to check the exact fare for any train, class, and quota before booking.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>E-Ticket vs Counter Ticket</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {[
                { title: 'E-Ticket (IRCTC)', points: ['Booked online via IRCTC or apps', 'PDF sent to email; show on mobile', 'Must carry original photo ID', 'Auto-cancelled if WL at chart time', 'Can cancel online for refund'] },
                { title: 'Counter Ticket (PRS)', points: ['Booked at railway reservation counter', 'Physical printed ticket', 'No ID required (ID preferred)', 'WL passengers can board and pay TTE', 'Cancel at counter for refund'] },
              ].map(({ title, points }) => (
                <div key={title} className="border border-slate-200 rounded-xl p-4">
                  <p className="font-semibold text-slate-800 text-sm mb-3">{title}</p>
                  <ul className="space-y-1.5">
                    {points.map((p) => (
                      <li key={p} className="text-xs text-slate-600 flex items-start gap-1.5">
                        <span className="text-primary mt-0.5">•</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Check Your PNR Status</p>
              <p className="text-sm text-slate-600 mb-3">Now that you know how to read your ticket, check your PNR status to see your current booking status.</p>
              <Link to="/pnr-status" className="inline-flex items-center gap-2 bg-primary text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                <Train size={16} /> Check PNR Status
              </Link>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="How to Read Your Train Ticket — Every Field Explained" url="https://chalotrain.com/blog/how-to-read-train-ticket" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/how-to-read-train-ticket" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
