import { motion } from 'motion/react';
import { IndianRupee, Clock, AlertCircle, CheckCircle, Info } from 'lucide-react';
import PageHero from '@/components/PageHero';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import LastUpdatedBadge from '@/components/LastUpdatedBadge';
import AppDownloadCTA from '@/components/AppDownloadCTA';

const faqs = [
  { question: 'Can I cancel my train ticket online?', answer: 'Yes, you can cancel train tickets online through the IRCTC website or mobile app. E-tickets can be cancelled up to 30 minutes before departure for AC classes and 4 hours for non-AC classes. Counter tickets must be cancelled at the railway reservation counter.' },
  { question: 'How much refund will I get if I cancel my ticket?', answer: 'Refund amount depends on when you cancel. More than 48 hours before departure: Full fare minus clerkage charges (₹60 for AC, ₹30 for non-AC). Between 48-12 hours: 25% cancellation charges. Between 12-4 hours: 50% cancellation charges. Less than 4 hours: No refund (except in case of train cancellation).' },
  { question: 'What happens if the train is cancelled by Indian Railways?', answer: 'If the train is cancelled by Indian Railways, you get a full refund of the ticket fare with no cancellation charges. The refund is automatically processed to your original payment method within 7-10 working days. You don\'t need to file a TDR for train cancellations.' },
  { question: 'Can I get a refund for a waitlisted ticket?', answer: 'Yes, waitlisted tickets are automatically cancelled and full refund is processed if the ticket doesn\'t get confirmed by chart preparation (usually 4 hours before departure). You don\'t need to manually cancel WL tickets. Refund is credited within 7-10 working days.' },
  { question: 'How long does it take to receive the refund?', answer: 'Refunds are typically processed within 7-10 working days for online bookings. For credit/debit card payments, it may take an additional 5-7 days for the amount to reflect in your account. For UPI/net banking, refunds are usually faster (3-5 days).' },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Train Ticket Cancellation & Refund Rules 2026 - Complete Guide",
  "description": "Complete guide to Indian Railways ticket cancellation and refund rules. Learn cancellation charges, refund timelines, and how to cancel tickets online.",
  "url": "https://chalotrain.com/blog/train-ticket-cancellation-refund-rules",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/train-ticket-cancellation-refund-rules"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function TrainTicketCancellationRefundRulesPage() {
  return (
    <>
      <title>Train Ticket Cancellation & Refund Rules 2026 - Complete Guide</title>
      <meta name="description" content="Complete guide to Indian Railways ticket cancellation and refund rules. Learn cancellation charges, refund timelines, and how to cancel tickets online." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/train-ticket-cancellation-refund-rules" />
      
      {/* Open Graph */}
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Train Ticket Cancellation & Refund Rules 2026 - Complete Guide" />
      <meta property="og:description" content="Complete guide to Indian Railways ticket cancellation and refund rules. Learn cancellation charges, refund timelines, and how to cancel tickets online." />
      <meta property="og:url" content="https://chalotrain.com/blog/train-ticket-cancellation-refund-rules" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Train Ticket Cancellation & Refund Rules 2026 - Complete Guide" />
      <meta name="twitter:description" content="Complete guide to Indian Railways ticket cancellation and refund rules. Learn cancellation charges, refund timelines, and how to cancel tickets online." />
      <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />

      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        title="Train Ticket Cancellation & Refund Rules"
        subtitle="Complete guide to cancellation charges, refund timelines, and online cancellation process"
        icon={IndianRupee}
      />
      <h1 className="sr-only">Train Ticket Cancellation &amp; Refund Rules 2026 — Complete Guide</h1>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <motion.article
          initial="hidden"
          animate="visible"
          variants={fadeUp}
          className="prose prose-slate max-w-none"
        >
          {/* Last Updated Badge */}
          <LastUpdatedBadge label="2026-04-20" />

          {/* Introduction */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8 border border-blue-100">
            <p className="text-lg text-slate-700 leading-relaxed mb-0">
              Understanding <strong>train ticket cancellation and refund rules</strong> can save you money and hassle. Indian Railways has specific guidelines for cancellation charges based on ticket type, class, and timing. This comprehensive guide covers everything you need to know about cancelling tickets and getting refunds in 2026.
            </p>
          </div>

          {/* Cancellation Charges Table */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Cancellation Charges by Timing
            </h2>

            <div className="overflow-x-auto mb-6">
              <table className="w-full border-collapse bg-white rounded-xl overflow-hidden shadow-sm">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                    <th className="px-4 py-3 text-left text-sm font-semibold">Cancellation Time</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">AC Classes</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold">Non-AC Classes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">More than 48 hours</td>
                    <td className="px-4 py-3 text-slate-700">₹240 flat + GST</td>
                    <td className="px-4 py-3 text-slate-700">₹120 flat + GST</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">48 hours to 12 hours</td>
                    <td className="px-4 py-3 text-slate-700">25% of fare + ₹240</td>
                    <td className="px-4 py-3 text-slate-700">25% of fare + ₹120</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">12 hours to 4 hours</td>
                    <td className="px-4 py-3 text-slate-700">50% of fare</td>
                    <td className="px-4 py-3 text-slate-700">50% of fare</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-semibold text-slate-800">Less than 4 hours</td>
                    <td className="px-4 py-3 text-red-600 font-semibold">No refund</td>
                    <td className="px-4 py-3 text-red-600 font-semibold">No refund</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <AlertCircle className="text-amber-600 flex-shrink-0 mt-0.5" size={20} />
                <div>
                  <p className="text-sm text-amber-900 font-semibold mb-2">Important Notes:</p>
                  <ul className="text-sm text-amber-800 space-y-1 mb-0">
                    <li>• Clerkage charges: ₹60 for AC classes, ₹30 for non-AC classes</li>
                    <li>• GST is applicable on cancellation charges</li>
                    <li>• Tatkal tickets have different cancellation rules (see below)</li>
                    <li>• Premium Tatkal tickets are non-refundable</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Online Cancellation Process */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-blue-500 to-indigo-500 p-3 rounded-xl">
                <Clock className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                How to Cancel Tickets Online
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-6 mb-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-4">Step-by-Step Process</h3>
              
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">1</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Login to IRCTC</h4>
                    <p className="text-sm text-slate-600">Visit irctc.co.in or open the IRCTC Rail Connect app and login with your credentials.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">2</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Go to Booked Tickets</h4>
                    <p className="text-sm text-slate-600">Navigate to "My Transactions" → "Booked Ticket History" to view all your bookings.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">3</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Select Ticket to Cancel</h4>
                    <p className="text-sm text-slate-600">Find the ticket you want to cancel and click on "Cancel Ticket" button.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">4</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Choose Passengers</h4>
                    <p className="text-sm text-slate-600">Select which passengers' tickets you want to cancel (you can cancel partial tickets).</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">5</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Review Refund Amount</h4>
                    <p className="text-sm text-slate-600">Check the refund amount after deducting cancellation charges. Confirm if acceptable.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">6</div>
                  <div>
                    <h4 className="font-semibold text-slate-800 mb-1">Confirm Cancellation</h4>
                    <p className="text-sm text-slate-600">Click "Confirm" to complete the cancellation. You'll receive a confirmation SMS and email.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <CheckCircle className="text-green-600 flex-shrink-0 mt-0.5" size={20} />
                <div>
                  <p className="text-sm text-green-900 font-semibold mb-2">Online Cancellation Deadlines:</p>
                  <ul className="text-sm text-green-800 space-y-1 mb-0">
                    <li>• <strong>AC Classes:</strong> Up to 30 minutes before departure</li>
                    <li>• <strong>Non-AC Classes:</strong> Up to 4 hours before departure</li>
                    <li>• <strong>Tatkal Tickets:</strong> Cannot be cancelled online (only at counter)</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          {/* Special Cases */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Special Cancellation Cases
            </h2>

            <div className="grid md:grid-cols-2 gap-6">
              {/* Tatkal Tickets */}
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-orange-100 p-2 rounded-lg">
                    <AlertCircle className="text-orange-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">Tatkal Tickets</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>❌ <strong>No online cancellation</strong> allowed</li>
                  <li>✅ Can be cancelled at <strong>railway counter only</strong></li>
                  <li>💰 <strong>No refund</strong> except in case of train cancellation</li>
                  <li>⏰ Must cancel before chart preparation</li>
                  <li>🎫 Premium Tatkal is <strong>completely non-refundable</strong></li>
                </ul>
              </div>

              {/* Waitlisted Tickets */}
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-blue-100 p-2 rounded-lg">
                    <Info className="text-blue-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">Waitlisted Tickets</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ <strong>Auto-cancelled</strong> if not confirmed by chart preparation</li>
                  <li>💰 <strong>Full refund</strong> processed automatically</li>
                  <li>⏰ No manual cancellation needed</li>
                  <li>📧 Refund confirmation sent via email/SMS</li>
                  <li>🕐 Refund credited in 7-10 working days</li>
                </ul>
              </div>

              {/* RAC Tickets */}
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-purple-100 p-2 rounded-lg">
                    <Clock className="text-purple-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">RAC Tickets</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ Can be <strong>cancelled online</strong></li>
                  <li>💰 Standard cancellation charges apply</li>
                  <li>⏰ Same deadlines as confirmed tickets</li>
                  <li>🎫 Partial cancellation allowed</li>
                  <li>📱 Refund processed to original payment method</li>
                </ul>
              </div>

              {/* Train Cancelled by Railways */}
              <div className="bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="bg-green-100 p-2 rounded-lg">
                    <CheckCircle className="text-green-600" size={20} />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-0">Train Cancelled</h3>
                </div>
                <ul className="space-y-2 text-sm text-slate-700">
                  <li>✅ <strong>Full refund</strong> with no charges</li>
                  <li>💰 Includes all classes and ticket types</li>
                  <li>⏰ Auto-processed within 3-5 days</li>
                  <li>🎫 No TDR filing required</li>
                  <li>📧 Confirmation sent automatically</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Refund Timeline */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-br from-green-500 to-teal-500 p-3 rounded-xl">
                <IndianRupee className="text-white" size={24} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-0" style={{ fontFamily: 'var(--font-heading)' }}>
                Refund Processing Timeline
              </h2>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
              <div className="divide-y divide-slate-200">
                <div className="p-5 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">1</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 mb-1">Cancellation Confirmed</h3>
                      <p className="text-sm text-slate-600 mb-2">You receive immediate confirmation via SMS and email after cancelling the ticket.</p>
                      <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">Instant</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">2</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 mb-1">Refund Initiated</h3>
                      <p className="text-sm text-slate-600 mb-2">IRCTC processes the refund and initiates transfer to your bank/payment method.</p>
                      <span className="text-xs font-semibold text-green-600 bg-green-50 px-2 py-1 rounded">3-5 working days</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold">3</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 mb-1">Bank Processing</h3>
                      <p className="text-sm text-slate-600 mb-2">Your bank processes the refund and credits it to your account.</p>
                      <span className="text-xs font-semibold text-orange-600 bg-orange-50 px-2 py-1 rounded">5-7 working days</span>
                    </div>
                  </div>
                </div>

                <div className="p-5 hover:bg-slate-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold">✓</div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-800 mb-1">Refund Credited</h3>
                      <p className="text-sm text-slate-600 mb-2">Amount reflects in your bank account/card statement.</p>
                      <span className="text-xs font-semibold text-green-600 bg-green-50 px-2 py-1 rounded">Total: 7-10 working days</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-5">
              <p className="text-sm text-blue-900 mb-2"><strong>Faster Refunds:</strong></p>
              <ul className="text-sm text-blue-800 space-y-1 mb-0">
                <li>• UPI payments: 3-5 days (fastest)</li>
                <li>• Net Banking: 5-7 days</li>
                <li>• Credit/Debit Cards: 7-10 days (slowest)</li>
                <li>• IRCTC Wallet: Instant refund to wallet balance</li>
              </ul>
            </div>
          </section>

          {/* Tips Section */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
              Pro Tips to Maximize Refunds
            </h2>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-blue-900 mb-3">✅ Do's</h3>
                <ul className="space-y-2 text-blue-800 text-sm">
                  <li>✓ Cancel as early as possible to minimize charges</li>
                  <li>✓ Check refund amount before confirming cancellation</li>
                  <li>✓ Save cancellation confirmation SMS/email</li>
                  <li>✓ Use IRCTC wallet for instant refunds</li>
                  <li>✓ File TDR if train is delayed by 3+ hours</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-red-50 to-orange-50 border border-red-200 rounded-xl p-5">
                <h3 className="text-lg font-semibold text-red-900 mb-3">❌ Don'ts</h3>
                <ul className="space-y-2 text-red-800 text-sm">
                  <li>✗ Don't wait until last minute to cancel</li>
                  <li>✗ Don't expect refund for no-show tickets</li>
                  <li>✗ Don't cancel Tatkal tickets online (won't work)</li>
                  <li>✗ Don't forget to check cancellation deadline</li>
                  <li>✗ Don't cancel WL tickets manually (auto-cancelled)</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Conclusion */}
          <section className="mb-12">
            <div className="bg-gradient-to-br from-blue-900 to-indigo-900 text-white rounded-2xl p-8">
              <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                Key Takeaways
              </h2>
              <div className="space-y-3 text-blue-100">
                <p>✓ Cancel <strong>more than 48 hours</strong> before departure for minimum charges</p>
                <p>✓ Online cancellation deadline: <strong>30 minutes (AC)</strong> or <strong>4 hours (non-AC)</strong> before departure</p>
                <p>✓ Waitlisted tickets get <strong>automatic full refund</strong> if not confirmed</p>
                <p>✓ Tatkal tickets can only be cancelled at <strong>railway counter</strong></p>
                <p>✓ Refunds take <strong>7-10 working days</strong> to credit (faster with UPI)</p>
                <p>✓ Train cancellation by Railways = <strong>Full refund with no charges</strong></p>
              </div>
            </div>
          </section>

          {/* CTA */}
          <AppDownloadCTA />
        </motion.article>

        {/* Social Share */}
        <div className="mt-12">
          <SocialShareBar
            title="Train Ticket Cancellation & Refund Rules 2026"
            url="https://chalotrain.com/blog/train-ticket-cancellation-refund-rules"
          />
        </div>

        {/* Related Tools */}
        <div className="mt-12">
          <RelatedTools currentHref="/blog" />
        </div>

        {/* FAQ Section */}
        <div className="mt-12">
          <FAQSection items={faqs} />
        </div>
      </div>
    </>
  );
}
