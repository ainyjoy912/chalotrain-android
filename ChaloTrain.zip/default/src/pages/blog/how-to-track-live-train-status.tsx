import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Train, MapPin, Clock, Wifi, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'How accurate is the live train status?', answer: 'Live train status on ChaloTrain is sourced from the National Train Enquiry System (NTES) maintained by Indian Railways. It is updated every few minutes as the train passes through stations. Accuracy is generally high, though remote areas with poor connectivity may have slight delays in updates.' },
  { question: 'Can I track a train without knowing the train number?', answer: 'Yes. You can search by train name on ChaloTrain. Enter the partial name (e.g., "Rajdhani") and select your train from the suggestions. You can also find the train number on your ticket or by using the Train Search tool.' },
  { question: 'Why does live status show "No data available" for some trains?', answer: 'Some trains, especially short-distance passenger trains and DEMU/MEMU services, may not have station-based GPS tracking data. Live status is most reliable for long-distance express and mail trains.' },
  { question: 'How do I know which platform my train will arrive on?', answer: 'Platform information is updated in the live status as the train approaches the station. Check ChaloTrain\'s Live Status 30–60 minutes before the expected arrival. Platform assignments can change, so always verify at the station display boards.' },
  { question: 'Can I track a train that has not yet started its journey?', answer: 'Yes. You can check the scheduled status of a train before it departs. The live status will show "Not Yet Started" or "At Origin" until the train begins its journey.' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Track Live Train Status — Real-Time Train Tracking Guide | ChaloTrain",
  "description": "Learn how to track your train's live running status in real-time. Know exactly where your train is, how late it is running, and when it will arrive at your station.",
  "url": "https://chalotrain.com/blog/how-to-track-live-train-status",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-track-live-train-status"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogTrackLiveTrainStatus() {
  return (
    <>
      <title>How to Track Live Train Status — Live Train Tracking Guide | ChaloTrain</title>
      <meta name="description" content="Learn how to track your train's live running status. Know where your train is, how late it is running, and when it will arrive at your station." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Track Live Train Status — Live Train Tracking Guide" />
      <meta property="og:description" content="Learn how to track your train's live running status. Know where your train is, how late it is running, and when it will arrive at your station." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-track-live-train-status" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Track Live Train Status — Live Train Tracking Guide" />
      <meta name="twitter:description" content="Learn how to track your train's live running status. Know where your train is, how late it is running, and when it will arrive at your station." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-track-live-train-status" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">How to Track Live Train Status</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full font-semibold">Live Tracking</span>
              <span className="text-xs text-slate-400">May 2026 • 7 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              How to Track Live Train Status — Live Train Tracking Guide
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              Indian trains are notorious for running late. Live train tracking tells you exactly where your train is right now, how many minutes it is running behind schedule, and when it will reach your station.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Why Track Live Train Status?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Live train tracking is useful in many situations:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li><strong>Waiting at the station:</strong> Know exactly when your train will arrive so you do not have to wait on the platform for hours.</li>
              <li><strong>Picking up passengers:</strong> Track a friend or family member's train to know when to leave for the station.</li>
              <li><strong>Connecting trains:</strong> If you have a connecting train, check if your first train is running late to plan accordingly.</li>
              <li><strong>TDR filing:</strong> If your train is running more than 3 hours late, you may be eligible for a refund. Live status helps you document the delay.</li>
              <li><strong>General peace of mind:</strong> Know your train is on its way and not cancelled or diverted.</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Track Live Train Status on ChaloTrain</h2>
            <ol className="list-none space-y-3 mb-6">
              {[
                'Go to the Live Train Status page on ChaloTrain.',
                'Enter your 5-digit train number (e.g., 12301 for Howrah Rajdhani).',
                'Select the date of journey from the date picker.',
                'Click "Track Train" to see the live running status.',
                'View the station-by-station status showing actual vs scheduled times.',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <span className="text-slate-600 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <Wifi size={20} className="text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-blue-800 mb-1">Live Data</p>
                <p className="text-sm text-blue-700">ChaloTrain's live status is powered by the National Train Enquiry System (NTES) and updates every few minutes as the train passes through stations.</p>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Understanding the Live Status Display</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              The live status page shows a timeline of all stations on the train's route. Here is what each element means:
            </p>
            <div className="space-y-3 mb-6">
              {[
                { icon: MapPin, color: 'text-green-600', label: 'Current Location', desc: 'The last station the train has passed or is currently at. Shown with a green indicator.' },
                { icon: Clock, color: 'text-blue-600', label: 'Scheduled Time (STA/STD)', desc: 'The original timetable time for arrival (STA) and departure (STD) at each station.' },
                { icon: Clock, color: 'text-orange-600', label: 'Actual/Expected Time (ETA/ETD)', desc: 'The actual time the train arrived/departed (for past stations) or the expected time (for future stations) based on current delay.' },
                { icon: Train, color: 'text-red-600', label: 'Delay', desc: 'How many minutes the train is running behind schedule. Shown in red if delayed, green if on time.' },
              ].map(({ icon: Icon, color, label, desc }) => (
                <div key={label} className="border border-slate-200 rounded-xl p-4 flex items-start gap-3">
                  <Icon size={18} className={`${color} mt-0.5 flex-shrink-0`} />
                  <div>
                    <p className="font-semibold text-slate-800 text-sm mb-1">{label}</p>
                    <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How Live Train Tracking Works</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Indian Railways uses a combination of technologies to track train positions:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-4 pl-2">
              <li><strong>Station-based reporting:</strong> Station masters report train arrivals and departures to the central system. This is the primary data source for most trains.</li>
              <li><strong>GPS tracking:</strong> Some modern trains are equipped with GPS devices that provide location data where available, supplementing station-based updates.</li>
              <li><strong>NTES (National Train Enquiry System):</strong> All data is aggregated by NTES, which is the official Indian Railways train tracking system. ChaloTrain uses this data to provide live status.</li>
            </ul>
            <p className="text-slate-600 leading-relaxed mb-6">
              The accuracy of live status depends on how recently the train passed through a station with good connectivity. In remote areas, there may be a delay of 15–30 minutes in status updates.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Other Ways to Track Train Status</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {[
                { method: 'SMS to 139', desc: 'Send "TRAIN <number> <date>" to 139. Works without internet.' },
                { method: 'NTES App', desc: 'Official Indian Railways app. Download from Play Store or App Store.' },
                { method: 'Call 139', desc: 'Call the national railway enquiry number for live status.' },
                { method: 'Station Display Boards', desc: 'Real-time arrival/departure boards at all major stations.' },
              ].map(({ method, desc }) => (
                <div key={method} className="border border-slate-200 rounded-xl p-4">
                  <p className="font-semibold text-slate-800 text-sm mb-1">{method}</p>
                  <p className="text-xs text-slate-600">{desc}</p>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Track Your Train Now</p>
              <p className="text-sm text-slate-600 mb-3">Get real-time running status for any Indian Railways train.</p>
              <Link to="/live-status" className="inline-flex items-center gap-2 bg-primary text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                <Train size={16} /> Track Live Status
              </Link>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="How to Track Live Train Status — Real-Time Train Tracking Guide" url="https://chalotrain.com/blog/how-to-track-live-train-status" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/how-to-track-live-train-status" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
