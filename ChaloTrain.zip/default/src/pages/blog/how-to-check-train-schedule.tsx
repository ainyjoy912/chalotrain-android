import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Clock, Train, MapPin, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'What is the difference between train schedule and live status?', answer: 'Train schedule shows the fixed timetable — the planned arrival and departure times at every station. Live status shows the actual real-time position of the train on a specific date, including any delays. Use schedule for planning; use live status on the day of travel.' },
  { question: 'Do train schedules change?', answer: 'Yes. Indian Railways periodically revises train schedules, especially during timetable changes (usually in June). Trains may also have temporary schedule changes during special occasions or maintenance work. Always verify the current schedule before travel.' },
  { question: 'How do I find the station code for my station?', answer: 'Station codes are 2–7 letter abbreviations. Common examples: NDLS (New Delhi), BCT (Mumbai Central), HWH (Howrah), MAS (Chennai Central), SBC (Bengaluru City). You can find station codes on your ticket or by searching on ChaloTrain.' },
  { question: 'What does "halt duration" mean in a train schedule?', answer: 'Halt duration is the time the train stops at a station. For example, a 2-minute halt means the train stops for 2 minutes before continuing. Major stations typically have longer halts (5–10 minutes) while smaller stations may have 1–2 minute halts.' },
  { question: 'Can I board a train at an intermediate station?', answer: 'Yes. You can board a train at any intermediate station on its route, as long as you have a valid ticket from that station. Your ticket will show the boarding station and the scheduled departure time from that station.' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Check Train Schedule — Complete Timetable Guide | ChaloTrain",
  "description": "Learn how to check the complete schedule of any Indian Railways train. Understand timetables, halt durations, platform numbers, and how to plan your journey.",
  "url": "https://chalotrain.com/blog/how-to-check-train-schedule",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-check-train-schedule"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogCheckTrainSchedule() {
  return (
    <>
      <title>How to Check Train Schedule — Complete Timetable Guide | ChaloTrain</title>
      <meta name="description" content="Learn how to check the complete schedule of any Indian Railways train. Understand timetables, halt durations, platform numbers, and how to plan your journey." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Check Train Schedule — Complete Timetable Guide" />
      <meta property="og:description" content="Learn how to check the complete schedule of any Indian Railways train. Understand timetables, halt durations, platform numbers, and how to plan your journey." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-check-train-schedule" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Check Train Schedule — Complete Timetable Guide" />
      <meta name="twitter:description" content="Learn how to check the complete schedule of any Indian Railways train. Understand timetables, halt durations, platform numbers, and how to plan your journey." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-check-train-schedule" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">How to Check Train Schedule</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-cyan-100 text-cyan-700 px-3 py-1 rounded-full font-semibold">Train Schedule</span>
              <span className="text-xs text-slate-400">May 2026 • 7 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              How to Check Train Schedule — Complete Timetable Guide
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              A train's schedule tells you exactly when it arrives and departs from every station on its route. This is essential for planning connections, picking up passengers, and understanding your journey timeline.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Why Check the Train Schedule?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              The train schedule (also called timetable) is useful for:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li><strong>Planning connections:</strong> If you need to catch a connecting train, check both schedules to ensure enough time between arrivals and departures.</li>
              <li><strong>Picking up passengers:</strong> Know the exact arrival time at your station so you can plan when to leave for the station.</li>
              <li><strong>Boarding at intermediate stations:</strong> Find the scheduled departure time from your boarding station.</li>
              <li><strong>Estimating journey time:</strong> Calculate total travel time including halts at major stations.</li>
              <li><strong>Finding intermediate stations:</strong> Discover which cities and towns the train passes through.</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Check Train Schedule on ChaloTrain</h2>
            <ol className="list-none space-y-3 mb-6">
              {[
                'Go to the Train Schedule page on ChaloTrain.',
                'Enter the 5-digit train number (e.g., 12301 for Howrah Rajdhani Express).',
                'Click "Get Schedule" to view the complete timetable.',
                'Browse the station-by-station schedule with arrival times, departure times, halt duration, platform number, and distance from source.',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <span className="text-slate-600 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Understanding the Train Schedule</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              A train schedule shows the following information for each station:
            </p>
            <div className="space-y-3 mb-6">
              {[
                { icon: MapPin, label: 'Station Name & Code', desc: 'The name of the station and its 2–7 letter code (e.g., NDLS for New Delhi, BCT for Mumbai Central).' },
                { icon: Clock, label: 'Arrival Time (STA)', desc: 'The scheduled time the train arrives at the station. Shown as "--" for the origin station.' },
                { icon: Clock, label: 'Departure Time (STD)', desc: 'The scheduled time the train departs from the station. Shown as "--" for the terminal station.' },
                { icon: Clock, label: 'Halt Duration', desc: 'How long the train stops at the station. Ranges from 1 minute at small stations to 10+ minutes at major junctions.' },
                { icon: Train, label: 'Platform Number', desc: 'The platform from which the train departs. Note: Platform numbers can change on the day of travel.' },
                { icon: MapPin, label: 'Distance from Source', desc: 'The cumulative distance in kilometres from the train\'s origin station to this station.' },
              ].map(({ icon: Icon, label, desc }) => (
                <div key={label} className="border border-slate-200 rounded-xl p-4 flex items-start gap-3">
                  <Icon size={16} className="text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-slate-800 text-sm mb-1">{label}</p>
                    <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Reading Day Numbers in Train Schedules</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Long-distance trains that run overnight show day numbers next to arrival/departure times. Here is how to read them:
            </p>
            <div className="bg-slate-50 rounded-xl p-4 mb-6">
              <ul className="space-y-2 text-sm text-slate-600">
                <li><strong>Day 1:</strong> The day the train departs from its origin station</li>
                <li><strong>Day 2:</strong> The next calendar day (e.g., if the train departs on Monday, Day 2 is Tuesday)</li>
                <li><strong>Day 3:</strong> Two days after departure (for very long-distance trains)</li>
              </ul>
              <p className="text-xs text-slate-400 mt-3">Example: If Howrah Rajdhani departs Delhi on Monday at 4:55 PM, and Mumbai Central shows "Day 2 08:50", it arrives on Tuesday at 8:50 AM.</p>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Find a Train Number</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              If you know the train name but not the number, here are ways to find it:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li>Check your ticket — the train number is printed prominently</li>
              <li>Use ChaloTrain's <Link to="/train-search" className="text-primary underline font-medium">Train Search</Link> to find trains between stations — results show train numbers</li>
              <li>Search by train name on the Train Schedule page</li>
              <li>Call 139 (National Railway Enquiry) and ask for the train number by name</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Train Schedule vs Live Status — When to Use Which</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {[
                { title: 'Use Train Schedule when...', points: ['Planning your journey in advance', 'Checking if a train stops at your station', 'Calculating journey duration', 'Finding connecting train options', 'Checking platform numbers (approximate)'] },
                { title: 'Use Live Status when...', points: ['Travelling on the day of journey', 'Waiting at the station for a train', 'Picking up passengers', 'Checking actual delay', 'Filing TDR for late trains'] },
              ].map(({ title, points }) => (
                <div key={title} className="border border-slate-200 rounded-xl p-4">
                  <p className="font-semibold text-slate-800 text-sm mb-3">{title}</p>
                  <ul className="space-y-1.5">
                    {points.map((p) => (
                      <li key={p} className="text-xs text-slate-600 flex items-start gap-1.5">
                        <span className="text-primary mt-0.5">•</span> {p}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Check Train Schedule Now</p>
              <p className="text-sm text-slate-600 mb-3">View the complete timetable for any Indian Railways train.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/train-schedule" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                  <Clock size={15} /> View Train Schedule
                </Link>
                <Link to="/live-status" className="inline-flex items-center gap-2 bg-white border border-primary text-primary px-4 py-2 rounded-xl text-sm font-semibold hover:bg-primary/5 transition-colors">
                  Track Live Status
                </Link>
              </div>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="How to Check Train Schedule — Complete Timetable Guide" url="https://chalotrain.com/blog/how-to-check-train-schedule" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/how-to-check-train-schedule" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
