import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Train, CreditCard, ShieldCheck, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'Is IRCTC the only way to book train tickets online?', answer: 'No. While IRCTC is the official platform, you can also book through authorized agents like MakeMyTrip, Cleartrip, Paytm, and RailYatri. However, IRCTC is the most reliable and charges the lowest convenience fee.' },
  { question: 'How many tickets can I book per month on IRCTC?', answer: 'A regular IRCTC user can book up to 6 tickets per month. If you complete Aadhaar-based verification, the limit increases to 12 tickets per month.' },
  { question: 'What is the IRCTC convenience fee?', answer: 'IRCTC charges a convenience fee of ₹15 + GST for non-AC class tickets and ₹30 + GST for AC class tickets per transaction. This fee is non-refundable even if you cancel the ticket.' },
  { question: 'Can I book tickets for someone else on IRCTC?', answer: 'Yes. You can add other passengers while booking. You do not need a separate account for each passenger. However, the booking is linked to your IRCTC account.' },
  { question: 'What payment methods does IRCTC accept?', answer: 'IRCTC accepts UPI (GPay, PhonePe, Paytm), credit/debit cards, net banking, IRCTC wallet, and EMI options. UPI is the fastest and most reliable payment method.' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "IRCTC Ticket Booking Complete Guide 2026 — Step by Step | ChaloTrain",
  "description": "Complete step-by-step guide to booking train tickets on IRCTC in 2026. Account creation, train search, seat selection, payment, and ticket download explained.",
  "url": "https://chalotrain.com/blog/irctc-complete-booking-guide",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/irctc-complete-booking-guide"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogIRCTCCompleteGuide() {
  return (
    <>
      <title>IRCTC Ticket Booking Complete Guide 2026 — Step by Step | ChaloTrain</title>
      <meta name="description" content="Complete step-by-step guide to booking train tickets on IRCTC in 2026. Account creation, train search, seat selection, payment, and ticket download explained." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="IRCTC Ticket Booking Complete Guide 2026 — Step by Step" />
      <meta property="og:description" content="Complete step-by-step guide to booking train tickets on IRCTC in 2026. Account creation, train search, seat selection, payment, and ticket download explained." />
      <meta property="og:url" content="https://chalotrain.com/blog/irctc-complete-booking-guide" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="IRCTC Ticket Booking Complete Guide 2026 — Step by Step" />
      <meta name="twitter:description" content="Complete step-by-step guide to booking train tickets on IRCTC in 2026. Account creation, train search, seat selection, payment, and ticket download explained." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/irctc-complete-booking-guide" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">IRCTC Complete Booking Guide</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-semibold">Booking Guide</span>
              <span className="text-xs text-slate-400">May 2026 • 10 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              IRCTC Ticket Booking Complete Guide 2026 — Step by Step
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              Booking train tickets on IRCTC can feel overwhelming for first-timers. This comprehensive guide walks you through every step — from creating your account to downloading your e-ticket.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Step 1: Create Your IRCTC Account</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Before you can book tickets, you need a free IRCTC account. Visit <strong>irctc.co.in</strong> and click "Register". You will need to provide:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-4 pl-2">
              <li>A unique username (6–35 characters, letters and numbers only)</li>
              <li>A strong password</li>
              <li>Your full name, date of birth, and gender</li>
              <li>A valid mobile number (for OTP verification)</li>
              <li>A valid email address</li>
              <li>Your occupation and residential address</li>
            </ul>
            <p className="text-slate-600 leading-relaxed mb-6">
              After submitting the form, verify your mobile number and email via OTP. Your account is ready to use immediately after verification.
            </p>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <ShieldCheck size={20} className="text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-amber-800 mb-1">Security Tip</p>
                <p className="text-sm text-amber-700">Never share your IRCTC username or password with anyone. IRCTC will never ask for your password via phone or email. Beware of phishing websites that look like IRCTC.</p>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Step 2: Search for Trains</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Log in to IRCTC and go to the "Book Ticket" section. Enter:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-4 pl-2">
              <li><strong>From Station:</strong> Your boarding station (type the name or station code)</li>
              <li><strong>To Station:</strong> Your destination station</li>
              <li><strong>Date of Journey:</strong> Select from the calendar (bookings open 60 days in advance)</li>
              <li><strong>Class:</strong> Select your preferred class (1A, 2A, 3A, SL, etc.)</li>
              <li><strong>Quota:</strong> General, Tatkal, Ladies, Senior Citizen, etc.</li>
            </ul>
            <p className="text-slate-600 leading-relaxed mb-4">
              Click "Find Trains" to see all available trains. You can also use ChaloTrain's <Link to="/train-search" className="text-primary underline font-medium">Train Search</Link> to check availability before going to IRCTC.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Step 3: Check Seat Availability</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              The search results show all trains with their departure and arrival times, duration, and available classes. For each train, you can see:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-4 pl-2">
              <li>Available seats in each class (shown as a number or "AVL")</li>
              <li>RAC status (e.g., "RAC 5" means 5 RAC berths available)</li>
              <li>Waitlist position (e.g., "WL 12" means 12 people on waitlist)</li>
              <li>Fare for each class</li>
            </ul>
            <p className="text-slate-600 leading-relaxed mb-6">
              Use ChaloTrain's <Link to="/seat-availability" className="text-primary underline font-medium">Seat Availability</Link> tool to check availability across multiple dates at once before deciding.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Step 4: Select Train and Add Passengers</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Click "Book Now" on your chosen train and class. On the passenger details page:
            </p>
            <ol className="list-none space-y-3 mb-6">
              {[
                'Add passenger details: name, age, gender, and berth preference (lower, middle, upper, side-lower, side-upper).',
                'Add up to 6 passengers per booking (4 for Tatkal).',
                'Enter your mobile number for SMS alerts.',
                'Select "Auto Upgrade" if you want to be upgraded to a higher class if your chosen class is full.',
                'Choose "Consider for Alternate Train" to be automatically moved to another train if your chosen train has no availability.',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <span className="text-slate-600 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Step 5: Review and Pay</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Review your booking summary carefully. Check the train name, date, passenger details, and total fare including the IRCTC convenience fee. Then proceed to payment.
            </p>
            <div className="grid grid-cols-2 gap-3 mb-6">
              {[
                { icon: CreditCard, title: 'UPI', desc: 'GPay, PhonePe, Paytm — fastest option' },
                { icon: CreditCard, title: 'Debit/Credit Card', desc: 'Visa, Mastercard, RuPay accepted' },
                { icon: CreditCard, title: 'Net Banking', desc: 'All major banks supported' },
                { icon: CreditCard, title: 'IRCTC Wallet', desc: 'Pre-loaded wallet for quick checkout' },
              ].map(({ icon: Icon, title, desc }) => (
                <div key={title} className="border border-slate-200 rounded-xl p-3 flex items-start gap-2">
                  <Icon size={16} className="text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{title}</p>
                    <p className="text-xs text-slate-500">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Step 6: Download Your E-Ticket</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              After successful payment, your e-ticket is generated instantly. You can:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li>Download the PDF from your IRCTC account under "Booked Ticket History"</li>
              <li>Print the ticket or show it on your mobile phone during the journey</li>
              <li>The ticket will also be sent to your registered email and mobile number</li>
            </ul>
            <p className="text-slate-600 leading-relaxed mb-6">
              For e-tickets, you must carry a valid government-issued photo ID (Aadhaar, PAN, Passport, Voter ID, or Driving License) during the journey. The ID must match the name on the ticket.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Important IRCTC Booking Rules</h2>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li>Advance booking opens <strong>60 days before</strong> the journey date (excluding the date of journey)</li>
              <li>Tatkal booking opens <strong>1 day before</strong> departure (AC classes at 10 AM, non-AC at 11 AM)</li>
              <li>Maximum <strong>6 passengers</strong> per booking (4 for Tatkal)</li>
              <li>Maximum <strong>6 tickets per month</strong> per account (12 with Aadhaar verification)</li>
              <li>Children below 5 years travel free without a berth; children 5–11 years get a half-fare berth</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Plan Your Journey with ChaloTrain</p>
              <p className="text-sm text-slate-600 mb-3">Check train availability, seat status, and fares before heading to IRCTC.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/train-search" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                  <Train size={15} /> Search Trains
                </Link>
                <Link to="/seat-availability" className="inline-flex items-center gap-2 bg-white border border-primary text-primary px-4 py-2 rounded-xl text-sm font-semibold hover:bg-primary/5 transition-colors">
                  Check Seat Availability
                </Link>
              </div>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="IRCTC Ticket Booking Complete Guide 2026" url="https://chalotrain.com/blog/irctc-complete-booking-guide" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/irctc-complete-booking-guide" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
