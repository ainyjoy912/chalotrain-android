import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Zap, Clock, AlertCircle, HelpCircle, IndianRupee } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'What time does Tatkal booking open?', answer: 'Tatkal booking opens 1 day before the journey date. For AC classes (1A, 2A, 3A, 3E, CC, EC), booking starts at 10:00 AM. For non-AC classes (SL, 2S), it opens at 11:00 AM. Premium Tatkal opens simultaneously with regular Tatkal.' },
  { question: 'Can I cancel a Tatkal ticket?', answer: 'Regular Tatkal tickets can be cancelled, but the refund is very limited. You will only get back the base fare minus the Tatkal charge and cancellation fee. In most cases, the refund is minimal. Premium Tatkal tickets are non-refundable.' },
  { question: 'What is the difference between Tatkal and Premium Tatkal?', answer: 'Regular Tatkal has a fixed surcharge and can be cancelled (with minimal refund). Premium Tatkal uses dynamic pricing — fares increase as seats fill up — and is completely non-refundable. Premium Tatkal fares can be significantly higher than regular Tatkal.' },
  { question: 'How many passengers can I book under Tatkal?', answer: 'You can book a maximum of 4 passengers per Tatkal booking (compared to 6 for regular bookings). Each IRCTC account can book Tatkal tickets within the monthly booking limit.' },
  { question: 'Is Tatkal available for all trains?', answer: 'Tatkal quota is available on most long-distance express and mail trains. It is not available on some special trains, suburban trains, and certain short-distance services. Check availability on ChaloTrain before planning.' },
];

const tatkalCharges = [
  { cls: '2S', min: '₹10', max: '₹15' },
  { cls: 'SL', min: '₹100', max: '₹200' },
  { cls: 'CC', min: '₹125', max: '₹225' },
  { cls: '3A', min: '₹300', max: '₹400' },
  { cls: '2A', min: '₹400', max: '₹500' },
  { cls: '1A', min: '₹400', max: '₹500' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks | ChaloTrain",
  "description": "Master Tatkal ticket booking on IRCTC. Learn the exact timing, charges, cancellation rules, and pro tips to successfully book Tatkal tickets every time.",
  "url": "https://chalotrain.com/blog/tatkal-ticket-booking-complete-guide",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/tatkal-ticket-booking-complete-guide"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogTatkalCompleteGuide() {
  return (
    <>
      <title>Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks | ChaloTrain</title>
      <meta name="description" content="Master Tatkal ticket booking on IRCTC. Learn the exact timing, charges, cancellation rules, and pro tips to successfully book Tatkal tickets every time." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks" />
      <meta property="og:description" content="Master Tatkal ticket booking on IRCTC. Learn the exact timing, charges, cancellation rules, and pro tips to successfully book Tatkal tickets every time." />
      <meta property="og:url" content="https://chalotrain.com/blog/tatkal-ticket-booking-complete-guide" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks" />
      <meta name="twitter:description" content="Master Tatkal ticket booking on IRCTC. Learn the exact timing, charges, cancellation rules, and pro tips to successfully book Tatkal tickets every time." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/tatkal-ticket-booking-complete-guide" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">Tatkal Ticket Booking Complete Guide</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-amber-100 text-amber-700 px-3 py-1 rounded-full font-semibold">Tatkal Guide</span>
              <span className="text-xs text-slate-400">May 2026 • 9 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              Need to travel urgently but all regular tickets are sold out? Tatkal is your answer. This guide covers everything about Tatkal booking — timing, charges, cancellation rules, and pro tips to beat the rush.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>What is Tatkal?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Tatkal (meaning "immediate" in Hindi) is a special quota introduced by Indian Railways for last-minute travel. It allows passengers to book confirmed tickets just 1 day before the journey date, at a higher fare. Tatkal seats are reserved separately from the General quota and become available only 24 hours before departure.
            </p>
            <p className="text-slate-600 leading-relaxed mb-6">
              There are two types of Tatkal: <strong>Regular Tatkal (TQ)</strong> with a fixed surcharge, and <strong>Premium Tatkal (PT)</strong> with dynamic pricing (fares increase as seats fill up). Premium Tatkal is non-refundable.
            </p>

            <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Clock size={20} className="text-amber-600" />
                <p className="font-bold text-amber-800">Tatkal Opening Times</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="bg-white rounded-xl p-3 border border-amber-200">
                  <p className="text-xs text-amber-600 font-semibold mb-1">AC Classes (1A, 2A, 3A, 3E, CC, EC)</p>
                  <p className="text-2xl font-bold text-amber-800">10:00 AM</p>
                  <p className="text-xs text-amber-600">1 day before departure</p>
                </div>
                <div className="bg-white rounded-xl p-3 border border-amber-200">
                  <p className="text-xs text-amber-600 font-semibold mb-1">Non-AC Classes (SL, 2S)</p>
                  <p className="text-2xl font-bold text-amber-800">11:00 AM</p>
                  <p className="text-xs text-amber-600">1 day before departure</p>
                </div>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Tatkal Charges by Class</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Tatkal charges are in addition to the regular fare. They are calculated as a percentage of the base fare, subject to minimum and maximum limits:
            </p>
            <div className="overflow-x-auto mb-6">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Class</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Min Tatkal Charge</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Max Tatkal Charge</th>
                  </tr>
                </thead>
                <tbody>
                  {tatkalCharges.map(({ cls, min, max }) => (
                    <tr key={cls} className="hover:bg-slate-50">
                      <td className="p-3 border border-slate-200 font-bold text-primary">{cls}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{min}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{max}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-slate-400 mb-6">* Actual Tatkal charge = 30% of base fare for AC classes, 10% for non-AC, subject to min/max limits above.</p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Book Tatkal Tickets — Step by Step</h2>
            <ol className="list-none space-y-4 mb-6">
              {[
                { title: 'Prepare in advance', desc: 'Log in to IRCTC the night before. Fill in passenger details in your profile to save time. Have your payment method ready (UPI is fastest).' },
                { title: 'Be ready at 9:55 AM (for AC) or 10:55 AM (for non-AC)', desc: 'Open IRCTC and navigate to the booking page. Have the train number, station codes, and date ready.' },
                { title: 'Search for the train', desc: 'Enter your source, destination, and date. Select "Tatkal" from the quota dropdown.' },
                { title: 'Select the train and class', desc: 'Click "Book Now" on your chosen train. Select the class (e.g., 3A for Tatkal).' },
                { title: 'Add passengers quickly', desc: 'Add passenger details. Use saved passenger profiles to save time. Do not spend more than 2–3 minutes on this step.' },
                { title: 'Pay immediately', desc: 'Use UPI or a saved card for the fastest payment. Complete payment within the session timeout (usually 10 minutes).' },
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-amber-500 text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <div>
                    <p className="font-semibold text-slate-800 text-sm">{step.title}</p>
                    <p className="text-sm text-slate-600 leading-relaxed">{step.desc}</p>
                  </div>
                </li>
              ))}
            </ol>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Pro Tips for Successful Tatkal Booking</h2>
            <div className="space-y-3 mb-6">
              {[
                { icon: Zap, tip: 'Use IRCTC iMudra Wallet', desc: 'Pre-load your IRCTC wallet with sufficient balance. Wallet payments are instant and avoid payment gateway delays.' },
                { icon: Zap, tip: 'Save Passenger Profiles', desc: 'Save all frequent travellers in your IRCTC profile. During booking, select from saved profiles instead of typing details manually.' },
                { icon: Zap, tip: 'Use a Fast Browser', desc: 'Chrome or Firefox on a desktop/laptop is faster than mobile for Tatkal booking. Avoid using the IRCTC app during peak Tatkal hours.' },
                { icon: Zap, tip: 'Check Availability First', desc: 'Use ChaloTrain\'s Seat Availability tool to verify Tatkal availability before the booking window opens. This saves time during the rush.' },
                { icon: Zap, tip: 'Have a Backup Plan', desc: 'If your preferred train\'s Tatkal fills up, have 2–3 alternate trains ready. Tatkal on a slightly longer route may still be available.' },
              ].map(({ icon: Icon, tip, desc }) => (
                <div key={tip} className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
                  <Icon size={16} className="text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-amber-800 text-sm mb-1">{tip}</p>
                    <p className="text-sm text-amber-700 leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Tatkal Cancellation Rules</h2>
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
              <div className="flex items-start gap-3">
                <AlertCircle size={20} className="text-red-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-red-800 mb-2">Important Cancellation Rules</p>
                  <ul className="space-y-1.5">
                    {[
                      'Regular Tatkal: Can be cancelled, but Tatkal charge is NOT refunded',
                      'Premium Tatkal: Completely non-refundable — no cancellation allowed',
                      'Cancellation charges apply on top of the non-refundable Tatkal charge',
                      'If train is cancelled by Railways: Full refund including Tatkal charge',
                    ].map((rule) => (
                      <li key={rule} className="text-sm text-red-700 flex items-start gap-1.5">
                        <span className="mt-0.5">•</span> {rule}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Check Tatkal Availability</p>
              <p className="text-sm text-slate-600 mb-3">Verify Tatkal seat availability before the booking window opens.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/seat-availability" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                  Check Seat Availability
                </Link>
                <Link to="/fare-inquiry" className="inline-flex items-center gap-2 bg-white border border-primary text-primary px-4 py-2 rounded-xl text-sm font-semibold hover:bg-primary/5 transition-colors">
                  <IndianRupee size={15} /> Check Tatkal Fare
                </Link>
              </div>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="Tatkal Ticket Booking Complete Guide 2026 — Tips & Tricks" url="https://chalotrain.com/blog/tatkal-ticket-booking-complete-guide" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/tatkal-ticket-booking-complete-guide" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
