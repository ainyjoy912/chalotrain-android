import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Clock, AlertTriangle, ArrowRight, Info } from 'lucide-react';
import PageHero from '@/components/PageHero';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import AppDownloadCTA from '@/components/AppDownloadCTA';
import { BookOpen } from 'lucide-react';

const faqs = [
  {
    question: 'How can I check if my train is running late?',
    answer: 'You can check live train running status on ChaloTrain\'s Live Status page. Enter your train number and date to see real-time location, current delay, and expected arrival times at upcoming stations.',
  },
  {
    question: 'What is the average delay of Indian trains?',
    answer: 'According to Indian Railways data, approximately 20-25% of trains run late on any given day. The average delay ranges from 30 minutes to 2 hours for most delayed trains, though some trains can be delayed by 5-10 hours during extreme weather or major disruptions.',
  },
  {
    question: 'Which Indian trains are most punctual?',
    answer: 'Rajdhani Express, Shatabdi Express, and Vande Bharat Express trains generally have the best punctuality records. Dedicated freight corridor trains and premium trains on well-maintained routes also tend to be more punctual.',
  },
  {
    question: 'Does fog affect train schedules in India?',
    answer: 'Yes, dense fog during winter (November to February) significantly affects train punctuality, especially in North India. Trains may be delayed by several hours or even cancelled. Indian Railways operates a Fog Safety Device (FSD) system to help drivers navigate in low visibility.',
  },
  {
    question: 'Can I get a refund if my train is very late?',
    answer: 'Yes. If a train is delayed by more than 3 hours and you choose not to travel, you can claim a full refund by filing a TDR (Ticket Deposit Receipt) on IRCTC within 72 hours of the scheduled departure. The refund is processed to your original payment method.',
  },
];

const reasons = [
  {
    title: 'Cascading Delays',
    desc: 'Indian Railways operates on a shared track network. When one train is delayed, it blocks the track for following trains, creating a domino effect. A single delay at a major junction can cascade into dozens of delayed trains.',
    severity: 'high',
  },
  {
    title: 'Dense Fog (Winter)',
    desc: 'North India experiences severe fog from November to February. Trains must slow down significantly for safety, causing delays of 2-8 hours. Fog-related delays affect hundreds of trains daily during peak winter months.',
    severity: 'high',
  },
  {
    title: 'Track Maintenance & Engineering Works',
    desc: 'Indian Railways conducts regular track maintenance, especially at night. Engineering blocks (temporary track closures) cause trains to wait or take alternate routes, adding to journey time.',
    severity: 'medium',
  },
  {
    title: 'Freight Train Priority',
    desc: 'Freight trains generate more revenue for Indian Railways and are sometimes given priority over passenger trains on shared tracks. This can cause passenger trains to wait at stations or signals.',
    severity: 'medium',
  },
  {
    title: 'Unscheduled Stoppages',
    desc: 'Emergency stops, medical emergencies, passenger chain-pulling, and signal failures cause unplanned delays. Each unscheduled stoppage adds to the total delay.',
    severity: 'medium',
  },
  {
    title: 'Extreme Weather',
    desc: 'Cyclones, floods, heavy rainfall, and landslides can damage tracks or make them unsafe. Trains are diverted or cancelled during severe weather events, causing major disruptions.',
    severity: 'high',
  },
  {
    title: 'Overcrowded Stations',
    desc: 'At busy junctions like Mumbai CST, Delhi, or Howrah, platform congestion and the sheer volume of trains can cause delays in departure and arrival.',
    severity: 'low',
  },
  {
    title: 'Technical Failures',
    desc: 'Locomotive failures, brake issues, and signal malfunctions require trains to stop for repairs. While rare, these can cause significant delays when they occur.',
    severity: 'medium',
  },
];

const severityColors: Record<string, string> = {
  high: 'bg-red-100 text-red-700 border-red-200',
  medium: 'bg-orange-100 text-orange-700 border-orange-200',
  low: 'bg-yellow-100 text-yellow-700 border-yellow-200',
};

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Why Do Indian Trains Run Late? Top Reasons Explained | ChaloTrain",
  "description": "Ever wondered why your train is always delayed? We explain the top reasons Indian trains run late — from fog and track maintenance to cascading delays and freight priority.",
  "url": "https://chalotrain.com/blog/why-trains-run-late-in-india",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/why-trains-run-late-in-india"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogTrainDelayPage() {
  return (
    <>
      <title>Why Do Indian Trains Run Late? Top Reasons Explained | ChaloTrain</title>
      <meta
        name="description"
        content="Ever wondered why your train is always delayed? We explain the top reasons Indian trains run late — from fog and track maintenance to cascading delays and freight priority."
      />
      <meta name="keywords" content="why Indian trains run late, train delay India, Indian Railways punctuality, train delay reasons, live train status" />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Why Do Indian Trains Run Late? Top Reasons Explained" />
      <meta property="og:description" content="Ever wondered why your train is always delayed? We explain the top reasons Indian trains run late — from fog and track maintenance to cascading delays and freight priority." />
      <meta property="og:url" content="https://chalotrain.com/blog/why-trains-run-late-in-india" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Why Do Indian Trains Run Late? Top Reasons Explained" />
      <meta name="twitter:description" content="Ever wondered why your train is always delayed? We explain the top reasons Indian trains run late — from fog and track maintenance to cascading delays and freight priority." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/why-trains-run-late-in-india" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        icon={BookOpen}
        title="Why Do Indian Trains Run Late?"
        subtitle="Top Reasons Explained — And How to Stay Updated"
        badge="Train Info · 6 min read"
      />
      <h1 className="sr-only">Why Do Indian Trains Run Late? Top Reasons Explained</h1>

      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-2xl border border-slate-200 p-6 md:p-10 mb-8"
          >
            <nav className="flex items-center gap-2 text-xs text-slate-400 mb-6">
              <Link to="/" className="hover:text-primary">Home</Link>
              <span>/</span>
              <Link to="/blog" className="hover:text-primary">Blog</Link>
              <span>/</span>
              <span className="text-slate-600">Why Trains Run Late</span>
            </nav>

            <div className="flex items-center gap-3 mb-6">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700">Train Info</span>
              <span className="flex items-center gap-1 text-xs text-slate-400"><Clock size={11} /> 6 min read</span>
              <span className="text-xs text-slate-400">April 2, 2026</span>
            </div>

            <p className="text-slate-600 leading-relaxed mb-6">
              If you've ever waited on a platform watching the "Expected Arrival" time keep pushing back, you're not alone. Indian Railways operates one of the world's largest rail networks — over 13,000 trains daily across 67,000 km of track. With that scale comes complexity, and delays are an inevitable part of the system. Here's why.
            </p>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8 text-sm text-blue-800 flex gap-3">
              <Info size={16} className="shrink-0 mt-0.5" />
              <div>
                <strong>Did you know?</strong> Indian Railways carries over 23 million passengers every day — more than the entire population of Australia. Managing punctuality at this scale is an enormous challenge.
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Top 8 Reasons Indian Trains Run Late
            </h2>

            <div className="space-y-4 mb-8">
              {reasons.map((reason, i) => (
                <div key={reason.title} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h3 className="font-bold text-slate-900 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
                      {i + 1}. {reason.title}
                    </h3>
                    <span className={`px-2 py-0.5 rounded text-xs font-semibold border shrink-0 ${severityColors[reason.severity]}`}>
                      {reason.severity === 'high' ? 'Major' : reason.severity === 'medium' ? 'Moderate' : 'Minor'}
                    </span>
                  </div>
                  <p className="text-sm text-slate-500 leading-relaxed">{reason.desc}</p>
                </div>
              ))}
            </div>

            {/* What you can do */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              What You Can Do About Train Delays
            </h2>
            <ul className="space-y-3 mb-8">
              {[
                { tip: 'Check live train status before leaving home', link: '/live-status', linkText: 'Live Status' },
                { tip: 'Add buffer time for connecting trains or flights', link: null, linkText: null },
                { tip: 'Sign up for SMS alerts via IRCTC for your PNR', link: null, linkText: null },
                { tip: 'Check the train\'s historical punctuality before booking', link: '/train-schedule', linkText: 'Train Schedule' },
                { tip: 'If delayed by 3+ hours, you can file a TDR for a refund', link: null, linkText: null },
              ].map((item) => (
                <li key={item.tip} className="flex items-start gap-2 text-sm text-slate-600">
                  <AlertTriangle size={15} className="text-amber-400 mt-0.5 shrink-0" />
                  <span>
                    {item.tip}
                    {item.link && (
                      <> — <Link to={item.link} className="text-primary hover:underline font-medium">{item.linkText}</Link></>
                    )}
                  </span>
                </li>
              ))}
            </ul>

            {/* Live status CTA */}
            <div className="bg-gradient-to-r from-purple-600 to-purple-700 rounded-2xl p-6 text-white text-center mb-8">
              <h3 className="text-lg font-bold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Track Your Train Live</h3>
              <p className="text-purple-100 text-sm mb-4">Get real-time location, current delay, and expected arrival times for any Indian Railways train.</p>
              <Link to="/live-status" className="inline-flex items-center gap-2 px-6 py-2.5 bg-white text-purple-700 text-sm font-bold rounded-xl hover:bg-purple-50 transition-colors">
                Check Live Status <ArrowRight size={14} />
              </Link>
            </div>

            <AppDownloadCTA />

            <SocialShareBar
              url="https://chalotrain.com/blog/why-trains-run-late-in-india"
              title="Why Do Indian Trains Run Late? Top Reasons Explained"
            />
          </motion.article>

          <FAQSection items={faqs} />
          <RelatedTools currentHref="/blog/why-trains-run-late-in-india" />
        </div>
      </section>
    </>
  );
}
