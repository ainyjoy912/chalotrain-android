import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { CheckCircle, Clock, Smartphone, Globe, MessageSquare, ArrowRight } from 'lucide-react';
import PageHero from '@/components/PageHero';
import FAQSection from '@/components/FAQSection';
import FAQSchemaLD from '@/components/FAQSchemaLD';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import AppDownloadCTA from '@/components/AppDownloadCTA';
import { BookOpen } from 'lucide-react';

const faqs = [
  {
    question: 'What is a PNR number?',
    answer: 'PNR stands for Passenger Name Record. It is a unique 10-digit number assigned to every Indian Railways ticket booking. It contains all your journey details including passenger names, train number, travel date, seat/berth allocation, and booking status.',
  },
  {
    question: 'How long does it take for PNR status to update?',
    answer: 'PNR status typically updates within a few minutes of booking. For waitlisted tickets, the status updates as chart preparation happens — usually 4 hours before departure. After chart preparation, the final status (CNF/RAC/WL) is locked.',
  },
  {
    question: 'What does CNF, RAC, and WL mean in PNR status?',
    answer: 'CNF means Confirmed — your seat/berth is guaranteed. RAC (Reservation Against Cancellation) means you share a berth and may get a full berth if someone cancels. WL (Waitlist) means you are on the waiting list and may not be allowed to board if the status does not improve.',
  },
  {
    question: 'Can I check PNR status without internet?',
    answer: 'Yes! You can check PNR status via SMS. Send "PNR <10-digit PNR number>" to 139 from any mobile number. You will receive the current status as an SMS reply. This works even on basic phones without internet.',
  },
  {
    question: 'What happens if my PNR status is still WL after chart preparation?',
    answer: 'If your PNR status remains WL after chart preparation, your ticket is automatically cancelled and a refund is processed to your original payment method. You will not be allowed to board the train with a WL status after chart preparation.',
  },
];

const methods = [
  {
    icon: Globe,
    title: 'ChaloTrain Website',
    desc: 'Enter your 10-digit PNR on our PNR Status page for instant results with passenger details.',
    color: 'bg-blue-50 text-blue-600',
    link: '/pnr-status',
    linkText: 'Check Now',
  },
  {
    icon: Globe,
    title: 'IRCTC Website',
    desc: 'Visit irctc.co.in → "PNR Enquiry" and enter your PNR number for official status.',
    color: 'bg-orange-50 text-orange-600',
    link: null,
    linkText: null,
  },
  {
    icon: Smartphone,
    title: 'IRCTC Rail Connect App',
    desc: 'Download the official IRCTC app and use the PNR Status section for real-time updates.',
    color: 'bg-green-50 text-green-600',
    link: null,
    linkText: null,
  },
  {
    icon: MessageSquare,
    title: 'SMS to 139',
    desc: 'Send "PNR <your 10-digit PNR>" to 139 from any mobile. Works without internet.',
    color: 'bg-purple-50 text-purple-600',
    link: null,
    linkText: null,
  },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Check PNR Status Online — All Methods (SMS, App, Web) | ChaloTrain",
  "description": "Learn how to check your Indian Railways PNR status online in seconds. Step-by-step guide covering all methods: ChaloTrain, IRCTC, SMS to 139, and mobile apps.",
  "url": "https://chalotrain.com/blog/how-to-check-pnr-status-online",
  "datePublished": "2026-04-01",
  "dateModified": "2026-04-01",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-check-pnr-status-online"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogPNRStatusPage() {
  return (
    <>
      <title>How to Check PNR Status Online — All Methods (SMS, App, Web) | ChaloTrain</title>
      <meta
        name="description"
        content="Learn how to check your Indian Railways PNR status online in seconds. Step-by-step guide covering all methods: ChaloTrain, IRCTC, SMS to 139, and mobile apps."
      />
      <meta name="keywords" content="PNR status check, how to check PNR status, IRCTC PNR, train ticket status, PNR number" />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Check PNR Status Online — All Methods (SMS, App, Web)" />
      <meta property="og:description" content="Learn how to check your Indian Railways PNR status online in seconds. Step-by-step guide covering all methods: ChaloTrain, IRCTC, SMS to 139, and mobile apps." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-check-pnr-status-online" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Check PNR Status Online — All Methods (SMS, App, Web)" />
      <meta name="twitter:description" content="Learn how to check your Indian Railways PNR status online in seconds. Step-by-step guide covering all methods: ChaloTrain, IRCTC, SMS to 139, and mobile apps." />
      <meta name="robots" content="noindex, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-check-pnr-status-online-guide" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <PageHero
        icon={BookOpen}
        title="How to Check PNR Status Online"
        subtitle="Complete Guide 2026 — All Methods Explained"
        badge="PNR & Tickets · 5 min read"
      />
      <h1 className="sr-only">How to Check PNR Status Online — All Methods (SMS, App, Web)</h1>

      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-2xl border border-slate-200 p-6 md:p-10 mb-8"
          >
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-xs text-slate-400 mb-6">
              <Link to="/" className="hover:text-primary">Home</Link>
              <span>/</span>
              <Link to="/blog" className="hover:text-primary">Blog</Link>
              <span>/</span>
              <span className="text-slate-600">PNR Status Guide</span>
            </nav>

            <div className="flex items-center gap-3 mb-6">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">PNR & Tickets</span>
              <span className="flex items-center gap-1 text-xs text-slate-400"><Clock size={11} /> 5 min read</span>
              <span className="text-xs text-slate-400">April 10, 2026</span>
            </div>

            {/* Intro */}
            <p className="text-slate-600 leading-relaxed mb-6">
              Checking your PNR (Passenger Name Record) status is one of the most common tasks for Indian railway travellers. Whether you want to know if your waitlisted ticket got confirmed, check your seat/berth number, or verify passenger details — this guide covers every method available in 2026.
            </p>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8 text-sm text-blue-800">
              <strong>Quick Answer:</strong> The fastest way to check PNR status is to visit <Link to="/pnr-status" className="underline font-semibold">ChaloTrain's PNR Status page</Link>, enter your 10-digit PNR number, and get instant results — no login required.
            </div>

            {/* What is PNR */}
            <h2 className="text-xl font-bold text-slate-900 mb-3 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              What is a PNR Number?
            </h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              A PNR number is a unique 10-digit identifier assigned to every Indian Railways ticket booking. It acts as your booking reference and contains all journey information:
            </p>
            <ul className="space-y-2 mb-6">
              {['Passenger names and ages', 'Train number and name', 'Travel date and class', 'Source and destination stations', 'Seat/berth allocation (after chart preparation)', 'Current booking status (CNF/RAC/WL)'].map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm text-slate-600">
                  <CheckCircle size={15} className="text-green-500 mt-0.5 shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
            <p className="text-slate-600 leading-relaxed mb-6">
              You can find your PNR number on your ticket (printed or e-ticket), in the IRCTC booking confirmation email, or in the IRCTC app under "My Bookings."
            </p>

            {/* Methods */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              4 Ways to Check PNR Status
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {methods.map((m) => (
                <div key={m.title} className="border border-slate-200 rounded-xl p-4">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${m.color}`}>
                    <m.icon size={18} />
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{m.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed mb-3">{m.desc}</p>
                  {m.link && (
                    <Link to={m.link} className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline">
                      {m.linkText} <ArrowRight size={11} />
                    </Link>
                  )}
                </div>
              ))}
            </div>

            {/* Step by step */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Step-by-Step: Check PNR on ChaloTrain
            </h2>
            <ol className="space-y-4 mb-8">
              {[
                { step: '1', title: 'Visit the PNR Status page', desc: 'Go to chalotrain.com/pnr-status or click "Check PNR" in the header.' },
                { step: '2', title: 'Enter your 10-digit PNR number', desc: 'Type your PNR number in the input field. It must be exactly 10 digits. You can find it on your ticket or IRCTC confirmation email.' },
                { step: '3', title: 'Click "Check PNR Status"', desc: 'Hit the button and wait a moment while we fetch the latest status from Indian Railways.' },
                { step: '4', title: 'View your results', desc: 'See your train details, journey info, and individual passenger status cards showing CNF/RAC/WL with seat/berth details.' },
              ].map((item) => (
                <li key={item.step} className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-900 text-sm mb-1">{item.title}</h4>
                    <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
                  </div>
                </li>
              ))}
            </ol>

            {/* Understanding status */}
            <h2 className="text-xl font-bold text-slate-900 mb-4 mt-8" style={{ fontFamily: 'var(--font-heading)' }}>
              Understanding PNR Status Codes
            </h2>
            <div className="overflow-x-auto mb-8">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Status</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Full Form</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Meaning</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { status: 'CNF', full: 'Confirmed', meaning: 'Seat/berth is guaranteed. You can board the train.', color: 'text-green-700 bg-green-50' },
                    { status: 'RAC', full: 'Reservation Against Cancellation', meaning: 'You share a berth. May get full berth if someone cancels.', color: 'text-yellow-700 bg-yellow-50' },
                    { status: 'WL', full: 'Waitlist', meaning: 'On the waiting list. Status may improve before departure.', color: 'text-red-700 bg-red-50' },
                    { status: 'PQWL', full: 'Pooled Quota Waitlist', meaning: 'Waitlist from pooled quota. Harder to confirm than general WL.', color: 'text-orange-700 bg-orange-50' },
                    { status: 'GNWL', full: 'General Waitlist', meaning: 'Standard waitlist. Confirms based on cancellations.', color: 'text-orange-700 bg-orange-50' },
                  ].map((row) => (
                    <tr key={row.status} className="border-b border-slate-100">
                      <td className="p-3 border border-slate-200">
                        <span className={`px-2 py-0.5 rounded text-xs font-bold ${row.color}`}>{row.status}</span>
                      </td>
                      <td className="p-3 border border-slate-200 text-slate-600">{row.full}</td>
                      <td className="p-3 border border-slate-200 text-slate-500">{row.meaning}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* CTA */}
            <div className="bg-gradient-to-r from-primary to-blue-700 rounded-2xl p-6 text-white text-center mb-8">
              <h3 className="text-lg font-bold mb-2" style={{ fontFamily: 'var(--font-heading)' }}>Check Your PNR Status Now</h3>
              <p className="text-blue-100 text-sm mb-4">Free, instant, no login required. Get your PNR status in seconds.</p>
              <Link to="/pnr-status" className="inline-flex items-center gap-2 px-6 py-2.5 bg-white text-primary text-sm font-bold rounded-xl hover:bg-blue-50 transition-colors">
                Check PNR Status <ArrowRight size={14} />
              </Link>
            </div>

            <AppDownloadCTA />

            <SocialShareBar
              url="https://chalotrain.com/blog/how-to-check-pnr-status-online"
              title="How to Check PNR Status Online — Complete Guide 2026"
            />
          </motion.article>

          <FAQSection
            items={faqs}
          />

          <RelatedTools currentHref="/blog/how-to-check-pnr-status-online" />
        </div>
      </section>
    </>
  );
}
