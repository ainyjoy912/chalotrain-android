import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Train, CheckCircle, AlertCircle, Clock, HelpCircle } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'What is a PNR number?', answer: 'PNR stands for Passenger Name Record. It is a unique 10-digit number assigned to every train ticket booked through IRCTC or at a railway counter. It contains all your journey details including passenger info, train, seat, and booking status.' },
  { question: 'How long does it take for PNR status to update?', answer: 'PNR status updates in real-time as chart preparation happens, usually 4–6 hours before departure. Waitlisted tickets get confirmed or cancelled during this window.' },
  { question: 'What does CNF, RAC, and WL mean in PNR status?', answer: 'CNF means Confirmed — you have a confirmed berth. RAC (Reservation Against Cancellation) means you share a berth and may get a full berth if someone cancels. WL (Waitlist) means you are on the waiting list and need to wait for cancellations.' },
  { question: 'Can I travel on a WL (Waitlisted) ticket?', answer: 'No. If your PNR status remains WL at the time of chart preparation, your ticket is automatically cancelled and you receive a refund. You cannot board the train on a waitlisted e-ticket.' },
  { question: 'Where can I find my PNR number?', answer: 'Your PNR number is printed on the top-left corner of your physical ticket. For e-tickets, it appears in your booking confirmation email and in your IRCTC account under "Booked Ticket History".' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Check PNR Status Online — Complete Guide 2026 | ChaloTrain",
  "description": "Learn how to check your PNR status online instantly. Understand CNF, RAC, WL statuses, what they mean, and what to do if your ticket is waitlisted.",
  "url": "https://chalotrain.com/blog/how-to-check-pnr-status-online-guide",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/how-to-check-pnr-status-online-guide"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogPNRGuide() {
  return (
    <>
      <title>How to Check PNR Status Online — Complete Guide 2026 | ChaloTrain</title>
      <meta name="description" content="Learn how to check your PNR status online instantly. Understand CNF, RAC, WL statuses, what they mean, and what to do if your ticket is waitlisted." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="How to Check PNR Status Online — Complete Guide 2026" />
      <meta property="og:description" content="Learn how to check your PNR status online instantly. Understand CNF, RAC, WL statuses, what they mean, and what to do if your ticket is waitlisted." />
      <meta property="og:url" content="https://chalotrain.com/blog/how-to-check-pnr-status-online-guide" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="How to Check PNR Status Online — Complete Guide 2026" />
      <meta name="twitter:description" content="Learn how to check your PNR status online instantly. Understand CNF, RAC, WL statuses, what they mean, and what to do if your ticket is waitlisted." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/how-to-check-pnr-status-online-guide" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          {/* Breadcrumb */}
          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">How to Check PNR Status Online</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold">PNR Status</span>
              <span className="text-xs text-slate-400">May 2026 • 8 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              How to Check PNR Status Online — Complete Guide 2026
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              Your PNR number is the key to your entire train journey. This guide explains everything — from finding your PNR to understanding every possible status code and what action to take.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>What is a PNR Number?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              PNR stands for <strong>Passenger Name Record</strong>. It is a unique 10-digit number that Indian Railways assigns to every train ticket at the time of booking. Whether you book online through IRCTC, via a travel agent, or at a railway counter, every ticket gets a PNR number.
            </p>
            <p className="text-slate-600 leading-relaxed mb-4">
              This number acts as your booking ID and contains all information about your journey: the train number, date of travel, boarding and destination stations, class of travel, coach and berth number (once confirmed), and the names and ages of all passengers on the ticket.
            </p>
            <p className="text-slate-600 leading-relaxed mb-6">
              For e-tickets booked on IRCTC, the PNR appears in your booking confirmation email and SMS. For counter tickets, it is printed in the top-left corner of the physical ticket.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>How to Check PNR Status on ChaloTrain</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              ChaloTrain makes PNR checking instant and easy. Here is the step-by-step process:
            </p>
            <ol className="list-none space-y-3 mb-6">
              {[
                'Visit the PNR Status page on ChaloTrain or use the quick search on the homepage.',
                'Enter your 10-digit PNR number in the search box. The system only accepts numeric digits.',
                'Click the "Check PNR Status" button.',
                'Within seconds, you will see your complete booking details including current status for each passenger.',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center mt-0.5">{i + 1}</span>
                  <span className="text-slate-600 leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <Train size={20} className="text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold text-blue-800 mb-1">Quick Tip</p>
                <p className="text-sm text-blue-700">You can check PNR status directly at <Link to="/pnr-status" className="underline font-semibold hover:text-primary">chalotrain.com/pnr-status</Link>. No login or registration required.</p>
              </div>
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Understanding PNR Status Codes</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              Indian Railways uses specific codes to indicate your booking status. Here is what each one means:
            </p>

            <div className="space-y-4 mb-6">
              {[
                { code: 'CNF', color: 'bg-green-50 border-green-200', badge: 'bg-green-100 text-green-700', icon: CheckCircle, iconColor: 'text-green-600', title: 'Confirmed (CNF)', desc: 'Your seat or berth is confirmed. Your coach and berth number will be assigned when the chart is prepared, usually 4–6 hours before departure. You can board the train without any worry.' },
                { code: 'RAC', color: 'bg-yellow-50 border-yellow-200', badge: 'bg-yellow-100 text-yellow-700', icon: Clock, iconColor: 'text-yellow-600', title: 'Reservation Against Cancellation (RAC)', desc: 'You have a valid ticket and can board the train, but you will share a side-lower berth with another RAC passenger. If any confirmed passenger cancels, you will be upgraded to a full berth. RAC passengers must board the train.' },
                { code: 'WL', color: 'bg-red-50 border-red-200', badge: 'bg-red-100 text-red-700', icon: AlertCircle, iconColor: 'text-red-500', title: 'Waitlist (WL)', desc: 'You are on the waiting list. Your ticket is not confirmed yet. If passengers ahead of you cancel, your status moves up. For e-tickets, if the status remains WL at chart preparation, the ticket is automatically cancelled and a full refund is issued.' },
                { code: 'PQWL', color: 'bg-orange-50 border-orange-200', badge: 'bg-orange-100 text-orange-700', icon: AlertCircle, iconColor: 'text-orange-500', title: 'Pooled Quota Waitlist (PQWL)', desc: 'This is a waitlist under the pooled quota, which covers intermediate stations. PQWL tickets have a lower chance of confirmation compared to GNWL (General Waitlist) tickets.' },
                { code: 'RLWL', color: 'bg-purple-50 border-purple-200', badge: 'bg-purple-100 text-purple-700', icon: AlertCircle, iconColor: 'text-purple-500', title: 'Remote Location Waitlist (RLWL)', desc: 'This waitlist applies to passengers boarding from remote or intermediate stations. Confirmation depends on cancellations from the same boarding point.' },
              ].map(({ code, color, badge, icon: Icon, iconColor, title, desc }) => (
                <div key={code} className={`rounded-xl border p-4 ${color}`}>
                  <div className="flex items-start gap-3">
                    <Icon size={20} className={`${iconColor} mt-0.5 flex-shrink-0`} />
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${badge}`}>{code}</span>
                        <span className="font-semibold text-slate-800 text-sm">{title}</span>
                      </div>
                      <p className="text-sm text-slate-600 leading-relaxed">{desc}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>When Does PNR Status Change?</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              PNR status is dynamic and changes at several key points:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li><strong>At booking:</strong> Status is assigned based on availability at that moment.</li>
              <li><strong>As cancellations happen:</strong> Waitlisted passengers move up the queue when others cancel.</li>
              <li><strong>Chart preparation (4–6 hours before departure):</strong> Final statuses are locked. WL e-tickets that are not confirmed get auto-cancelled with a full refund.</li>
              <li><strong>After chart preparation:</strong> No further changes are possible for that journey.</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>What to Do If Your Ticket is Waitlisted</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              If your PNR status is WL and you are worried about confirmation, here are your options:
            </p>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li><strong>Wait and monitor:</strong> Check PNR status regularly. Many WL tickets get confirmed, especially for popular routes.</li>
              <li><strong>Book a Tatkal ticket:</strong> If your journey is urgent, book a Tatkal ticket on the same or alternate train. Tatkal opens 1 day before departure.</li>
              <li><strong>Try alternate trains:</strong> Use ChaloTrain's <Link to="/train-search" className="text-primary underline font-medium">Train Search</Link> to find other trains on the same route with available seats.</li>
              <li><strong>Cancel and rebook:</strong> If your WL number is high (e.g., WL 50+), consider cancelling and booking on a different date or train.</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>PNR Status via SMS</h2>
            <p className="text-slate-600 leading-relaxed mb-4">
              You can also check PNR status via SMS without internet access. Send an SMS to <strong>139</strong> in the format:
            </p>
            <div className="bg-slate-100 rounded-xl p-4 font-mono text-sm text-slate-700 mb-6">
              PNR &lt;10-digit PNR number&gt;<br />
              Example: PNR 1234567890
            </div>
            <p className="text-slate-600 leading-relaxed mb-6">
              You will receive an SMS reply with your current PNR status. This is useful when you are travelling in areas with limited internet connectivity.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Check Your PNR Status Now</p>
              <p className="text-sm text-slate-600 mb-3">Use ChaloTrain's free PNR Status checker for instant results — no login required.</p>
              <Link to="/pnr-status" className="inline-flex items-center gap-2 bg-primary text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                <Train size={16} /> Check PNR Status
              </Link>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="How to Check PNR Status Online — Complete Guide 2026" url="https://chalotrain.com/blog/how-to-check-pnr-status-online-guide" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/how-to-check-pnr-status-online-guide" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
