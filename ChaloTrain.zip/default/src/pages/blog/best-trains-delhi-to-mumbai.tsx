import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ChevronRight, Train, Clock, IndianRupee, HelpCircle, Star } from 'lucide-react';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSchemaLD from '@/components/FAQSchemaLD';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

const faqs = [
  { question: 'What is the fastest train from Delhi to Mumbai?', answer: 'The Rajdhani Express (12951/12952) is the fastest train between Delhi and Mumbai, covering the distance in approximately 15 hours 55 minutes. It runs daily and offers 1A, 2A, and 3A classes with meals included.' },
  { question: 'How far is Delhi from Mumbai by train?', answer: 'The railway distance between New Delhi (NDLS) and Mumbai Central (BCT) is approximately 1,384 km. Journey time ranges from 16 to 23 hours depending on the train.' },
  { question: 'Which is the best train from Delhi to Mumbai for budget travelers?', answer: 'The August Kranti Rajdhani (12953) and the Paschim Express (12925) offer good value. For the most budget-friendly option, the Sleeper Class (SL) on any Mail/Express train is the cheapest way to travel.' },
  { question: 'Do Delhi to Mumbai trains have pantry cars?', answer: 'Yes. All major trains on the Delhi–Mumbai route including Rajdhani, Duronto, and August Kranti have pantry cars. Rajdhani fares include meals. On other trains, you can order from the pantry or use IRCTC e-Catering.' },
  { question: 'Which station in Delhi and Mumbai should I use?', answer: 'Most Delhi–Mumbai trains depart from New Delhi (NDLS) or Hazrat Nizamuddin (NZM). In Mumbai, trains arrive at Mumbai Central (BCT) or Bandra Terminus (BDTS). Check your specific train\'s route on ChaloTrain.' },
];

const trains = [
  { number: '12951', name: 'Mumbai Rajdhani Express', from: 'NDLS', to: 'BCT', dep: '16:55', arr: '08:50+1', duration: '15h 55m', days: 'Daily', classes: '1A, 2A, 3A', rating: 5, highlight: 'Fastest & Premium' },
  { number: '12953', name: 'August Kranti Rajdhani', from: 'NDLS', to: 'BCT', dep: '17:40', arr: '10:55+1', duration: '17h 15m', days: 'Daily', classes: '1A, 2A, 3A', rating: 5, highlight: 'Popular Choice' },
  { number: '12909', name: 'Garib Rath Express', from: 'NDLS', to: 'BCT', dep: '15:35', arr: '10:05+1', duration: '18h 30m', days: 'Tue, Thu, Sat', classes: '3A', rating: 4, highlight: 'Budget AC' },
  { number: '12925', name: 'Paschim Express', from: 'NDLS', to: 'BCT', dep: '11:05', arr: '09:45+1', duration: '22h 40m', days: 'Daily', classes: '1A, 2A, 3A, SL', rating: 4, highlight: 'All Classes' },
  { number: '12137', name: 'Punjab Mail', from: 'NDLS', to: 'BCT', dep: '19:30', arr: '19:05+1', duration: '23h 35m', days: 'Daily', classes: '1A, 2A, 3A, SL', rating: 4, highlight: 'Historic Train' },
  { number: '22209', name: 'Mumbai Duronto Express', from: 'NDLS', to: 'BCT', dep: '23:00', arr: '16:45+1', duration: '17h 45m', days: 'Mon, Wed, Fri', classes: '1A, 2A, 3A', rating: 4, highlight: 'Non-stop' },
];

const articleJsonLd = {
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Best Trains from Delhi to Mumbai 2026 — Complete Guide | ChaloTrain",
  "description": "Discover the best trains from Delhi to Mumbai in 2026. Compare Rajdhani, Duronto, Garib Rath and more — timings, fares, classes, and booking tips.",
  "url": "https://chalotrain.com/blog/best-trains-delhi-to-mumbai",
  "datePublished": "2026-05-21",
  "dateModified": "2026-05-21",
  "author": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ChaloTrain",
    "url": "https://chalotrain.com",
    "logo": {
      "@type": "ImageObject",
      "url": "https://chalotrain.com/favicon.ico"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://chalotrain.com/blog/best-trains-delhi-to-mumbai"
  },
  "isPartOf": {
    "@type": "Blog",
    "@id": "https://chalotrain.com/blog"
  }
};

export default function BlogBestTrainsDelhiMumbai() {
  return (
    <>
      <title>Best Trains from Delhi to Mumbai 2026 — Complete Guide | ChaloTrain</title>
      <meta name="description" content="Discover the best trains from Delhi to Mumbai in 2026. Compare Rajdhani, Duronto, Garib Rath and more — timings, fares, classes, and booking tips." />
      <meta property="og:type" content="article" />
      <meta property="og:site_name" content="ChaloTrain" />
      <meta property="og:title" content="Best Trains from Delhi to Mumbai 2026 — Complete Guide" />
      <meta property="og:description" content="Discover the best trains from Delhi to Mumbai in 2026. Compare Rajdhani, Duronto, Garib Rath and more — timings, fares, classes, and booking tips." />
      <meta property="og:url" content="https://chalotrain.com/blog/best-trains-delhi-to-mumbai" />
      <meta property="og:image" content="https://chalotrain.com/og-image.png" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@chalotrain" />
      <meta name="twitter:title" content="Best Trains from Delhi to Mumbai 2026 — Complete Guide" />
      <meta name="twitter:description" content="Discover the best trains from Delhi to Mumbai in 2026. Compare Rajdhani, Duronto, Garib Rath and more — timings, fares, classes, and booking tips." />
      <meta name="robots" content="index, follow" />
      <link rel="canonical" href="https://chalotrain.com/blog/best-trains-delhi-to-mumbai" />
      <FAQSchemaLD items={faqs} />
      <script type="application/ld+json">{JSON.stringify(articleJsonLd)}</script>

      <section className="py-10 bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 max-w-3xl">

          <motion.nav initial="hidden" animate="visible" variants={fadeUp} className="flex items-center gap-1.5 text-xs text-slate-500 mb-6">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/blog" className="hover:text-primary transition-colors">Blog</Link>
            <ChevronRight size={12} />
            <span className="text-slate-700">Best Trains Delhi to Mumbai</span>
          </motion.nav>

          <motion.article initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-slate-200 p-8 mb-6">

            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold">Train Routes</span>
              <span className="text-xs text-slate-400">May 2026 • 8 min read</span>
            </div>

            <h1 className="text-3xl font-bold text-slate-900 mb-4 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
              Best Trains from Delhi to Mumbai 2026 — Complete Guide
            </h1>

            <p className="text-slate-600 text-lg leading-relaxed mb-8 border-l-4 border-primary pl-4">
              The Delhi–Mumbai rail corridor is one of India's busiest routes. With over 20 trains running daily, choosing the right one can be confusing. This guide compares the best options for every budget and preference.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>Top Trains from Delhi to Mumbai at a Glance</h2>

            <div className="space-y-4 mb-8">
              {trains.map((train) => (
                <div key={train.number} className="border border-slate-200 rounded-xl p-4 hover:border-primary/40 transition-colors">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-primary bg-blue-50 px-2 py-0.5 rounded">{train.number}</span>
                        <span className="font-bold text-slate-800 text-sm">{train.name}</span>
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        {Array.from({ length: train.rating }).map((_, i) => (
                          <Star key={i} size={12} className="text-amber-400 fill-amber-400" />
                        ))}
                      </div>
                    </div>
                    <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-semibold flex-shrink-0">{train.highlight}</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <p className="text-xs text-slate-400 mb-0.5">Departure</p>
                      <p className="text-sm font-semibold text-slate-700">{train.dep} ({train.from})</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 mb-0.5">Arrival</p>
                      <p className="text-sm font-semibold text-slate-700">{train.arr} ({train.to})</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 mb-0.5">Duration</p>
                      <p className="text-sm font-semibold text-slate-700 flex items-center gap-1"><Clock size={12} />{train.duration}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400 mb-0.5">Classes</p>
                      <p className="text-sm font-semibold text-slate-700">{train.classes}</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Runs: {train.days}</p>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Detailed Train Reviews</h2>

            <h3 className="text-base font-bold text-slate-800 mb-2">1. Mumbai Rajdhani Express (12951) — Best Overall</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              The Mumbai Rajdhani is the crown jewel of the Delhi–Mumbai route. It is the fastest train on this corridor, covering 1,384 km in under 16 hours. Running daily from New Delhi station, it departs at 4:55 PM and arrives at Mumbai Central by 8:50 AM the next morning. Meals are included in the fare for all classes (1A, 2A, 3A). The train is well-maintained with clean coaches and attentive pantry staff. Book at least 30–45 days in advance as it fills up very quickly.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">2. August Kranti Rajdhani (12953) — Popular Alternative</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              Named after the Quit India Movement of 1942, the August Kranti Rajdhani is another premium daily train. It departs from Hazrat Nizamuddin (NZM) at 5:40 PM and arrives at Mumbai Central at 10:55 AM. Like the Mumbai Rajdhani, meals are included. It is slightly slower but equally comfortable. A great alternative when the Mumbai Rajdhani is fully booked.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">3. Garib Rath Express (12909) — Best Budget AC</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              The Garib Rath (meaning "Poor Man's Chariot") was introduced to make AC travel affordable. It offers only 3A class at significantly lower fares than Rajdhani. The coaches are slightly more densely packed (8 berths per bay instead of 6), but it is a great value option for budget-conscious AC travelers. Runs on Tuesday, Thursday, and Saturday.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">4. Paschim Express (12925) — Best for All Classes</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              The Paschim Express is a daily train that offers all classes including Sleeper (SL), making it the best option for budget travelers who do not need AC. It takes about 22 hours but covers the route reliably. The Sleeper class fare is very affordable, making it popular with students and budget travelers.
            </p>

            <h3 className="text-base font-bold text-slate-800 mb-2">5. Mumbai Duronto Express (22209) — Non-Stop Premium</h3>
            <p className="text-slate-600 leading-relaxed mb-4">
              The Duronto Express is a non-stop train between Delhi and Mumbai, making no intermediate stops. It runs on Monday, Wednesday, and Friday. The non-stop nature means faster journey times and fewer delays. It offers 1A, 2A, and 3A classes with meals included.
            </p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Fare Comparison (Approximate)</h2>
            <div className="overflow-x-auto mb-6">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Class</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Rajdhani</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Garib Rath</th>
                    <th className="text-left p-3 border border-slate-200 font-semibold text-slate-700">Paschim Exp</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { cls: '1A', raj: '₹4,500–5,500', gr: '—', pw: '₹3,800–4,500' },
                    { cls: '2A', raj: '₹2,500–3,200', gr: '—', pw: '₹2,000–2,600' },
                    { cls: '3A', raj: '₹1,700–2,200', gr: '₹900–1,200', pw: '₹1,400–1,800' },
                    { cls: 'SL', raj: '—', gr: '—', pw: '₹450–600' },
                  ].map(({ cls, raj, gr, pw }) => (
                    <tr key={cls} className="hover:bg-slate-50">
                      <td className="p-3 border border-slate-200 font-bold text-primary">{cls}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{raj}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{gr}</td>
                      <td className="p-3 border border-slate-200 text-slate-600">{pw}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-slate-400 mb-6">* Fares are approximate and vary by date, quota, and availability. Check exact fares on ChaloTrain's <Link to="/fare-inquiry" className="text-primary underline">Fare Inquiry</Link> tool.</p>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Booking Tips for Delhi–Mumbai Trains</h2>
            <ul className="list-disc list-inside space-y-2 text-slate-600 mb-6 pl-2">
              <li>Book Rajdhani and Duronto tickets exactly 60 days in advance — they sell out within hours</li>
              <li>For travel during festivals (Diwali, Holi, Christmas), book 60 days in advance without fail</li>
              <li>If General quota is full, try Tatkal (opens 1 day before at 10 AM for AC classes)</li>
              <li>Check <Link to="/seat-availability" className="text-primary underline font-medium">Seat Availability</Link> across multiple dates to find the best option</li>
              <li>Use <Link to="/fare-inquiry" className="text-primary underline font-medium">Fare Inquiry</Link> to compare fares across classes before booking</li>
            </ul>

            <h2 className="text-xl font-bold text-slate-900 mt-8 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>Frequently Asked Questions</h2>
            <div className="space-y-4 mb-6">
              {faqs.map((faq, i) => (
                <div key={i} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start gap-2">
                    <HelpCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-slate-800 text-sm mb-1">{faq.question}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 mt-8">
              <p className="text-sm font-semibold text-slate-800 mb-2">Search Delhi to Mumbai Trains</p>
              <p className="text-sm text-slate-600 mb-3">Check real-time availability and fares for all Delhi–Mumbai trains.</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/train-search" className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
                  <Train size={15} /> Search Trains
                </Link>
                <Link to="/fare-inquiry" className="inline-flex items-center gap-2 bg-white border border-primary text-primary px-4 py-2 rounded-xl text-sm font-semibold hover:bg-primary/5 transition-colors">
                  <IndianRupee size={15} /> Check Fares
                </Link>
              </div>
            </div>

          </motion.article>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <SocialShareBar title="Best Trains from Delhi to Mumbai 2026 — Complete Guide" url="https://chalotrain.com/blog/best-trains-delhi-to-mumbai" />
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <RelatedTools currentHref="/blog/best-trains-delhi-to-mumbai" />
          </motion.div>

        </div>
      </section>
    </>
  );
}
