import { useState, useEffect } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { useSearchParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  Building2, MapPin, Star, ChevronRight, ChevronLeft,
  Wifi, Coffee, Car, Dumbbell, Waves, UtensilsCrossed,
  ExternalLink, AlertCircle, Train, Search,
  CheckCircle2, Clock, Images,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────────
interface HotelDetails {
  id: string;
  name: string;
  description: string;
  starRating: number;
  reviewScore: number;
  reviewScoreWord: string;
  reviewCount: number;
  address: string;
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  photos: { url: string; description: string }[];
  facilities: string[];
  checkinFrom: string;
  checkoutUntil: string;
  pricePerNight: number;
  currency: string;
  dealBadge: string;
  url: string;
}

// ── Helpers ────────────────────────────────────────────────────────────────────
function formatPrice(price: number, currency = 'INR') {
  if (!price) return '—';
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 0 }).format(price);
}

function StarRow({ count }: { count: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map((i) => (
        <Star key={i} size={13} className={i <= count ? 'text-amber-400 fill-amber-400' : 'text-slate-200 fill-slate-200'} />
      ))}
    </div>
  );
}

const FACILITY_ICONS: Record<string, React.ReactNode> = {
  wifi:       <Wifi size={14} />,
  internet:   <Wifi size={14} />,
  breakfast:  <Coffee size={14} />,
  restaurant: <UtensilsCrossed size={14} />,
  parking:    <Car size={14} />,
  gym:        <Dumbbell size={14} />,
  fitness:    <Dumbbell size={14} />,
  pool:       <Waves size={14} />,
  swimming:   <Waves size={14} />,
};

function FacilityIcon({ name }: { name: string }) {
  const lower = name.toLowerCase();
  const key = Object.keys(FACILITY_ICONS).find((k) => lower.includes(k));
  return <span className="text-violet-500">{key ? FACILITY_ICONS[key] : <CheckCircle2 size={14} />}</span>;
}

// ── Photo gallery ──────────────────────────────────────────────────────────────
function PhotoGallery({ photos, name }: { photos: { url: string; description: string }[]; name: string }) {
  const [active, setActive] = useState(0);
  const [imgErr, setImgErr] = useState<Record<number, boolean>>({});
  const [lightbox, setLightbox] = useState(false);

  if (!photos.length) {
    return (
      <div className="w-full h-56 sm:h-72 rounded-2xl bg-gradient-to-br from-violet-100 to-purple-100 flex items-center justify-center">
        <Building2 size={48} className="text-violet-300" />
      </div>
    );
  }

  const prev = () => setActive((a) => (a - 1 + photos.length) % photos.length);
  const next = () => setActive((a) => (a + 1) % photos.length);

  return (
    <>
      <div className="relative rounded-2xl overflow-hidden bg-slate-100 shadow-sm">
        {/* Main image */}
        <div className="w-full h-56 sm:h-80 relative cursor-pointer" onClick={() => setLightbox(true)}>
          {imgErr[active] ? (
            <div className="w-full h-full bg-gradient-to-br from-violet-100 to-purple-100 flex items-center justify-center">
              <Building2 size={48} className="text-violet-300" />
            </div>
          ) : (
            <img
              key={active}
              src={photos[active].url}
              alt={photos[active].description || name}
              className="w-full h-full object-cover"
              onError={() => setImgErr((e) => ({ ...e, [active]: true }))}
            />
          )}
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
          {/* Counter + expand hint */}
          <div className="absolute bottom-3 right-3 flex items-center gap-2">
            <div className="bg-black/50 text-white text-xs font-semibold px-2 py-1 rounded-lg backdrop-blur-sm flex items-center gap-1">
              <Images size={11} /> {active + 1} / {photos.length}
            </div>
          </div>
        </div>

        {/* Nav arrows */}
        {photos.length > 1 && (
          <>
            <button onClick={prev}
              className="absolute left-3 top-[calc(50%-20px)] w-8 h-8 rounded-full bg-white/85 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors shadow-sm"
              aria-label="Previous photo"
            >
              <ChevronLeft size={16} className="text-slate-700" />
            </button>
            <button onClick={next}
              className="absolute right-3 top-[calc(50%-20px)] w-8 h-8 rounded-full bg-white/85 backdrop-blur-sm flex items-center justify-center hover:bg-white transition-colors shadow-sm"
              aria-label="Next photo"
            >
              <ChevronRight size={16} className="text-slate-700" />
            </button>
          </>
        )}

        {/* Thumbnail strip */}
        {photos.length > 1 && (
          <div className="flex gap-1.5 p-2 overflow-x-auto">
            {photos.slice(0, 10).map((p, i) => (
              <button key={i} onClick={() => setActive(i)}
                className={`shrink-0 w-14 h-10 rounded-lg overflow-hidden border-2 transition-all ${i === active ? 'border-violet-500 opacity-100' : 'border-transparent opacity-55 hover:opacity-90'}`}
              >
                {imgErr[i] ? (
                  <div className="w-full h-full bg-violet-100 flex items-center justify-center">
                    <Building2 size={12} className="text-violet-300" />
                  </div>
                ) : (
                  <img src={p.url} alt="" className="w-full h-full object-cover"
                    onError={() => setImgErr((e) => ({ ...e, [i]: true }))}
                  />
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
            onClick={() => setLightbox(false)}
          >
            <button className="absolute top-4 right-4 text-white/70 hover:text-white text-2xl font-bold" onClick={() => setLightbox(false)}>✕</button>
            <button className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center" onClick={(e) => { e.stopPropagation(); prev(); }}>
              <ChevronLeft size={20} className="text-white" />
            </button>
            <img
              src={photos[active].url}
              alt={photos[active].description || name}
              className="max-w-full max-h-[85vh] object-contain rounded-xl"
              onClick={(e) => e.stopPropagation()}
            />
            <button className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center" onClick={(e) => { e.stopPropagation(); next(); }}>
              <ChevronRight size={20} className="text-white" />
            </button>
            <div className="absolute bottom-4 text-white/60 text-sm">{active + 1} / {photos.length}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// ── Review score badge ─────────────────────────────────────────────────────────
function ReviewBadge({ score, word, count }: { score: number; word: string; count: number }) {
  const color =
    score >= 9 ? 'bg-green-600' :
    score >= 8 ? 'bg-green-500' :
    score >= 7 ? 'bg-blue-500' :
    score >= 6 ? 'bg-amber-500' : 'bg-slate-400';

  return (
    <div className="flex items-center gap-2">
      <div className={`${color} text-white text-sm font-bold px-2.5 py-1 rounded-xl`}>
        {score.toFixed(1)}
      </div>
      <div>
        <div className="text-sm font-bold text-slate-800">{word}</div>
        {count > 0 && <div className="text-xs text-slate-400">{count.toLocaleString()} reviews</div>}
      </div>
    </div>
  );
}

// ── Loading skeleton ───────────────────────────────────────────────────────────
function DetailsSkeleton() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="bg-white rounded-2xl overflow-hidden">
        <div className="h-64 bg-slate-200" />
        <div className="flex gap-1.5 p-2">
          {[1,2,3,4].map((i) => <div key={i} className="w-14 h-10 rounded-lg bg-slate-200 shrink-0" />)}
        </div>
      </div>
      <div className="bg-white rounded-2xl p-5 space-y-3">
        <div className="h-6 bg-slate-200 rounded w-3/4" />
        <div className="h-4 bg-slate-100 rounded w-1/3" />
        <div className="h-4 bg-slate-100 rounded w-1/2" />
        <div className="h-4 bg-slate-100 rounded w-2/3" />
        <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
          <div className="h-8 bg-slate-200 rounded w-28" />
          <div className="h-10 bg-slate-200 rounded w-40" />
        </div>
      </div>
      <div className="bg-white rounded-2xl p-5 space-y-2">
        <div className="h-4 bg-slate-200 rounded w-1/3 mb-3" />
        {[1,2,3,4,5,6].map((i) => <div key={i} className="h-4 bg-slate-100 rounded w-full" />)}
      </div>
    </div>
  );
}

// ── Main page ──────────────────────────────────────────────────────────────────
export default function HotelDetailsPage() {
  const [searchParams] = useSearchParams();
  const hotelId  = searchParams.get('id') ?? '';
  const checkIn  = searchParams.get('checkIn') ?? '';
  const checkOut = searchParams.get('checkOut') ?? '';
  const adults   = searchParams.get('adults') ?? '2';
  const currency = searchParams.get('currency') ?? 'INR';

  const [hotel, setHotel]     = useState<HotelDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  useEffect(() => {
    if (!hotelId) { setLoading(false); setError('No hotel ID provided.'); return; }
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ hotelId, checkIn, checkOut, adults, currency });
    fetch(`/api/hotels/details?${params.toString()}`)
      .then(async (r) => {
        const j = await r.json() as HotelDetails & { message?: string };
        if (!r.ok) throw new Error(j.message ?? `HTTP ${r.status}`);
        setHotel(j);
      })
      .catch((e: unknown) => setError(e instanceof Error ? e.message : 'Failed to load hotel details.'))
      .finally(() => setLoading(false));
  }, [hotelId, checkIn, checkOut, adults, currency]);

  const title = hotel ? `${hotel.name} — Hotel Details | ChaloTrain` : 'Hotel Details | ChaloTrain';

  // Night count
  const nightCount = checkIn && checkOut
    ? Math.max(1, Math.round((new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86400000))
    : 1;

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={hotel ? `${hotel.name} in ${hotel.city}. ${hotel.reviewScoreWord} · ${hotel.reviewScore}/10 · From ${formatPrice(hotel.pricePerNight, hotel.currency)} per night.` : 'Hotel details on ChaloTrain.'} />
        <meta name="robots" content="noindex, nofollow" />
        {hotel && <link rel="canonical" href={`https://chalotrain.com/hotel-details?id=${hotel.id}`} />}
        {hotel && <meta property="og:title" content={title} />}
        {hotel && <meta property="og:description" content={`${hotel.name} in ${hotel.city}. ${hotel.reviewScoreWord} · ${hotel.reviewScore}/10`} />}
        {hotel && <meta property="og:image" content={hotel.photos?.[0]?.url ?? 'https://chalotrain.com/og-image.png'} />}
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        {hotel && hotel.reviewScore > 0 && (
          <script type="application/ld+json">{JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'LodgingBusiness',
            name: hotel.name,
            description: hotel.description || undefined,
            address: hotel.address ? {
              '@type': 'PostalAddress',
              streetAddress: hotel.address,
              addressLocality: hotel.city,
              addressCountry: hotel.country,
            } : undefined,
            aggregateRating: {
              '@type': 'AggregateRating',
              ratingValue: hotel.reviewScore,
              bestRating: 10,
              reviewCount: hotel.reviewCount || undefined,
            },
            image: hotel.photos?.[0]?.url || undefined,
            starRating: hotel.starRating > 0 ? { '@type': 'Rating', ratingValue: hotel.starRating } : undefined,
          })}</script>
        )}
      </Helmet>

      {/* ── Breadcrumb header ─────────────────────────────────────────────── */}
      <div className="bg-gradient-to-r from-[#1a0a3e] to-violet-800 py-4">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="flex items-center gap-1.5 text-violet-300/70 text-xs">
            <Link to="/" className="hover:text-white transition-colors">Home</Link>
            <ChevronRight size={12} />
            <Link to="/hotels" className="hover:text-white transition-colors">Hotels</Link>
            <ChevronRight size={12} />
            <span className="text-white/80 truncate max-w-[160px]">{hotel?.name ?? 'Details'}</span>
          </div>
        </div>
      </div>

      <div className="bg-[#f0f4f8] min-h-screen py-6 pb-24 sm:pb-6">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* Loading */}
          {loading && <DetailsSkeleton />}

          {/* Error */}
          {!loading && error && (
            <div className="flex items-start gap-3 bg-red-50 border border-red-200 rounded-2xl p-5">
              <AlertCircle size={20} className="text-red-500 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-red-700">Could not load hotel</div>
                <div className="text-sm text-red-600 mt-0.5">{error}</div>
                <Link to="/hotels" className="inline-flex items-center gap-1 mt-3 text-sm font-semibold text-violet-600 hover:text-violet-700">
                  <ChevronLeft size={14} /> Back to Hotels
                </Link>
              </div>
            </div>
          )}

          {/* Content */}
          {!loading && hotel && (
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

              {/* Photo gallery */}
              <PhotoGallery photos={hotel.photos} name={hotel.name} />

              {/* Main info card */}
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <h1 className="text-xl font-bold text-slate-900 leading-snug">{hotel.name}</h1>
                    {hotel.starRating > 0 && (
                      <div className="mt-1"><StarRow count={hotel.starRating} /></div>
                    )}
                  </div>
                  {hotel.dealBadge && (
                    <span className="shrink-0 bg-orange-100 text-orange-700 text-xs font-bold px-2.5 py-1 rounded-xl">
                      {hotel.dealBadge}
                    </span>
                  )}
                </div>

                {/* Location */}
                {(hotel.address || hotel.city) && (
                  <div className="flex items-start gap-1.5 text-sm text-slate-500 mb-3">
                    <MapPin size={14} className="text-violet-400 shrink-0 mt-0.5" />
                    <span>{[hotel.address, hotel.city, hotel.country].filter(Boolean).join(', ')}</span>
                  </div>
                )}

                {/* Review */}
                {hotel.reviewScore > 0 && (
                  <div className="mb-4">
                    <ReviewBadge score={hotel.reviewScore} word={hotel.reviewScoreWord} count={hotel.reviewCount} />
                  </div>
                )}

                {/* Stay summary */}
                {(checkIn || checkOut) && (
                  <div className="flex items-center gap-2 mb-4 bg-violet-50 rounded-xl px-3 py-2.5 text-xs text-violet-700 font-semibold">
                    <Clock size={13} className="text-violet-500 shrink-0" />
                    {checkIn && <span>{checkIn}</span>}
                    {checkIn && checkOut && <span className="text-violet-400">→</span>}
                    {checkOut && <span>{checkOut}</span>}
                    <span className="text-violet-400">·</span>
                    <span>{nightCount} night{nightCount > 1 ? 's' : ''}</span>
                    <span className="text-violet-400">·</span>
                    <span>{adults} adult{Number(adults) > 1 ? 's' : ''}</span>
                  </div>
                )}

                {/* Price + CTA */}
                <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-100">
                  <div>
                    {hotel.pricePerNight > 0 ? (
                      <>
                        <div className="text-2xl font-bold text-slate-900">{formatPrice(hotel.pricePerNight, hotel.currency)}</div>
                        <div className="text-xs text-slate-400">per night · taxes may apply</div>
                        {nightCount > 1 && (
                          <div className="text-xs text-violet-600 font-semibold mt-0.5">
                            ≈ {formatPrice(hotel.pricePerNight * nightCount, hotel.currency)} total
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="text-sm text-slate-400 italic">Price not available</div>
                    )}
                  </div>
                  {hotel.url && (
                    <a href={hotel.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-2 px-5 py-2.5 bg-violet-600 text-white text-sm font-bold rounded-xl hover:bg-violet-700 transition-colors shadow-sm"
                    >
                      Book on Booking.com <ExternalLink size={13} />
                    </a>
                  )}
                </div>
              </div>

              {/* Check-in / Check-out times */}
              {(hotel.checkinFrom || hotel.checkoutUntil) && (
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
                  <h2 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                    <Clock size={14} className="text-violet-500" /> Check-in & Check-out
                  </h2>
                  <div className="grid grid-cols-2 gap-3">
                    {hotel.checkinFrom && (
                      <div className="bg-slate-50 rounded-xl p-3">
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Check-in from</div>
                        <div className="text-base font-bold text-slate-800">{hotel.checkinFrom}</div>
                      </div>
                    )}
                    {hotel.checkoutUntil && (
                      <div className="bg-slate-50 rounded-xl p-3">
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Check-out until</div>
                        <div className="text-base font-bold text-slate-800">{hotel.checkoutUntil}</div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Description */}
              {hotel.description && (
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                  <h2 className="text-sm font-bold text-slate-700 mb-2">About this property</h2>
                  <p className="text-sm text-slate-600 leading-relaxed line-clamp-6">{hotel.description}</p>
                </div>
              )}

              {/* Facilities */}
              {hotel.facilities.length > 0 && (
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
                  <h2 className="text-sm font-bold text-slate-700 mb-3">Facilities & Amenities</h2>
                  <div className="grid grid-cols-2 gap-2.5">
                    {hotel.facilities.map((f, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 rounded-lg px-2.5 py-2">
                        <FacilityIcon name={f} />
                        <span className="truncate">{f}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Map link */}
              {hotel.latitude !== 0 && hotel.longitude !== 0 && (
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${hotel.latitude},${hotel.longitude}`}
                  target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-3 bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:border-violet-200 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-xl bg-violet-100 flex items-center justify-center shrink-0">
                    <MapPin size={18} className="text-violet-500" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-800 group-hover:text-violet-700 transition-colors">View on Google Maps</div>
                    <div className="text-xs text-slate-400">{hotel.city}{hotel.country ? `, ${hotel.country}` : ''}</div>
                  </div>
                  <ExternalLink size={14} className="text-slate-400 ml-auto" />
                </a>
              )}

              {/* Train nudge */}
              <div className="flex flex-col sm:flex-row items-center gap-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Train size={18} className="text-primary" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">Check your train too</div>
                    <div className="text-xs text-slate-500">Verify PNR and live status before you travel.</div>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Link to="/pnr-status" className="flex items-center gap-1.5 px-3 py-2 bg-primary text-white text-xs font-bold rounded-xl hover:bg-blue-700 transition-colors">
                    <Search size={11} /> PNR Status
                  </Link>
                  <Link to="/hotels" className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-bold rounded-xl hover:border-primary/40 transition-colors">
                    <ChevronLeft size={11} /> More Hotels
                  </Link>
                </div>
              </div>

            </motion.div>
          )}
        </div>
      </div>

      {/* ── Sticky mobile booking bar ─────────────────────────────────────── */}
      {hotel?.url && (
        <div className="fixed bottom-0 left-0 right-0 sm:hidden bg-white border-t border-slate-200 px-4 py-3 z-40 shadow-[0_-4px_20px_hsl(0_0%_0%/0.08)]">
          <div className="flex items-center justify-between gap-3">
            <div>
              {hotel.pricePerNight > 0 && (
                <>
                  <div className="text-lg font-bold text-slate-900 leading-none">{formatPrice(hotel.pricePerNight, hotel.currency)}</div>
                  <div className="text-[10px] text-slate-400">per night</div>
                </>
              )}
            </div>
            <a href={hotel.url} target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-5 py-2.5 bg-violet-600 text-white text-sm font-bold rounded-xl hover:bg-violet-700 transition-colors"
            >
              Book on Booking.com <ExternalLink size={13} />
            </a>
          </div>
        </div>
      )}
    </>
  );
}
