import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { Armchair, Search, Calendar, Train } from 'lucide-react';
import PageHero from '@/components/PageHero';
import StatusBadge from '@/components/StatusBadge';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection, { type FAQItem } from '@/components/FAQSection';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorMessage from '@/components/ErrorMessage';
import { checkSeatAvailability, validateTrainNumber, validateStationCode, type SeatAvailabilityResponse } from '@/lib/api-client';

// Display labels → API codes
const CLASS_OPTIONS = [
  { label: '1A', code: '1A' },
  { label: '2A', code: '2A' },
  { label: '3A', code: '3A' },
  { label: '3E', code: '3E' },
  { label: 'SL', code: 'SL' },
  { label: 'CC', code: 'CC' },
  { label: '2S', code: '2S' },
];

const QUOTA_OPTIONS = [
  { label: 'General',         code: 'GN' },
  { label: 'Ladies',          code: 'LD' },
  { label: 'Senior Citizen',  code: 'SS' },
  { label: 'Tatkal',          code: 'TQ' },
  { label: 'Premium Tatkal',  code: 'PT' },
  { label: 'Defence',         code: 'DF' },
  { label: 'Divyaang',        code: 'HP' },
];

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
};

const FAQ_ITEMS: FAQItem[] = [
  { question: 'How do I check seat availability for a train?', answer: 'Enter the train number, source and destination stations, and your journey date. Select your preferred class (1A, 2A, 3A, SL, etc.) and quota (General, Tatkal, Ladies). Click "Check Availability" to see seat status for the next 7 days.' },
  { question: 'What do the availability statuses mean?', answer: 'AVAILABLE means seats are confirmed. RAC (Reservation Against Cancellation) means you share a berth initially. WL (Waitlist) means you\'re on the waiting list. The number indicates your position (e.g., WL15 means 15th on waitlist). REGRET means fully booked with no waitlist.' },
  { question: 'When does Tatkal booking open?', answer: 'Tatkal quota opens 1 day before train departure. For AC classes (1A, 2A, 3A, 3E, CC, EC), booking starts at 10:00 AM. For non-AC classes (SL, 2S), it opens at 11:00 AM. Premium Tatkal has dynamic pricing and opens simultaneously with regular Tatkal.' },
  { question: 'Can I check availability for multiple classes at once?', answer: 'Yes! After searching, you\'ll see a calendar grid showing availability across dates. Green indicates available seats, yellow shows RAC/Waitlist, and red means fully booked. This helps you compare and choose the best class and date for your journey.' },
  { question: 'Why is availability different for different quotas?', answer: 'Indian Railways allocates separate seat quotas for different categories: General (majority), Ladies (for women travelers), Senior Citizen (for 60+ passengers), Tatkal (last-minute booking), Defence (for armed forces), and Divyaang (for persons with disabilities). Each quota has its own availability.' },
];

export default function SeatAvailabilityPage() {
  const [trainNo, setTrainNo] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [selectedClass, setSelectedClass] = useState('3A');
  const [selectedQuota, setSelectedQuota] = useState('GN');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SeatAvailabilityResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<{ train?: string; from?: string; to?: string }>({});

  const doFetch = async (train: string, fromCode: string, toCode: string, cls: string, quota: string, dt: string) => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await checkSeatAvailability(train, fromCode, toCode, dt, cls, quota);
      setResult(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message.toLowerCase() : '';
      if (msg.includes('rate limit') || msg.includes('429') || msg.includes('quota')) {
        setError('Seat Availability service temporarily unavailable due to high traffic. Please try again in a few minutes.');
      } else if (msg.includes('network') || msg.includes('could not reach')) {
        setError('Unable to connect to railway data service. Please check your internet connection and try again.');
      } else if (msg.includes('not configured') || msg.includes('not yet configured')) {
        setError('Seat Availability service is currently being set up. Please try again shortly.');
      } else if (msg.includes('not found') || msg.includes('invalid')) {
        setError('Seat availability data not found. Please verify train number, stations, date, class, and quota.');
      } else {
        setError('Seat Availability service temporarily unavailable. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError({});

    const trainV = validateTrainNumber(trainNo.trim());
    const fromV  = validateStationCode(from.trim());
    const toV    = validateStationCode(to.trim());

    if (!trainV.valid || !fromV.valid || !toV.valid) {
      setValidationError({ train: trainV.error, from: fromV.error, to: toV.error });
      return;
    }

    await doFetch(trainNo.trim(), from.trim().toUpperCase(), to.trim().toUpperCase(), selectedClass, selectedQuota, date);
  };

  const handleRetry = () => {
    const trainV = validateTrainNumber(trainNo.trim());
    const fromV  = validateStationCode(from.trim());
    const toV    = validateStationCode(to.trim());
    if (!trainV.valid || !fromV.valid || !toV.valid) return;
    doFetch(trainNo.trim(), from.trim().toUpperCase(), to.trim().toUpperCase(), selectedClass, selectedQuota, date);
  };

  const getAvailColor = (status: string) => {
    const s = status.toUpperCase();
    if (s.startsWith('AVAILABLE') || s.startsWith('AVL')) return 'bg-green-50 border-green-200 hover:border-green-400';
    if (s.startsWith('RAC')) return 'bg-yellow-50 border-yellow-200 hover:border-yellow-400';
    return 'bg-red-50 border-red-200 hover:border-red-400';
  };

  return (
    <>
      <Helmet>
        <title>Seat Availability — Check Train Seat Availability Online | ChaloTrain</title>
        <meta name="description" content="Check seat availability for any Indian Railways train across all classes (1A, 2A, 3A, SL, CC) and quotas (General, Tatkal, Ladies). View 7-day availability calendar. No login required." />
        <meta name="keywords" content="seat availability, train seat availability, IRCTC seat availability, check seat availability, 1A 2A 3A SL availability, Tatkal seat availability" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Seat Availability — Check Train Seat Availability Online | ChaloTrain" />
        <meta property="og:description" content="Check seat availability for any Indian Railways train across all classes and quotas. View 7-day availability calendar." />
        <meta property="og:url" content="https://chalotrain.com/seat-availability" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Seat Availability — Check Train Seat Availability Online | ChaloTrain" />
        <meta name="twitter:description" content="Check seat availability for any Indian Railways train across all classes and quotas. View 7-day availability calendar." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/seat-availability" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'Train Seat Availability Checker — ChaloTrain',
          url: 'https://chalotrain.com/seat-availability',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'All',
          description: 'Check seat availability for Indian Railways trains across all classes and quotas with a 7-day calendar view.',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
          provider: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'Seat Availability', item: 'https://chalotrain.com/seat-availability' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        icon={Armchair}
        title="Seat Availability"
        subtitle="Check seat availability across all classes, quotas and upcoming dates."
        badge="Multi-date View"
      />
      {/* sr-only h1 for SEO checkers — PageHero renders the visible heading */}
      <h1 className="sr-only">Seat Availability — Check Train Seat Availability for All Classes &amp; Quotas</h1>

      <section className="py-10 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* SEO Introduction */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-blue-100/60 p-6 mb-6 shadow-[0_2px_12px_hsl(221_79%_48%/0.06)]">
            <h2 className="text-xl font-bold text-slate-900 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              Check Train Seat Availability — All Classes &amp; Quotas
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Planning to book train tickets? Check seat availability before you book! ChaloTrain's Seat Availability tool shows you current availability status across all classes (1A, 2A, 3A, Sleeper, 2S, CC, EC) and quotas (General, Tatkal, Ladies, Senior Citizen) for the next 7 days.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              No more guessing or multiple IRCTC searches. Our comprehensive calendar view lets you see availability trends at a glance. Green means seats available, yellow indicates RAC/Waitlist, and red shows fully booked. Compare different dates and classes to find the best booking option for your journey.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>How to use:</strong> Enter your train number, source and destination stations, and select your journey date. Choose your preferred class and quota. Click "Check Availability" to see a date-wise grid showing seat status. Use this information to plan your booking strategy and choose the best travel date.
            </p>
          </motion.div>

          <motion.div initial="hidden" animate="visible" variants={fadeUp}
            className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-6"
          >
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="seat-train-no" className="block text-sm font-semibold text-slate-700 mb-1.5">Train Number</label>
                <div className="relative">
                  <Train size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                  <input
                    id="seat-train-no"
                    type="text"
                    inputMode="numeric"
                    value={trainNo}
                    onChange={(e) => {
                      setTrainNo(e.target.value.replace(/\D/g, '').slice(0, 5));
                      setValidationError((p) => ({ ...p, train: undefined }));
                    }}
                    placeholder="e.g. 12301"
                    maxLength={5}
                    className={`w-full pl-10 pr-4 py-3 border rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px] ${validationError.train ? 'border-red-300 bg-red-50' : 'border-slate-200'}`}
                  />
                </div>
                {validationError.train && <p className="text-xs text-red-600 mt-1" role="alert">{validationError.train}</p>}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="seat-from" className="block text-sm font-semibold text-slate-700 mb-1.5">From Station</label>
                  <input
                    id="seat-from"
                    type="text"
                    value={from}
                    onChange={(e) => {
                      setFrom(e.target.value.toUpperCase());
                      setValidationError((p) => ({ ...p, from: undefined }));
                    }}
                    placeholder="e.g. HWH"
                    maxLength={7}
                    autoComplete="off"
                    className={`w-full px-4 py-3 border rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm uppercase min-h-[44px] ${validationError.from ? 'border-red-300 bg-red-50' : 'border-slate-200'}`}
                  />
                  {validationError.from && <p className="text-xs text-red-600 mt-1" role="alert">{validationError.from}</p>}
                </div>
                <div>
                  <label htmlFor="seat-to" className="block text-sm font-semibold text-slate-700 mb-1.5">To Station</label>
                  <input
                    id="seat-to"
                    type="text"
                    value={to}
                    onChange={(e) => {
                      setTo(e.target.value.toUpperCase());
                      setValidationError((p) => ({ ...p, to: undefined }));
                    }}
                    placeholder="e.g. NDLS"
                    maxLength={7}
                    autoComplete="off"
                    className={`w-full px-4 py-3 border rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm uppercase min-h-[44px] ${validationError.to ? 'border-red-300 bg-red-50' : 'border-slate-200'}`}
                  />
                  {validationError.to && <p className="text-xs text-red-600 mt-1" role="alert">{validationError.to}</p>}
                </div>
              </div>

              {/* Class Selector */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5" id="seat-class-label">Travel Class</label>
                <div className="flex flex-wrap gap-2" role="group" aria-labelledby="seat-class-label">
                  {CLASS_OPTIONS.map(({ label, code }) => (
                    <button
                      key={code}
                      type="button"
                      onClick={() => setSelectedClass(code)}
                      aria-pressed={selectedClass === code}
                      className={`px-3 py-2 rounded-lg text-sm font-semibold border transition-all min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 ${selectedClass === code ? 'bg-primary text-white border-primary' : 'bg-white text-slate-600 border-slate-200 hover:border-primary hover:text-primary'}`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="seat-quota" className="block text-sm font-semibold text-slate-700 mb-1.5">Quota</label>
                  <select
                    id="seat-quota"
                    value={selectedQuota}
                    onChange={(e) => setSelectedQuota(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm bg-white min-h-[44px]"
                  >
                    {QUOTA_OPTIONS.map(({ label, code }) => (
                      <option key={code} value={code}>{label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="seat-date" className="block text-sm font-semibold text-slate-700 mb-1.5">Journey Date</label>
                  <input
                    id="seat-date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-60 min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
              >
                <Search size={18} aria-hidden="true" />
                Check Availability
              </button>
            </form>
          </motion.div>

          <AnimatePresence mode="wait">
            {loading && (
              <motion.div key="loading" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <LoadingSpinner message="Checking seat availability..." />
              </motion.div>
            )}

            {error && !loading && (
              <motion.div key="error" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <ErrorMessage title="Unable to Check Availability" message={error} onRetry={handleRetry} />
              </motion.div>
            )}

            {result && !loading && !error && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4, ease: 'easeOut' as const }}
                className="space-y-4"
              >
                {/* Train Info */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs text-slate-400 mb-0.5">{result.trainNumber}</div>
                      <h2 className="font-bold text-slate-800 text-lg" style={{ fontFamily: 'var(--font-heading)' }}>{result.trainName}</h2>
                      <div className="text-sm text-slate-500 mt-0.5">{result.from} → {result.to}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-slate-400">Class / Quota</div>
                      <div className="font-bold text-primary">{result.class} / {result.quota}</div>
                    </div>
                  </div>
                </div>

                {/* Date-wise Availability */}
                {result.availability.length > 0 ? (
                  <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                      <Calendar size={16} className="text-primary" />
                      <h3 className="font-semibold text-slate-800" style={{ fontFamily: 'var(--font-heading)' }}>
                        Date-wise Availability
                      </h3>
                    </div>
                    <div className="p-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {result.availability.map((item) => (
                        <div
                          key={item.date}
                          className={`p-3 rounded-xl border-2 transition-all cursor-pointer ${getAvailColor(item.status)}`}
                        >
                          <div className="font-bold text-slate-800 text-sm">{item.date}</div>
                          <div className="mt-2">
                            <StatusBadge status={item.status} size="sm" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center">
                    <p className="text-sm text-slate-500">No availability data returned for this combination. Try a different class or quota.</p>
                  </div>
                )}

                {/* Legend */}
                <div className="bg-white rounded-2xl shadow-sm border border-blue-100/60 p-4">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">Legend</div>
                  <div className="flex flex-wrap gap-3">
                    {[
                      { label: 'AVL — Available', color: 'bg-green-100 text-green-700' },
                      { label: 'RAC — Reservation Against Cancellation', color: 'bg-yellow-100 text-yellow-700' },
                      { label: 'WL — Waitlist', color: 'bg-red-100 text-red-700' },
                    ].map((item) => (
                      <span key={item.label} className={`text-xs px-3 py-1.5 rounded-full font-medium ${item.color}`}>
                        {item.label}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Related Tools */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <RelatedTools currentHref="/seat-availability" />
          </motion.div>

          {/* Social Share */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <SocialShareBar
              title="Check train seat availability on ChaloTrain — All classes & quotas"
              url="https://chalotrain.com/seat-availability"
            />
          </motion.div>

          {/* FAQ */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <FAQSection items={FAQ_ITEMS} />
          </motion.div>

          {/* Learn more */}
          <div className="container mx-auto px-4 pb-2 mt-3">
            <div className="max-w-2xl mx-auto">
              <p className="text-sm text-slate-500">
                Want to learn more?{' '}
                <Link to="/blog/how-to-check-seat-availability" className="text-primary hover:underline font-medium">
                  Read our complete guide →
                </Link>
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> This website is not affiliated with IRCTC or Indian Railways and provides railway information for general purposes only. Please verify critical information from official sources.
              </p>
            </div>
          </motion.div>

        </div>
      </section>
    </>
  );
}
