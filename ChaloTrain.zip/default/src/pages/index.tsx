import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import {
  Ticket, Train, ArrowLeftRight, Armchair, Clock, IndianRupee,
  Zap, ShieldCheck, Smartphone, ArrowRight, Search, ChevronRight,
  CheckCircle2, MapPin, Star, TrendingUp,
  Sparkles,
} from 'lucide-react';
import AdBanner from '@/components/AdBanner';

// ─── Animation Variants ───────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.38, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.07 } } };

// ─── Data ─────────────────────────────────────────────────────────────────────
const trainTabs = [
  { id: 'pnr',    label: 'PNR Status',   placeholder: 'Enter 10-digit PNR number',  href: '/pnr-status'   },
  { id: 'live',   label: 'Live Status',  placeholder: 'Enter train number or name', href: '/live-status'  },
  { id: 'search', label: 'Train Search', placeholder: 'Enter source station code',  href: '/train-search' },
];

const tools = [
  { icon: Ticket,         title: 'PNR Status',             description: 'Check booking status, coach & berth details instantly.',       href: '/pnr-status',        accent: 'bg-blue-50 text-blue-600',    border: 'hover:border-blue-200',   glow: 'hover:shadow-[0_8px_32px_hsl(221_79%_48%/0.15)]', popular: true  },
  { icon: ArrowLeftRight, title: 'Train Between Stations', description: 'Find all trains running between two stations on any date.',     href: '/train-search',      accent: 'bg-sky-50 text-sky-600',      border: 'hover:border-sky-200',    glow: 'hover:shadow-[0_8px_32px_hsl(199_89%_48%/0.15)]', popular: true  },
  { icon: Train,          title: 'Live Train Status',      description: 'Track your train live with running status updates.',            href: '/live-status',       accent: 'bg-indigo-50 text-indigo-600',border: 'hover:border-indigo-200', glow: 'hover:shadow-[0_8px_32px_hsl(239_84%_67%/0.15)]', popular: false },
  { icon: Armchair,       title: 'Seat Availability',      description: 'Check seat availability across all classes and quotas.',        href: '/seat-availability', accent: 'bg-violet-50 text-violet-600',border: 'hover:border-violet-200', glow: 'hover:shadow-[0_8px_32px_hsl(262_83%_58%/0.15)]', popular: false },
  { icon: Clock,          title: 'Train Schedule',         description: 'View complete timetable with all stops and timings.',           href: '/train-schedule',    accent: 'bg-cyan-50 text-cyan-600',    border: 'hover:border-cyan-200',   glow: 'hover:shadow-[0_8px_32px_hsl(188_94%_43%/0.15)]', popular: false },
  { icon: IndianRupee,    title: 'Fare Inquiry',           description: 'Compare fares across classes, quotas and concessions.',         href: '/fare-inquiry',      accent: 'bg-orange-50 text-orange-600',border: 'hover:border-orange-200', glow: 'hover:shadow-[0_8px_32px_hsl(25_95%_53%/0.15)]',  popular: false },
];

const benefits = [
  { icon: Zap,         title: 'Fast & Simple',   description: 'Designed to deliver railway information quickly. No clutter, no unnecessary steps.',  gradient: 'from-[#1040a8] to-[#1a56db]' },
  { icon: ShieldCheck, title: 'Reliable Tools',  description: 'Six tools covering every aspect of your train journey — PNR, live status, fares and more.', gradient: 'from-[#3730a3] to-[#6366f1]' },
  { icon: Smartphone,  title: 'Mobile First',    description: 'Designed for on-the-go travelers. Works seamlessly on any device, any screen size.',  gradient: 'from-[#0369a1] to-[#0ea5e9]' },
];

const popularRoutes = [
  { from: 'Delhi',     to: 'Mumbai'    },
  { from: 'Mumbai',    to: 'Pune'      },
  { from: 'Chennai',   to: 'Bangalore' },
  { from: 'Kolkata',   to: 'Delhi'     },
  { from: 'Hyderabad', to: 'Chennai'   },
  { from: 'Ahmedabad', to: 'Mumbai'    },
  { from: 'Jaipur',    to: 'Delhi'     },
  { from: 'Lucknow',   to: 'Delhi'     },
];

const trainClasses = [
  { code: '1A', name: 'First AC'       },
  { code: '2A', name: 'Second AC'      },
  { code: '3A', name: 'Third AC'       },
  { code: '3E', name: 'AC 3 Economy'   },
  { code: 'SL', name: 'Sleeper'        },
  { code: 'CC', name: 'Chair Car'      },
  { code: '2S', name: 'Second Sitting' },
  { code: 'GN', name: 'General'        },
];

// ─── Component ────────────────────────────────────────────────────────────────
export default function HomePage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('pnr');
  const [inputValue, setInputValue] = useState('');
  const currentTab = trainTabs.find((t) => t.id === activeTab)!

  return (
    <>
      <Helmet>
        <title>PNR Status, Train Between Stations & Live Train Tracking — ChaloTrain</title>
        <meta name="description" content="Check PNR status instantly, find trains between stations, track live train running status, check seat availability, train schedule and fare — all free on ChaloTrain." />
        <meta name="keywords" content="PNR status, train between stations, live train status, seat availability, train schedule, fare inquiry, Indian Railways, IRCTC PNR check" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="PNR Status, Train Between Stations & Live Train Tracking — ChaloTrain" />
        <meta property="og:description" content="Check PNR status instantly, find trains between stations, track live train running status, check seat availability, train schedule and fare — all free on ChaloTrain." />
        <meta property="og:url" content="https://chalotrain.com/" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="PNR Status, Train Between Stations & Live Train Tracking — ChaloTrain" />
        <meta name="twitter:description" content="Check PNR status instantly, find trains between stations, track live train running status, check seat availability, train schedule and fare — all free on ChaloTrain." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org', '@type': 'FAQPage',
          mainEntity: [
            { '@type': 'Question', name: 'How do I check my PNR status?', acceptedAnswer: { '@type': 'Answer', text: 'Enter your 10-digit PNR number on ChaloTrain\'s PNR Status page and click "Check PNR Status". You\'ll instantly see your booking status (CNF/RAC/WL), coach number, berth number, and passenger details. No login required.' } },
            { '@type': 'Question', name: 'What does CNF, RAC, and WL mean?', acceptedAnswer: { '@type': 'Answer', text: 'CNF means your ticket is Confirmed with a berth assigned. RAC (Reservation Against Cancellation) means you can board but share a side-lower berth. WL (Waitlist) means you\'re on the waiting list. WL e-tickets are auto-cancelled with a full refund if not confirmed by chart preparation.' } },
            { '@type': 'Question', name: 'How can I track my train live?', acceptedAnswer: { '@type': 'Answer', text: 'Use ChaloTrain\'s Live Train Status tool. Enter your train number and journey date to see live running status — current location, delay in minutes, and expected arrival time at every station.' } },
            { '@type': 'Question', name: 'When does Tatkal booking open?', acceptedAnswer: { '@type': 'Answer', text: 'Tatkal booking opens 1 day before the journey date. For AC classes (1A, 2A, 3A, CC, EC), it opens at 10:00 AM. For non-AC classes (SL, 2S), it opens at 11:00 AM.' } },
            { '@type': 'Question', name: 'Is ChaloTrain affiliated with IRCTC or Indian Railways?', acceptedAnswer: { '@type': 'Answer', text: 'No. ChaloTrain is an independent railway information portal and is not affiliated with IRCTC or Indian Railways. We provide railway information for general reference purposes.' } },
          ],
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org', '@type': 'WebSite',
          name: 'ChaloTrain', url: 'https://chalotrain.com',
          description: 'Free railway information portal — PNR status, live train tracking, train search, seat availability, schedule and fare inquiry.',
          potentialAction: { '@type': 'SearchAction', target: { '@type': 'EntryPoint', urlTemplate: 'https://chalotrain.com/train-search?from={from}&to={to}' }, 'query-input': 'required name=from required name=to' },
        })}</script>
      </Helmet>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* HERO                                                                  */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="relative overflow-hidden hero-gradient">
        {/* Dot pattern overlay */}
        <div className="absolute inset-0 dot-pattern opacity-100" />
        {/* Radial glow top-center */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-blue-400/15 rounded-full blur-[80px] pointer-events-none" />
        {/* Bottom glow */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[500px] h-[200px] bg-indigo-500/10 rounded-full blur-[60px] pointer-events-none" />

        <div className="relative container mx-auto px-4 pt-8 pb-0 sm:pt-12 md:pt-16">

          {/* Badge + Heading */}
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center mb-7">
            <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-xs font-semibold text-white/90 mb-5 backdrop-blur-sm">
              <Train size={12} className="shrink-0" />
              6 Free Railway Tools — No Login Required
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-[3.2rem] font-bold text-white leading-[1.1] mb-4 tracking-tight">
              Check PNR Status &<br />
              <span className="text-gradient-warm">Train Information</span>
            </h1>
            <p className="text-blue-200/90 text-base md:text-lg max-w-lg mx-auto leading-relaxed">
              Instant PNR status, live train tracking, trains between stations,<br className="hidden sm:block" />
              seat availability &amp; fare — all free.
            </p>
          </motion.div>

          {/* Search Card */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            className="max-w-[560px] mx-auto"
          >
            {/* ── TRAIN CARD ── */}
            <div className="bg-white rounded-2xl shadow-[0_24px_64px_hsl(221_79%_48%/0.35)] overflow-hidden">
              {/* Sub-tabs */}
              <div className="flex border-b border-slate-100" role="tablist" aria-label="Railway search tools">
                {trainTabs.map((tab) => (
                  <button key={tab.id} onClick={() => { setActiveTab(tab.id); setInputValue(''); }}
                    role="tab"
                    aria-selected={activeTab === tab.id}
                    aria-controls="hero-search-panel"
                    className={`flex-1 py-3.5 text-xs sm:text-sm font-semibold transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:ring-inset ${
                      activeTab === tab.id
                        ? 'text-primary border-b-2 border-primary bg-blue-50/70'
                        : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              {/* Input Row */}
              <div className="p-4 sm:p-5 flex gap-3" id="hero-search-panel" role="tabpanel">
                <div className="flex-1 relative">
                  <label htmlFor="hero-search-input" className="sr-only">{currentTab.label} — {currentTab.placeholder}</label>
                  <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                  <input
                    id="hero-search-input"
                    type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)}
                    placeholder={currentTab.placeholder}
                    className="w-full pl-10 pr-3 py-3 border border-slate-200 rounded-xl text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-slate-50 focus:bg-white"
                    onKeyDown={(e) => e.key === 'Enter' && navigate(currentTab.href)}
                  />
                </div>
                <Link to={currentTab.href}
                  aria-label={`Search ${currentTab.label}`}
                  className="flex items-center gap-1.5 px-4 sm:px-5 py-3 text-white text-sm font-bold rounded-xl btn-premium whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
                >
                  Search <ArrowRight size={14} aria-hidden="true" />
                </Link>
              </div>
            </div>
          </motion.div>

          {/* Stats Row */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.35 }}
            className="flex flex-wrap justify-center gap-8 md:gap-14 mt-10 pb-10 text-center"
          >
            {[
              { value: '6',       label: 'Free Tools' },
              { value: '13,000+', label: 'Trains'     },
              { value: '7,000+',  label: 'Stations'   },
              { value: '100%',    label: 'Free'        },
            ].map((stat) => (
              <div key={stat.label} className="group">
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-blue-300/80 text-xs mt-0.5 font-medium">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Wave */}
        <div className="relative h-12 overflow-hidden">
          <svg viewBox="0 0 1440 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="absolute bottom-0 w-full" preserveAspectRatio="none">
            <path d="M0 48L60 40C120 32 240 16 360 12C480 8 600 16 720 20C840 24 960 24 1080 20C1200 16 1320 8 1380 4L1440 0V48H0Z" fill="#f5f7ff" />
          </svg>
        </div>
      </section>

      {/* ── Ad Slot ── */}
      <section className="py-3 bg-background">
        <div className="container mx-auto px-4">
          <AdBanner slot="homepage-hero-leaderboard" size="leaderboard" className="mx-auto" />
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* FEATURED: PNR STATUS                                                  */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-background" id="pnr-status">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center"
          >
            {/* Left: Content */}
            <motion.div variants={fadeUp}>
              <div className="inline-flex items-center gap-1.5 bg-blue-100 text-blue-700 text-[11px] font-bold px-3 py-1 rounded-full mb-4 uppercase tracking-wider">
                <Star size={10} className="fill-blue-500 text-blue-500" /> Most Used Tool
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-3 leading-tight">
                Check PNR Status<br />
                <span className="text-gradient">Instantly & Free</span>
              </h2>
              <p className="text-slate-600 text-base leading-relaxed mb-5">
                Enter your 10-digit PNR number to instantly check your booking confirmation status, coach number, berth details and passenger-wise status — <strong>CNF, RAC or Waitlist</strong>.
              </p>
              <ul className="space-y-2.5 mb-6">
                {[
                  'Passenger-wise CNF / RAC / WL status',
                  'Coach number and berth assignment',
                  'Train departure & arrival times',
                  'Chart preparation status',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2.5 text-slate-700 text-sm">
                    <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/pnr-status"
                className="inline-flex items-center gap-2 px-6 py-3 text-white font-bold rounded-xl btn-premium text-sm"
              >
                <Ticket size={16} /> Check PNR Status Now
              </Link>
            </motion.div>

            {/* Right: Sample PNR Card — clearly labelled as example */}
            <motion.div variants={fadeUp} className="bg-white rounded-2xl shadow-[0_8px_40px_hsl(221_79%_48%/0.12)] border border-blue-100/60 overflow-hidden">
              {/* Example label */}
              <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center gap-2">
                <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Example Result — Not Live Data</span>
              </div>
              <div className="bg-gradient-to-r from-[#0b1f4f] to-[#1a56db] text-white p-5">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="text-[11px] text-blue-200 mb-1">12301 • Howrah Rajdhani Express</div>
                    <div className="font-bold text-base">PNR: 4521876543</div>
                  </div>
                  <div className="text-right">
                    <div className="text-blue-200 text-[11px]">Journey Date</div>
                    <div className="font-semibold text-sm">15 Apr 2026</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-center">
                    <div className="text-xl font-bold tabular-nums">16:55</div>
                    <div className="text-[11px] text-blue-200 font-medium">NDLS</div>
                  </div>
                  <div className="flex-1 flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                    <div className="flex-1 border-t border-dashed border-white/25" />
                    <Train size={12} className="text-white/60" />
                    <div className="flex-1 border-t border-dashed border-white/25" />
                    <div className="w-1.5 h-1.5 rounded-full bg-white/50" />
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold tabular-nums">10:05</div>
                    <div className="text-[11px] text-blue-200 font-medium">HWH</div>
                  </div>
                </div>
              </div>
              <div className="divide-y divide-slate-50">
                {[
                  { name: 'Passenger 1', age: '32 / M', current: 'CNF', coach: 'A1 · 23 (LB)', color: 'bg-emerald-100 text-emerald-700' },
                  { name: 'Passenger 2', age: '28 / F', current: 'CNF', coach: 'A1 · 24 (UB)', color: 'bg-emerald-100 text-emerald-700' },
                  { name: 'Passenger 3', age: '8 / M',  current: 'WL/8', coach: '—',           color: 'bg-red-100 text-red-600'         },
                ].map((p) => (
                  <div key={p.name} className="px-5 py-3.5 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold text-slate-800">{p.name}</div>
                      <div className="text-xs text-slate-400">{p.age}</div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-xs text-slate-400 hidden sm:block font-mono">{p.coach}</div>
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-lg ${p.color}`}>{p.current}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Mid Ad ── */}
      <section className="py-3 bg-white">
        <div className="container mx-auto px-4 flex justify-center">
          <AdBanner slot="homepage-mid-rectangle" size="rectangle" />
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* FEATURED: TRAIN BETWEEN STATIONS                                      */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-white" id="train-between-stations">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center"
          >
            {/* Left: Sample Train Card — clearly labelled as example */}
            <motion.div variants={fadeUp} className="bg-white rounded-2xl shadow-[0_8px_40px_hsl(221_79%_48%/0.10)] border border-slate-100 overflow-hidden order-2 lg:order-1">
              {/* Example label */}
              <div className="bg-amber-50 border-b border-amber-200 px-4 py-2">
                <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">Example Result — Not Live Data</span>
              </div>
              <div className="bg-gradient-to-r from-sky-800 to-sky-600 text-white p-5">
                <div className="flex items-center gap-3 mb-1">
                  <div className="flex-1">
                    <div className="text-[11px] text-sky-200 mb-0.5">From</div>
                    <div className="font-bold text-base">New Delhi (NDLS)</div>
                  </div>
                  <ArrowLeftRight size={16} className="text-sky-300 shrink-0" />
                  <div className="flex-1 text-right">
                    <div className="text-[11px] text-sky-200 mb-0.5">To</div>
                    <div className="font-bold text-base">Mumbai CST (CSTM)</div>
                  </div>
                </div>
                <div className="text-[11px] text-sky-200 mt-2">Showing 3 of 18 trains · Thu, 10 Apr</div>
              </div>
              <div className="divide-y divide-slate-50">
                {[
                  { no: '12951', name: 'Mumbai Rajdhani',  dep: '16:25', arr: '08:15', dur: '15h 50m', classes: ['1A','2A','3A'], avail: 'AVAILABLE' },
                  { no: '12909', name: 'Garib Rath Exp',   dep: '15:35', arr: '09:25', dur: '17h 50m', classes: ['3A','SL'],      avail: 'RAC 12'    },
                  { no: '12137', name: 'Punjab Mail',       dep: '19:30', arr: '13:45', dur: '18h 15m', classes: ['2A','3A','SL'], avail: 'WL 24'     },
                ].map((t) => (
                  <div key={t.no} className="px-5 py-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-[11px] text-slate-400 font-mono">{t.no}</div>
                        <div className="text-sm font-bold text-slate-800">{t.name}</div>
                        <div className="flex gap-1 mt-1.5">
                          {t.classes.map((c) => (
                            <span key={c} className="text-[11px] bg-blue-50 text-primary font-bold px-1.5 py-0.5 rounded-md">{c}</span>
                          ))}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-sm font-bold text-slate-800 tabular-nums">{t.dep} → {t.arr}</div>
                        <div className="text-xs text-slate-400">{t.dur}</div>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-lg mt-1.5 inline-block ${
                          t.avail === 'AVAILABLE' ? 'bg-emerald-100 text-emerald-700' :
                          t.avail.startsWith('RAC') ? 'bg-amber-100 text-amber-700' :
                          'bg-red-100 text-red-600'
                        }`}>{t.avail}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Right: Content */}
            <motion.div variants={fadeUp} className="order-1 lg:order-2">
              <div className="inline-flex items-center gap-1.5 bg-sky-100 text-sky-700 text-[11px] font-bold px-3 py-1 rounded-full mb-4 uppercase tracking-wider">
                <MapPin size={10} /> Route Planner
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-3 leading-tight">
                Find Trains Between<br />
                <span className="text-sky-600">Any Two Stations</span>
              </h2>
              <p className="text-slate-600 text-base leading-relaxed mb-5">
                Search all trains running between your source and destination on any date. Compare timings, classes, availability and fares — all in one view.
              </p>
              <ul className="space-y-2.5 mb-6">
                {[
                  'All trains on your route with timings',
                  'Class-wise seat availability (CNF / RAC / WL)',
                  'General & Tatkal quota options',
                  'Filter by train type and departure time',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2.5 text-slate-700 text-sm">
                    <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/train-search"
                className="inline-flex items-center gap-2 px-6 py-3 bg-sky-600 text-white font-bold rounded-xl text-sm shadow-[0_4px_14px_hsl(199_89%_48%/0.35)] hover:bg-sky-700 hover:shadow-[0_6px_20px_hsl(199_89%_48%/0.45)] hover:-translate-y-0.5 transition-all"
              >
                <ArrowLeftRight size={16} /> Search Trains Now
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* ALL TOOLS GRID                                                         */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center mb-10">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-[11px] font-bold px-3 py-1 rounded-full mb-3 uppercase tracking-wider">
              <Sparkles size={10} /> All Tools Free
            </div>
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-2">Six Powerful Railway Tools</h2>
            <p className="text-slate-500 text-sm max-w-md mx-auto">Everything you need for a stress-free train journey — no login required.</p>
          </motion.div>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {tools.map((tool) => {
              const Icon = tool.icon;
              return (
                <motion.div key={tool.title} variants={fadeUp}>
                  <Link to={tool.href}
                    className={`group relative flex flex-col p-5 bg-white rounded-2xl border border-slate-100 shadow-sm transition-all duration-300 ${tool.border} ${tool.glow} hover:-translate-y-1`}
                  >
                    {tool.popular && (
                      <span className="absolute top-4 right-4 text-[10px] font-bold bg-accent/10 text-accent px-2 py-0.5 rounded-full uppercase tracking-wider">Popular</span>
                    )}
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center mb-4 ${tool.accent}`}>
                      <Icon size={20} />
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-1.5">{tool.title}</h3>
                    <p className="text-slate-500 text-sm leading-relaxed flex-1">{tool.description}</p>
                    <div className="flex items-center gap-1 mt-4 text-primary text-sm font-semibold group-hover:gap-2 transition-all">
                      Check Now <ChevronRight size={14} />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* ── Between-sections Ad ── */}
      <section className="py-3 bg-background">
        <div className="container mx-auto px-4">
          <AdBanner slot="homepage-between-sections" size="banner" />
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* WHY CHALOTRAIN                                                         */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-white">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 mb-2">Why ChaloTrain?</h2>
            <p className="text-slate-500 text-sm">Built for the modern Indian traveler.</p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-1 md:grid-cols-3 gap-5"
          >
            {benefits.map((b) => {
              const Icon = b.icon;
              return (
                <motion.div key={b.title} variants={fadeUp}
                  className={`bg-gradient-to-br ${b.gradient} rounded-2xl p-7 text-white relative overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                  <div className="relative">
                    <div className="w-11 h-11 rounded-xl bg-white/15 flex items-center justify-center mb-5">
                      <Icon size={21} className="text-white" />
                    </div>
                    <h3 className="text-lg font-bold mb-2">{b.title}</h3>
                    <p className="text-white/75 text-sm leading-relaxed">{b.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* POPULAR ROUTES                                                         */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mb-7">
            <div className="flex items-center gap-2 mb-1.5">
              <TrendingUp size={16} className="text-primary" />
              <h2 className="text-xl md:text-2xl font-bold text-slate-900">Popular Train Routes</h2>
            </div>
            <p className="text-slate-500 text-sm">Frequently searched routes — click to find trains.</p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-2 md:grid-cols-4 gap-2.5"
          >
            {popularRoutes.map((route) => (
              <motion.div key={`${route.from}-${route.to}`} variants={fadeUp}>
                <Link to="/train-search"
                  className="flex items-center gap-2 p-3.5 bg-white rounded-xl border border-slate-100 hover:border-primary/30 hover:shadow-[0_4px_16px_hsl(221_79%_48%/0.10)] transition-all group text-sm"
                >
                  <span className="font-semibold text-slate-700 group-hover:text-primary transition-colors text-sm">{route.from}</span>
                  <ArrowRight size={12} className="text-slate-300 shrink-0 group-hover:text-primary/50 transition-colors" />
                  <span className="font-semibold text-slate-700 group-hover:text-primary transition-colors text-sm">{route.to}</span>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* INSTAGRAM                                                              */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
            <motion.div variants={fadeUp} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-7">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)' }}>
                    <svg viewBox="0 0 24 24" fill="white" className="w-3.5 h-3.5"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" /></svg>
                  </div>
                  <span className="text-xs font-bold text-slate-400">@chalotrainofficial</span>
                </div>
                <h2 className="text-xl md:text-2xl font-bold text-slate-900">Follow Us on Instagram</h2>
                <p className="text-slate-500 text-sm mt-0.5">Railway tips, travel hacks & journey guides.</p>
              </div>
              <a href="https://instagram.com/chalotrainofficial" target="_blank" rel="noopener noreferrer"
                className="shrink-0 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-white text-sm font-bold transition-all hover:opacity-90"
                style={{ background: 'linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888)' }}
              >
                <svg viewBox="0 0 24 24" fill="white" className="w-3.5 h-3.5" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" /></svg>
                Follow on Instagram
              </a>
            </motion.div>

            {/* Branded railway tip cards — not fake Instagram posts */}
            <motion.div variants={stagger} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
              {[
                { bg: 'from-blue-600 to-blue-800',     icon: '🚂', tip: 'PNR Tip',          text: 'Check PNR 4–6 hrs before departure for final coach & berth details.' },
                { bg: 'from-orange-500 to-red-600',    icon: '🎫', tip: 'Tatkal Booking',   text: 'AC Tatkal opens at 10 AM, Non-AC at 11 AM — one day before journey.' },
                { bg: 'from-green-600 to-teal-700',    icon: '📍', tip: 'Live Tracking',    text: 'Use train number for live status. Works best for express & mail trains.' },
                { bg: 'from-violet-600 to-purple-800', icon: '💺', tip: 'Seat Classes',     text: '1A, 2A, 3A, SL, CC, 2S — know your class before booking.' },
                { bg: 'from-sky-500 to-blue-700',      icon: '🗺️', tip: 'Route Planning',  text: 'Search trains between stations to compare timings and availability.' },
                { bg: 'from-amber-500 to-orange-600',  icon: '💰', tip: 'Fare Comparison',  text: 'Compare fares across classes and quotas before booking your ticket.' },
              ].map((card, i) => (
                <motion.a key={i} href="https://instagram.com/chalotrainofficial" target="_blank" rel="noopener noreferrer"
                  variants={fadeUp}
                  aria-label={`Railway tip: ${card.tip}`}
                  className={`group relative aspect-square rounded-2xl bg-gradient-to-br ${card.bg} overflow-hidden cursor-pointer`}
                >
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-3 text-center">
                    <span className="text-2xl mb-1.5" aria-hidden="true">{card.icon}</span>
                    <p className="text-white text-[10px] font-bold leading-tight mb-1">{card.tip}</p>
                    <p className="text-white/75 text-[9px] leading-tight hidden sm:block">{card.text}</p>
                  </div>
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-3 text-center">
                    <p className="text-white text-[10px] font-medium leading-tight">{card.text}</p>
                    <span className="text-white/60 text-[9px] mt-2">Follow for more tips</span>
                  </div>
                </motion.a>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* BLOG                                                                   */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="flex items-end justify-between mb-7">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary/10 text-primary text-[11px] font-bold rounded-full mb-2">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3"><path d="M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" /></svg>
                BLOG
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-slate-900">Railway Travel Tips & Guides</h2>
              <p className="text-slate-500 text-sm mt-0.5">Expert advice for smarter train journeys.</p>
            </div>
            <Link to="/blog" className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline shrink-0">
              View All <ChevronRight size={14} />
            </Link>
          </motion.div>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5"
          >
            {[
              { title: 'How to Check PNR Status Online',   excerpt: 'Complete guide to checking your PNR status, understanding booking codes, and tracking your train ticket confirmation.', slug: 'how-to-check-pnr-status-online',    date: 'Apr 10, 2026', readTime: '5 min', tag: 'PNR Guide'      },
              { title: 'Tatkal Ticket Booking Tips',        excerpt: 'Master the art of Tatkal booking with proven strategies, timing tricks, and payment tips for confirmed tickets.',          slug: 'tatkal-ticket-booking-tips',        date: 'Apr 8, 2026',  readTime: '7 min', tag: 'Booking Tips'   },
              { title: 'IRCTC Booking Guide for Beginners', excerpt: 'Step-by-step tutorial for first-time users: account creation, ticket booking, payment, and cancellation process.',        slug: 'irctc-booking-guide-for-beginners', date: 'Mar 28, 2026', readTime: '8 min', tag: 'Beginner Guide' },
            ].map((article) => (
              <motion.div key={article.slug} variants={fadeUp}>
                <Link to={`/blog/${article.slug}`}
                  className="block bg-white rounded-2xl border border-slate-100 overflow-hidden hover:shadow-[0_8px_32px_hsl(221_79%_48%/0.10)] hover:border-primary/20 transition-all group h-full"
                >
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="px-2.5 py-0.5 bg-primary/10 text-primary text-[11px] font-bold rounded-full">{article.tag}</span>
                      <span className="text-[11px] text-slate-400">{article.date}</span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mb-2 group-hover:text-primary transition-colors leading-snug">
                      {article.title}
                    </h3>
                    <p className="text-sm text-slate-500 leading-relaxed mb-4 line-clamp-2">{article.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400 flex items-center gap-1">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-3 h-3"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>
                        {article.readTime} read
                      </span>
                      <span className="text-primary text-xs font-semibold inline-flex items-center gap-0.5 group-hover:gap-1.5 transition-all">
                        Read More <ChevronRight size={12} />
                      </span>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>

          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center sm:hidden">
            <Link to="/blog" className="inline-flex items-center gap-1.5 px-5 py-2.5 text-white font-bold rounded-xl btn-premium text-sm">
              View All Articles <ChevronRight size={14} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* CTA BANNER                                                             */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-white">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}
            className="relative overflow-hidden rounded-2xl hero-gradient text-white"
          >
            <div className="absolute inset-0 dot-pattern" />
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full translate-x-1/3 -translate-y-1/3" />
            <div className="relative flex flex-col md:flex-row items-center justify-between gap-6 p-8 md:p-12">
              <div className="text-center md:text-left">
                <h2 className="text-2xl md:text-3xl font-bold mb-2">Plan Your Journey Today</h2>
                <p className="text-blue-200/80 text-sm max-w-md">Plan your journey with ChaloTrain — live railway information, free for everyone.</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 shrink-0">
                <Link to="/pnr-status" className="px-6 py-3 bg-white text-primary font-bold rounded-xl hover:bg-blue-50 transition-all text-sm text-center shadow-lg hover:-translate-y-0.5">
                  Check PNR Status
                </Link>
                <Link to="/train-search" className="px-6 py-3 bg-white/15 text-white font-bold rounded-xl border border-white/25 hover:bg-white/25 transition-all text-sm text-center hover:-translate-y-0.5">
                  Find Trains
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* SEO CONTENT                                                            */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-background">
        <div className="container mx-auto px-4 max-w-4xl">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="space-y-8">
            {[
              {
                title: 'Check PNR Status Online — Fast & Free',
                color: 'text-primary',
                href: '/pnr-status',
                linkLabel: 'Check PNR Status',
                body: 'Your PNR (Passenger Name Record) is a unique 10-digit number printed on every Indian Railways ticket. ChaloTrain lets you check your PNR status instantly — whether your booking is Confirmed (CNF), on the Reservation Against Cancellation (RAC) list, or on the Waitlist (WL). You can also see your coach number, berth number, and chart preparation status.',
              },
              {
                title: 'Find Trains Between Stations',
                color: 'text-sky-600',
                href: '/train-search',
                linkLabel: 'Search Trains Between Stations',
                body: 'Planning a trip? Use ChaloTrain\'s Train Between Stations tool to find all trains running between your source and destination on any date. Compare departure and arrival times, journey duration, available classes (1A, 2A, 3A, SL, CC), and seat availability across all routes in India.',
              },
              {
                title: 'Live Train Running Status',
                color: 'text-indigo-600',
                href: '/live-status',
                linkLabel: 'Track Live Train Status',
                body: 'Track your train live with ChaloTrain\'s Live Train Status feature. Know exactly where your train is, how many minutes it\'s running late, and the expected arrival time at each station. Enter the train number or name to get the latest running status sourced from NTES.',
              },
            ].map((item) => (
              <motion.div key={item.title} variants={fadeUp}>
                <h2 className="text-xl font-bold text-slate-900 mb-2">{item.title}</h2>
                <p className="text-slate-600 leading-relaxed text-sm">{item.body}</p>
                <div className="mt-3">
                  <Link to={item.href} className={`${item.color} font-semibold text-sm hover:underline inline-flex items-center gap-1`}>
                    {item.linkLabel} <ChevronRight size={13} />
                  </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* FAQ                                                                    */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-14 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center mb-8">
            <h2 className="text-xl md:text-2xl font-bold text-slate-900 mb-1.5">Frequently Asked Questions</h2>
            <p className="text-slate-500 text-sm">Everything you need to know about Indian Railways and ChaloTrain</p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="space-y-2">
            {[
              { q: 'How do I check my PNR status?',                  a: 'Enter your 10-digit PNR number on ChaloTrain\'s PNR Status page and click "Check PNR Status". You\'ll instantly see your booking status (CNF/RAC/WL), coach number, berth number, and passenger details. No login required.' },
              { q: 'What does CNF, RAC, and WL mean?',               a: 'CNF means your ticket is Confirmed with a berth assigned. RAC (Reservation Against Cancellation) means you can board but share a side-lower berth — you may get a full berth if someone cancels. WL (Waitlist) means you\'re on the waiting list. For e-tickets, WL tickets are auto-cancelled with a full refund if not confirmed by chart preparation.' },
              { q: 'How can I track my train live?',                  a: 'Use ChaloTrain\'s Live Train Status tool. Enter your train number and journey date to see live running status — current location, delay in minutes, and expected arrival time at every station. Data is sourced from the National Train Enquiry System (NTES).' },
              { q: 'How do I find trains between two stations?',      a: 'Use ChaloTrain\'s Train Search tool. Enter your source station code (e.g., NDLS for New Delhi), destination station code (e.g., BCT for Mumbai Central), and journey date. You\'ll see all trains on that route with timings, duration, available classes, and seat availability.' },
              { q: 'When does Tatkal booking open?',                  a: 'Tatkal booking opens 1 day before the journey date. For AC classes (1A, 2A, 3A, CC, EC), it opens at 10:00 AM. For non-AC classes (SL, 2S), it opens at 11:00 AM. Tatkal seats fill up within minutes, so be ready before the opening time.' },
              { q: 'How do I check seat availability for a train?',   a: 'Use ChaloTrain\'s Seat Availability tool. Enter the train number, source and destination station codes, travel class, quota, and date. You\'ll see a date-wise grid showing availability (AVL = available, RAC = partial, WL = waitlist) for the next 7 days.' },
              { q: 'Is ChaloTrain affiliated with IRCTC or Indian Railways?', a: 'No. ChaloTrain is an independent railway information portal and is not affiliated with IRCTC or Indian Railways. We provide railway information for general reference purposes. For booking tickets, please use the official IRCTC website or authorized booking agents.' },
              { q: 'How do I check train fare?',                      a: 'Use ChaloTrain\'s Fare Inquiry tool. Enter the train number, source and destination stations, travel class, and quota to see the exact fare including base fare, reservation charge, superfast charge, and applicable taxes.' },
            ].map((item, i) => (
              <motion.details key={i} variants={fadeUp} className="group bg-background border border-slate-100 rounded-xl overflow-hidden">
                <summary className="flex items-center justify-between gap-3 px-5 py-4 cursor-pointer list-none font-semibold text-slate-800 text-sm hover:text-primary transition-colors">
                  {item.q}
                  <ChevronRight size={14} className="flex-shrink-0 text-slate-400 group-open:rotate-90 transition-transform duration-200" />
                </summary>
                <div className="px-5 pb-4 text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                  {item.a}
                </div>
              </motion.details>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ══════════════════════════════════════════════════════════════════════ */}
      {/* TRAIN CLASSES                                                          */}
      {/* ══════════════════════════════════════════════════════════════════════ */}
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center mb-6">
            <h2 className="text-xl font-bold text-slate-900 mb-1">All Train Classes Covered</h2>
            <p className="text-slate-500 text-sm">Check PNR status, availability and fares for every class.</p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
            className="flex flex-wrap justify-center gap-2"
          >
            {trainClasses.map((cls) => (
              <motion.div key={cls.code} variants={fadeUp}>
                <Link to="/seat-availability"
                  className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-100 rounded-xl hover:border-primary/30 hover:shadow-[0_4px_12px_hsl(221_79%_48%/0.10)] transition-all group"
                >
                  <span className="text-xs font-bold text-primary bg-blue-50 px-1.5 py-0.5 rounded-lg">{cls.code}</span>
                  <span className="text-sm text-slate-600 group-hover:text-slate-800 transition-colors">{cls.name}</span>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Footer Ad ── */}
      <section className="py-3 bg-background">
        <div className="container mx-auto px-4">
          <AdBanner slot="homepage-footer-leaderboard" size="leaderboard" className="mx-auto" />
        </div>
      </section>
    </>
  );
}
