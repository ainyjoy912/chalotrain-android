import { motion } from 'motion/react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { ShieldCheck } from 'lucide-react';
import PageHero from '@/components/PageHero';
import { Link } from 'react-router-dom';

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="mb-8">
    <h2
      className="text-lg font-bold text-slate-900 mb-3 pb-2 border-b border-slate-200"
      style={{ fontFamily: 'var(--font-heading)' }}
    >
      {title}
    </h2>
    <div className="text-sm text-slate-600 leading-relaxed space-y-3">{children}</div>
  </div>
);

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

export default function PrivacyPage() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy — ChaloTrain</title>
        <meta name="description" content="Read ChaloTrain's Privacy Policy. Learn how we collect, use, protect, and share your personal information when you use our railway information services." />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Privacy Policy — ChaloTrain" />
        <meta property="og:description" content="Read ChaloTrain's Privacy Policy. Learn how we collect, use, protect, and share your personal information when you use our railway information services." />
        <meta property="og:url" content="https://chalotrain.com/privacy" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Privacy Policy — ChaloTrain" />
        <meta name="twitter:description" content="Read ChaloTrain's Privacy Policy. Learn how we collect, use, protect, and share your personal information." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/privacy" />
      </Helmet>

      <PageHero
        icon={ShieldCheck}
        title="Privacy Policy"
        subtitle="How we collect, use, and protect your information."
        badge="Last updated: May 2026"
      />
      <h1 className="sr-only">Privacy Policy — ChaloTrain</h1>

      <section className="py-12 bg-slate-50 min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.div initial="hidden" animate="visible" variants={fadeUp}
            className="bg-white rounded-2xl border border-slate-200 p-8">

            <p className="text-sm text-slate-600 leading-relaxed mb-8 bg-blue-50 border border-blue-200 rounded-xl p-4">
              This Privacy Policy describes how ChaloTrain ("we", "us", or "our") collects, uses, and shares information about you when you use our website at <strong>chalotrain.com</strong>. By using ChaloTrain, you agree to the collection and use of information in accordance with this policy.
            </p>

            <Section title="1. Information We Collect">
              <p><strong>Information you provide:</strong> ChaloTrain does not require you to create an account or provide personal information to use our railway information tools. When you use our tools (PNR Status, Live Train Status, Train Search, etc.), you provide train numbers, PNR numbers, and station codes — none of which are personally identifiable information.</p>
              <p><strong>Contact information:</strong> If you contact us via our Contact page or email, we collect your name and email address to respond to your inquiry.</p>
              <p><strong>Automatically collected information:</strong> When you visit ChaloTrain, we automatically collect certain information about your device and usage, including your IP address, browser type, operating system, referring URLs, pages visited, and time spent on pages. This information is collected through cookies and similar tracking technologies.</p>
            </Section>

            <Section title="2. How We Use Your Information">
              <p>We use the information we collect to:</p>
              <ul className="list-disc list-inside space-y-1 pl-2">
                <li>Provide, maintain, and improve our railway information services</li>
                <li>Respond to your comments, questions, and requests</li>
                <li>Monitor and analyze usage patterns to improve user experience</li>
                <li>Detect and prevent fraudulent or abusive use of our services</li>
                <li>Comply with legal obligations</li>
                <li>Send you technical notices and support messages (if you have contacted us)</li>
              </ul>
            </Section>

            <Section title="3. Cookies and Tracking Technologies">
              <p>ChaloTrain uses cookies and similar tracking technologies to enhance your experience. Cookies are small data files stored on your device. We use:</p>
              <ul className="list-disc list-inside space-y-1 pl-2">
                <li><strong>Essential cookies:</strong> Required for the website to function properly</li>
                <li><strong>Analytics cookies:</strong> May be used to help us understand how visitors interact with our website</li>
                <li><strong>Advertising cookies:</strong> May be used by third-party advertising networks to display relevant advertisements</li>
              </ul>
              <p>You can control cookies through your browser settings. Disabling cookies may affect the functionality of some features.</p>
            </Section>

            <Section title="4. Advertising">
              <p>ChaloTrain may display advertisements from third-party advertising networks. These networks may use cookies to serve ads based on your prior visits to our website and other websites. You may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" target="_blank" rel="noopener noreferrer" className="text-primary underline">Google Ads Settings</a> or <a href="https://www.aboutads.info" target="_blank" rel="noopener noreferrer" className="text-primary underline">aboutads.info</a>.</p>
            </Section>

            <Section title="5. Analytics">
              <p>We may use analytics tools to analyze website traffic and usage patterns. These tools may collect information such as how often users visit our site and what pages they visit. We use this information to improve our services. Any analytics data is not combined with personally identifiable information.</p>
            </Section>

            <Section title="6. Information Sharing and Disclosure">
              <p>We do not sell, trade, or rent your personal information to third parties. We may share information in the following circumstances:</p>
              <ul className="list-disc list-inside space-y-1 pl-2">
                <li><strong>Service providers:</strong> We may share information with third-party vendors who assist us in operating our website (hosting, analytics, advertising)</li>
                <li><strong>Legal requirements:</strong> We may disclose information if required by law or in response to valid legal process</li>
                <li><strong>Protection of rights:</strong> We may disclose information to protect the rights, property, or safety of ChaloTrain, our users, or others</li>
              </ul>
            </Section>

            <Section title="7. Data Security">
              <p>We implement appropriate technical and organizational measures to protect your information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.</p>
              <p>ChaloTrain does not store PNR numbers, train numbers, or search queries entered by users beyond the immediate session required to process your request.</p>
            </Section>

            <Section title="8. Third-Party Links">
              <p>Our website may contain links to third-party websites, including IRCTC and other railway-related services. We are not responsible for the privacy practices of these external sites. We encourage you to review the privacy policies of any third-party sites you visit.</p>
            </Section>

            <Section title="9. Children's Privacy">
              <p>ChaloTrain is not directed to children under the age of 13. We do not knowingly collect personal information from children under 13. If you believe we have inadvertently collected information from a child under 13, please contact us immediately and we will take steps to delete such information.</p>
            </Section>

            <Section title="10. Your Rights">
              <p>Depending on your location, you may have certain rights regarding your personal information, including:</p>
              <ul className="list-disc list-inside space-y-1 pl-2">
                <li>The right to access information we hold about you</li>
                <li>The right to request correction of inaccurate information</li>
                <li>The right to request deletion of your information</li>
                <li>The right to opt out of certain data processing activities</li>
              </ul>
              <p>To exercise these rights, please contact us at the address provided in the Contact section below.</p>
            </Section>

            <Section title="11. Changes to This Privacy Policy">
              <p>We may update this Privacy Policy from time to time. We will notify you of any significant changes by posting the new policy on this page with an updated "Last updated" date. We encourage you to review this Privacy Policy periodically.</p>
            </Section>

            <Section title="12. Legal Information">
              <p>ChaloTrain is operated by a registered Indian company. Our statutory details are as follows:</p>
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 mt-2">
                <p className="text-xs font-bold text-slate-700 mb-3">ChaloTrain Technologies Private Limited</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { label: 'CIN', value: 'U62099UP2026PTC246981' },
                    { label: 'PAN', value: 'AANCC7761J' },
                    { label: 'TAN', value: 'KNPC02496E' },
                  ].map(({ label, value }) => (
                    <div key={label} className="bg-white rounded-lg border border-slate-200 px-3 py-2">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">{label}</p>
                      <p className="text-xs font-mono font-semibold text-slate-800 tracking-wide">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Section>

            <Section title="13. Contact Us">
              <p>If you have any questions about this Privacy Policy or our privacy practices, please contact us:</p>
              <ul className="list-none space-y-2 pl-2">
                <li><strong>Website:</strong> <Link to="/contact" className="text-primary underline">chalotrain.com/contact</Link></li>
                <li><strong>Email:</strong> chalotrain@chalotrain.com</li>
              </ul>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <p className="text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Registered Office</p>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ChaloTrain Technologies Private Limited<br />
                    C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                    Ragaul Tahsil, Hamirpur,<br />
                    Uttar Pradesh — 210507, India
                  </p>
                </div>
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <p className="text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Registered Office</p>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ChaloTrain Technologies Private Limited<br />
                    C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                    Ragaul Tahsil, Hamirpur,<br />
                    Uttar Pradesh — 210507, India
                  </p>
                </div>
              </div>
            </Section>

          </motion.div>
        </div>
      </section>
    </>
  );
}
