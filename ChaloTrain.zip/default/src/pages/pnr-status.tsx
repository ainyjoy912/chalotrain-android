import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { Ticket, Search, Train, User, MapPin, Calendar } from 'lucide-react';
import PageHero from '@/components/PageHero';
import StatusBadge from '@/components/StatusBadge';
import AdBanner from '@/components/AdBanner';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection, { type FAQItem } from '@/components/FAQSection';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorMessage from '@/components/ErrorMessage';
import { checkPNRStatus, validatePNR, type PNRStatusResponse } from '@/lib/api-client';

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
};

// ── FAQ ───────────────────────────────────────────────────────────────────────
const FAQ_ITEMS: FAQItem[] = [
  { question: 'What is a PNR number?', answer: 'PNR stands for Passenger Name Record. It is a unique 10-digit number assigned to every Indian Railways ticket booking. You can find it on your ticket or IRCTC booking confirmation email.' },
  { question: 'What does CNF, RAC, and WL mean?', answer: 'CNF (Confirmed) means your seat is confirmed. RAC (Reservation Against Cancellation) means you share a berth and may get a full berth if someone cancels. WL (Waitlist) means you are on the waiting list.' },
  { question: 'When is the chart prepared?', answer: 'The chart is usually prepared 4 hours before train departure. After chart preparation, your final coach and berth number are assigned. RAC and WL passengers know their final status only after chart preparation.' },
  { question: 'Can I check PNR status without the IRCTC app?', answer: 'Yes! ChaloTrain lets you check PNR status instantly without logging in or downloading any app. Just enter your PNR number and get results in seconds.' },
  { question: 'How often is PNR status updated?', answer: 'PNR status is updated regularly by Indian Railways. Once the chart is prepared, the status is final. Before chart preparation, status can change as passengers cancel their tickets.' },
];

export default function PNRStatusPage() {
  const [pnr, setPnr] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PNRStatusResponse | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset states
    setError(null);
    setValidationError(null);
    setResult(null);

    // Validate PNR
    const validation = validatePNR(pnr.trim());
    if (!validation.valid) {
      setValidationError(validation.error || 'Invalid PNR');
      return;
    }

    // Call API
    setLoading(true);
    try {
      const data = await checkPNRStatus(pnr.trim());
      setResult(data);
    } catch (err) {
      const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();

      if (msg.includes('rate limit') || msg.includes('too many') || msg.includes('429') || msg.includes('quota') || msg.includes('upgrade')) {
        setError('PNR service has reached its monthly request limit. Please try again tomorrow or contact support.');
      } else if (msg.includes('network error') || msg.includes('could not reach') || msg.includes('failed to fetch')) {
        setError('Unable to connect to railway data service. Please check your internet connection and try again.');
      } else if (msg.includes('not yet configured') || msg.includes('not configured')) {
        setError('PNR Status service is currently being set up. Please try again shortly.');
      } else if (
        msg.includes('pnr not found') ||
        msg.includes('not found') ||
        msg.includes('invalid pnr') ||
        msg.includes('no data') ||
        msg.includes('pnr number not found') ||
        msg.includes('flushed') ||
        msg.includes('not yet generated')
      ) {
        // Show the actual API message for flushed/expired PNRs so users understand why
        const isFlushed = msg.includes('flushed') || msg.includes('not yet generated');
        setError(
          isFlushed
            ? 'This PNR is no longer active. It may have been flushed after journey completion or not yet generated. Please check the PNR number and try again.'
            : 'PNR number not found. Please check your 10-digit PNR and try again.'
        );
      } else {
        // Surface the actual message in dev so it's easy to diagnose;
        // in production fall back to a friendly generic message.
        setError(
          import.meta.env.DEV
            ? `Error: ${err instanceof Error ? err.message : String(err)}`
            : 'PNR service temporarily unavailable. Please try again later.'
        );
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    setError(null);
    if (!pnr.trim()) return;
    setLoading(true);
    checkPNRStatus(pnr.trim())
      .then(setResult)
      .catch((err) => {
        const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
        if (
          msg.includes('not found') || msg.includes('invalid pnr') ||
          msg.includes('no data') || msg.includes('flushed') || msg.includes('not yet generated')
        ) {
          const isFlushed = msg.includes('flushed') || msg.includes('not yet generated');
          setError(
            isFlushed
              ? 'This PNR is no longer active. It may have been flushed after journey completion or not yet generated.'
              : 'PNR number not found. Please check your 10-digit PNR and try again.'
          );
        } else {
          setError('PNR service temporarily unavailable. Please try again later.');
        }
      })
      .finally(() => setLoading(false));
  };

  return (
    <>
      <Helmet>
        <title>PNR Status Check — Live CNF, RAC & WL Status | ChaloTrain</title>
        <meta name="description" content="Check your PNR status instantly. Get up-to-date CNF, RAC, WL updates with coach number, berth details and passenger-wise status for Indian Railways tickets. No login required." />
        <meta name="keywords" content="PNR status, check PNR status, IRCTC PNR status, train ticket status, CNF RAC WL, PNR number check, Indian Railways PNR" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="PNR Status Check — Live CNF, RAC & WL Status | ChaloTrain" />
        <meta property="og:description" content="Check your PNR status instantly. Get up-to-date CNF, RAC, WL updates with coach number, berth details and passenger-wise status for Indian Railways tickets." />
        <meta property="og:url" content="https://chalotrain.com/pnr-status" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="PNR Status Check — Live CNF, RAC & WL Status | ChaloTrain" />
        <meta name="twitter:description" content="Check your PNR status instantly. Get up-to-date CNF, RAC, WL updates with coach number, berth details and passenger-wise status." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/pnr-status" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'PNR Status Checker — ChaloTrain',
          url: 'https://chalotrain.com/pnr-status',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'All',
          description: 'Check Indian Railways PNR status instantly. Get up-to-date CNF, RAC, WL updates with coach and berth details.',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
          provider: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'PNR Status', item: 'https://chalotrain.com/pnr-status' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        title="PNR Status Check"
        subtitle="Check your train ticket status instantly — CNF, RAC, or WL"
        icon={Ticket}
        badge="Instant Results"
      />
      {/* sr-only h1 for SEO checkers — PageHero renders the visible heading */}
      <h1 className="sr-only">PNR Status Check — CNF, RAC &amp; WL Status for Indian Railways Tickets</h1>

      <section className="py-10 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* SEO Introduction */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-blue-100/60 p-6 mb-6 shadow-[0_2px_12px_hsl(221_79%_48%/0.06)]">
            <h2 className="text-xl font-bold text-slate-900 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              Check PNR Status Online — Instant CNF, RAC & WL Updates
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Wondering if your train ticket is confirmed? Check your PNR status with ChaloTrain! Get up-to-date information on your booking status — whether it's Confirmed (CNF), RAC (Reservation Against Cancellation), or Waitlisted (WL). Know your coach number, berth position, and current booking status in seconds.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Our PNR Status checker provides complete passenger-wise details including names, age, gender, booking status, and current status. Track chart preparation status and see if your waitlisted ticket has been confirmed. No login required — just enter your 10-digit PNR number and get results.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>How to use:</strong> Enter your 10-digit PNR number (found on your train ticket or IRCTC booking confirmation). Click "Check Status" to see complete journey details, passenger information, and current booking status. The status updates automatically as passengers cancel and your position improves.
            </p>
          </motion.div>

          {/* Search Form */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp}>
            <form onSubmit={handleSearch} className="bg-white rounded-2xl border border-blue-100/60 p-6 shadow-[0_4px_20px_hsl(221_79%_48%/0.08)]">
              <div className="flex items-center gap-2 mb-2">
                <Ticket size={18} className="text-primary" aria-hidden="true" />
                <label htmlFor="pnr-input" className="text-sm font-semibold text-slate-700">Enter PNR Number</label>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  id="pnr-input"
                  type="text"
                  value={pnr}
                  onChange={(e) => {
                    setPnr(e.target.value.replace(/\D/g, '').slice(0, 10));
                    setValidationError(null);
                  }}
                  placeholder="e.g., 4521876543"
                  maxLength={10}
                  inputMode="numeric"
                  autoComplete="off"
                  className={`flex-1 px-4 py-3 border rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px] ${
                    validationError ? 'border-red-300 bg-red-50' : 'border-slate-200'
                  }`}
                />
                <button
                  type="submit"
                  disabled={loading}
                  aria-label="Check PNR Status"
                  className="w-full sm:w-auto px-6 py-3 btn-premium text-white font-semibold rounded-xl flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
                >
                  <Search size={16} aria-hidden="true" />
                  <span>Check Status</span>
                </button>
              </div>
              {validationError && (
                <p className="text-xs text-red-600 mt-2 flex items-center gap-1">
                  <span className="w-1 h-1 rounded-full bg-red-600" />
                  {validationError}
                </p>
              )}
              <p className="text-xs text-slate-400 mt-2">
                Enter the 10-digit PNR number from your train ticket or booking confirmation.
              </p>
            </form>
          </motion.div>

          {/* Ad Banner */}
          <div className="mt-6">
            <AdBanner slot="pnr-top" size="rectangle" className="mx-auto" />
          </div>

          {/* Loading State */}
          <AnimatePresence mode="wait">
            {loading && (
              <motion.div
                key="loading"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={fadeUp}
                className="mt-6"
              >
                <LoadingSpinner message="Fetching PNR status..." />
              </motion.div>
            )}

            {/* Error State */}
            {error && !loading && (
              <motion.div
                key="error"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={fadeUp}
                className="mt-6"
              >
                <ErrorMessage
                  title="Service Unavailable"
                  message={error}
                  onRetry={handleRetry}
                  showHelpText={true}
                />
              </motion.div>
            )}

            {/* Results */}
            {result && !loading && !error && (
              <motion.div
                key="results"
                initial="hidden"
                animate="visible"
                exit="hidden"
                variants={fadeUp}
                className="mt-6 space-y-4"
              >
                {/* Train Journey Card */}
                <div className="bg-white rounded-2xl border border-blue-100/60 p-5 shadow-[0_4px_20px_hsl(221_79%_48%/0.08)]">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Train size={18} className="text-primary" />
                        <h3 className="text-base font-bold text-slate-900">{result.trainName}</h3>
                      </div>
                      <p className="text-sm text-slate-500">Train #{result.trainNumber} • PNR: {result.pnr}</p>
                    </div>
                    <span className={`px-3 py-1.5 rounded-full text-xs font-semibold ${
                      result.chartPrepared 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-amber-100 text-amber-700'
                    }`}>
                      {result.chartPrepared ? 'Chart Prepared' : 'Chart Not Prepared'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-start gap-2">
                      <MapPin size={14} className="text-slate-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-xs text-slate-400">From → To</p>
                        <p className="text-sm font-semibold text-slate-700">{result.from} → {result.to}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <Calendar size={14} className="text-slate-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-xs text-slate-400">Journey Date</p>
                        <p className="text-sm font-semibold text-slate-700">{result.dateOfJourney}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Passengers */}
                <div className="space-y-3">
                  <h4 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <User size={16} className="text-primary" />
                    Passenger Details ({result.passengers.length})
                  </h4>
                  {result.passengers.map((passenger) => (
                    <div key={passenger.passengerNumber} className="bg-white rounded-xl border border-blue-100/60 p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-sm font-semibold text-slate-900">{passenger.name}</p>
                          <p className="text-xs text-slate-500">
                            {passenger.age} yrs • {passenger.gender === 'M' ? 'Male' : passenger.gender === 'F' ? 'Female' : 'Other'}
                          </p>
                        </div>
                        <span className="text-xs font-medium text-slate-400">P{passenger.passengerNumber}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-slate-400 mb-1">Booking Status</p>
                          <StatusBadge status={passenger.bookingStatus} />
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 mb-1">Current Status</p>
                          <StatusBadge status={passenger.currentStatus} />
                        </div>
                      </div>
                      {passenger.coach && passenger.berth && (
                        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-4 text-xs">
                          <span className="text-slate-600">
                            <strong className="text-slate-900">Coach:</strong> {passenger.coach}
                          </span>
                          <span className="text-slate-600">
                            <strong className="text-slate-900">Berth:</strong> {passenger.berth}
                          </span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Ad Banner */}
                <AdBanner slot="pnr-results" size="banner" className="mx-auto" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Related Tools */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <RelatedTools currentHref="/pnr-status" />
          </motion.div>

          {/* Social Share */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <SocialShareBar
              title="Check PNR Status free on ChaloTrain — Instant CNF/RAC/WL results"
              url="https://chalotrain.com/pnr-status"
            />
          </motion.div>

          {/* FAQ */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <FAQSection items={FAQ_ITEMS} />
          </motion.div>

          {/* Learn more */}
          <div className="container mx-auto px-4 pb-2 mt-3">
            <div className="max-w-2xl mx-auto">
              <p className="text-sm text-slate-500">
                Want to learn more?{' '}
                <Link to="/blog/how-to-check-pnr-status-online" className="text-primary hover:underline font-medium">
                  Read our complete guide →
                </Link>
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> This website is not affiliated with IRCTC or Indian Railways and provides railway information for general purposes only. Please verify critical information from official sources.
              </p>
            </div>
          </motion.div>

          {/* Footer ad */}
          <div className="mt-6">
            <AdBanner slot="pnr-footer" size="leaderboard" className="mx-auto" />
          </div>

        </div>
      </section>
    </>
  );
}
