import { motion } from 'motion/react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { AlertTriangle, MapPin } from 'lucide-react';
import PageHero from '@/components/PageHero';
import { Link } from 'react-router-dom';

const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="mb-8">
    <h2
      className="text-lg font-bold text-slate-900 mb-3 pb-2 border-b border-slate-200"
      style={{ fontFamily: 'var(--font-heading)' }}
    >
      {title}
    </h2>
    <div className="text-sm text-slate-600 leading-relaxed space-y-3">{children}</div>
  </div>
);

export default function DisclaimerPage() {
  return (
    <>
      <Helmet>
        <title>Disclaimer — ChaloTrain</title>
        <meta name="description" content="Read ChaloTrain's Disclaimer. ChaloTrain Technologies Private Limited is an independent platform and is not affiliated with IRCTC or Indian Railways." />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Disclaimer — ChaloTrain" />
        <meta property="og:description" content="Read ChaloTrain's Disclaimer. ChaloTrain is an independent platform and is not affiliated with IRCTC or Indian Railways." />
        <meta property="og:url" content="https://chalotrain.com/disclaimer" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Disclaimer — ChaloTrain" />
        <meta name="twitter:description" content="ChaloTrain is an independent railway information platform and is not affiliated with IRCTC or Indian Railways." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/disclaimer" />
      </Helmet>

      <PageHero
        icon={AlertTriangle}
        title="Disclaimer"
        subtitle="Important information about the nature and limitations of ChaloTrain's services."
        badge="Please Read Carefully"
      />
      <h1 className="sr-only">Disclaimer — ChaloTrain</h1>

      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 md:p-10"
          >

            <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-8 text-sm text-red-800">
              <strong>Important:</strong> ChaloTrain is operated by <strong>ChaloTrain Technologies Private Limited</strong>, an independent railway information service. We are <strong>not affiliated with, endorsed by, or connected to IRCTC, Indian Railways, or any government body</strong>.
            </div>

            <Section title="1. No Affiliation with Indian Railways or IRCTC">
              <p>ChaloTrain (chalotrain.com) is owned and operated by <strong>ChaloTrain Technologies Private Limited</strong>, a privately registered company. We are not affiliated with, sponsored by, licensed by, or in any way officially connected to:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Indian Railway Catering and Tourism Corporation (IRCTC)</li>
                <li>Ministry of Railways, Government of India</li>
                <li>National Train Enquiry System (NTES)</li>
                <li>Any zonal railway, railway division, or railway station authority</li>
                <li>Any other government body, public sector undertaking, or statutory authority</li>
              </ul>
              <p>The ChaloTrain name, logo, and branding are proprietary to ChaloTrain Technologies Private Limited. For official railway services, bookings, and authoritative information, please visit <a href="https://www.irctc.co.in" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">www.irctc.co.in</a> or <a href="https://www.indianrailways.gov.in" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">www.indianrailways.gov.in</a>.</p>
            </Section>

            <Section title="2. Information Accuracy and Reliability">
              <p>All data displayed on ChaloTrain — including PNR status, train schedules, live running status, seat availability, platform numbers, and fare information — is sourced from publicly available Indian Railways data feeds and third-party APIs. This data is provided for general informational purposes only.</p>
              <p>While we make every effort to ensure accuracy and timeliness, we <strong>cannot guarantee</strong> that the information is:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Always current, complete, or up-to-date</li>
                <li>Free from errors, omissions, or technical inaccuracies</li>
                <li>Reflective of real-time changes made by Indian Railways</li>
                <li>Suitable for making critical travel decisions without independent verification</li>
              </ul>
              <p>Train schedules, fares, platform numbers, and seat availability are subject to change by Indian Railways at any time without prior notice. <strong>Always verify critical information with official sources before travelling.</strong></p>
            </Section>

            <Section title="3. No Ticket Booking or Financial Services">
              <p>ChaloTrain does <strong>not</strong> sell, process, or facilitate railway ticket bookings, cancellations, or any financial transactions related to railway travel. We are strictly an information aggregation and display service.</p>
              <p>For ticket booking, cancellation, refunds, or any financial transaction, please use the official <a href="https://www.irctc.co.in" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRCTC website</a>, the IRCTC Rail Connect app, or authorized travel agents.</p>
            </Section>

            <Section title="4. Limitation of Liability">
              <p>ChaloTrain Technologies Private Limited, its directors, officers, employees, and agents shall not be held liable for any loss, damage, inconvenience, missed journey, financial loss, or expense of any nature arising from:</p>
              <ul className="list-disc pl-5 space-y-1.5">
                <li>Reliance on information displayed on this platform for travel decisions</li>
                <li>Train delays, cancellations, diversions, or schedule changes by Indian Railways</li>
                <li>Incorrect, outdated, or incomplete PNR status, availability, or fare data</li>
                <li>Temporary or permanent unavailability of any tool or feature on this platform</li>
                <li>Any decisions, bookings, or financial commitments made based on information from this website</li>
                <li>Third-party API failures or data feed interruptions</li>
              </ul>
              <p>Users are strongly advised to verify all information with official Indian Railways or IRCTC sources before making any travel arrangements or financial commitments.</p>
            </Section>

            <Section title="5. Trademarks and Third-Party References">
              <p>All trademarks, logos, service marks, and brand names mentioned on ChaloTrain — including "Indian Railways," "IRCTC," "Rajdhani," "Shatabdi," "Vande Bharat," and related marks — are the registered trademarks and intellectual property of their respective owners. Their mention on this platform is purely for informational purposes and does not imply any affiliation, endorsement, sponsorship, or partnership with ChaloTrain Technologies Private Limited.</p>
            </Section>

            <Section title="6. Advertising and Third-Party Content">
              <p>ChaloTrain may display advertisements from third-party advertising networks. ChaloTrain Technologies Private Limited is not responsible for the content, accuracy, or claims made in any third-party advertisements. The display of advertisements does not constitute an endorsement of the advertised products or services.</p>
            </Section>

            <Section title="7. External Links">
              <p>ChaloTrain may contain links to external websites — including IRCTC, Indian Railways, and other railway-related services — for user convenience. We do not control, endorse, or take responsibility for the content, privacy practices, availability, or terms of service of these external sites. Accessing them is entirely at your own risk.</p>
            </Section>

            <Section title="8. Blog and Editorial Content">
              <p>Articles, guides, and informational content published on the ChaloTrain blog are intended for general informational and educational purposes only. They reflect the understanding of the authors at the time of writing and may not account for subsequent changes in Indian Railways policies, fares, or procedures. Always refer to official sources for the most current information.</p>
            </Section>

            <Section title="9. Changes to This Disclaimer">
              <p>ChaloTrain Technologies Private Limited reserves the right to update or modify this Disclaimer at any time. The most current version will always be available on this page with an updated date. Continued use of ChaloTrain after any changes constitutes your acceptance of the updated Disclaimer.</p>
            </Section>

            <Section title="10. Legal Information">
              <p>ChaloTrain is operated by a registered Indian private limited company. Our statutory registration details are as follows:</p>
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 mt-2">
                <p className="text-xs font-bold text-slate-700 mb-3">ChaloTrain Technologies Private Limited</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { label: 'CIN', value: 'U62099UP2026PTC246981' },
                    { label: 'PAN', value: 'AANCC7761J' },
                    { label: 'TAN', value: 'KNPC02496E' },
                  ].map(({ label, value }) => (
                    <div key={label} className="bg-white rounded-lg border border-slate-200 px-3 py-2">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-0.5">{label}</p>
                      <p className="text-xs font-mono font-semibold text-slate-800 tracking-wide">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Section>

            <Section title="11. Contact & Registered Office">
              <p>If you have questions about this Disclaimer or wish to report inaccurate information, please contact us:</p>
              <p><strong>Email:</strong> <a href="mailto:chalotrain@chalotrain.com" className="text-primary hover:underline">chalotrain@chalotrain.com</a></p>
              <p><strong>Phone:</strong> <a href="tel:+919170477270" className="text-primary hover:underline">+91 91704 77270</a></p>

              <div className="mt-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 max-w-sm">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin size={14} className="text-primary flex-shrink-0" />
                    <p className="text-xs font-bold text-slate-700 uppercase tracking-wide">Registered Office</p>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    ChaloTrain Technologies Private Limited<br />
                    C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya,<br />
                    Ragaul Tahsil, Hamirpur,<br />
                    Uttar Pradesh — 210507, India
                  </p>
                </div>
              </div>
            </Section>

            <div className="pt-4 border-t border-slate-200 flex flex-wrap gap-4 text-sm">
              <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>
              <Link to="/terms" className="text-primary hover:underline">Terms of Service</Link>
              <Link to="/contact" className="text-primary hover:underline">Contact Us</Link>
            </div>

          </motion.div>
        </div>
      </section>
    </>
  );
}
