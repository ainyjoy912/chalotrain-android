import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion, AnimatePresence } from 'motion/react';
import { IndianRupee, Search, Train, ArrowLeftRight, Info } from 'lucide-react';
import PageHero from '@/components/PageHero';
import SocialShareBar from '@/components/SocialShareBar';
import RelatedTools from '@/components/RelatedTools';
import FAQSection, { type FAQItem } from '@/components/FAQSection';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorMessage from '@/components/ErrorMessage';
import { getFareInquiry, validateTrainNumber, validateStationCode, type FareInquiryResponse } from '@/lib/api-client';

const CLASSES = ['1A', '2A', '3A', '3E', 'SL', 'CC', '2S'];

// Display labels → API quota codes
const QUOTA_OPTIONS = [
  { label: 'General',         code: 'GN' },
  { label: 'Tatkal',          code: 'TQ' },
  { label: 'Premium Tatkal',  code: 'PT' },
  { label: 'Senior Citizen',  code: 'SS' },
  { label: 'Ladies',          code: 'LD' },
  { label: 'Divyaang',        code: 'HP' },
];
const CONCESSIONS = ['None', 'Senior Citizen (Male)', 'Senior Citizen (Female)', 'Student', 'Divyaang'];

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
};

// ── FAQ ───────────────────────────────────────────────────────────────────────
const FAQ_ITEMS: FAQItem[] = [
  { question: 'How is train fare calculated in India?', answer: 'Train fare is calculated based on distance traveled, class of travel (1A, 2A, 3A, SL, etc.), train type (Rajdhani, Shatabdi, Express), and quota (General, Tatkal). Additional charges include reservation fees, superfast charges, GST, and catering charges (for premium trains). Senior citizens and other categories get concessions.' },
  { question: 'What is the difference between General and Tatkal fare?', answer: 'General fare is the standard fare for advance booking (up to 120 days). Tatkal fare is higher and applies to last-minute bookings (1 day before departure). Premium Tatkal has dynamic pricing that increases as seats fill up. Tatkal also has higher reservation charges and no refunds on cancellation.' },
  { question: 'Who is eligible for fare concessions?', answer: 'Senior citizens (60+ for men, 58+ for women) get 40-50% concession. Students with valid ID cards get 25-50% off. Persons with disabilities (Divyaang) get 50-75% concession. Children below 5 years travel free, and 5-12 years get 50% off. Concessions vary by class and train type.' },
  { question: 'Why do different classes have different fares?', answer: '1A (First AC) is the most expensive with private cabins and premium amenities. 2A (Second AC) and 3A (Third AC) have berths with AC. 3E (AC Chair Car) and CC (Chair Car) have seating. SL (Sleeper) is non-AC with berths. 2S (Second Sitting) is the cheapest with basic seating. Higher classes offer more comfort and privacy.' },
  { question: 'Are there any hidden charges in train tickets?', answer: 'No hidden charges. The fare breakdown shows: Base fare + Reservation charge + Superfast charge (if applicable) + Catering charge (for Rajdhani/Shatabdi) + GST. All charges are displayed transparently before booking. Cancellation charges apply if you cancel after booking.' },
];

export default function FareInquiryPage() {
  const [trainNo, setTrainNo] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [selectedClass, setSelectedClass] = useState('2A');
  const [selectedQuota, setSelectedQuota] = useState('GN');
  const [concession, setConcession] = useState('None');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<FareInquiryResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [, setValidationError] = useState<{ train?: string; from?: string; to?: string }>({});

  const doFetch = async (train: string, fromCode: string, toCode: string, cls: string, quota: string) => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await getFareInquiry(train, fromCode, toCode, cls, quota);
      setResult(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message.toLowerCase() : '';
      if (msg.includes('rate limit') || msg.includes('429') || msg.includes('quota')) {
        setError('Fare Inquiry service temporarily unavailable due to high traffic. Please try again in a few minutes.');
      } else if (msg.includes('network') || msg.includes('could not reach')) {
        setError('Unable to connect to railway data service. Please check your internet connection and try again.');
      } else if (msg.includes('not configured') || msg.includes('not yet configured')) {
        setError('Fare Inquiry service is currently being set up. Please try again shortly.');
      } else if (msg.includes('not found') || msg.includes('invalid')) {
        setError('Fare information not found. Please verify train number and station codes.');
      } else {
        setError('Fare Inquiry service temporarily unavailable. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError({});

    const trainV = validateTrainNumber(trainNo.trim());
    const fromV  = validateStationCode(from.trim());
    const toV    = validateStationCode(to.trim());

    if (!trainV.valid || !fromV.valid || !toV.valid) {
      setValidationError({ train: trainV.error, from: fromV.error, to: toV.error });
      return;
    }

    await doFetch(trainNo.trim(), from.trim().toUpperCase(), to.trim().toUpperCase(), selectedClass, selectedQuota);
  };

  const handleRetry = () => {
    const trainV = validateTrainNumber(trainNo.trim());
    const fromV  = validateStationCode(from.trim());
    const toV    = validateStationCode(to.trim());
    if (!trainV.valid || !fromV.valid || !toV.valid) return;
    doFetch(trainNo.trim(), from.trim().toUpperCase(), to.trim().toUpperCase(), selectedClass, selectedQuota);
  };

  const swapStations = () => { setFrom(to); setTo(from); };

  return (
    <>
      <Helmet>
        <title>Train Fare Calculator — Check Train Ticket Price for Any Route | ChaloTrain</title>
        <meta name="description" content="Check train ticket fare for any route in India. Compare General vs Tatkal fares across all classes (1A, 2A, 3A, SL, CC). Includes base fare, reservation charge, GST and concession details." />
        <meta name="keywords" content="train fare, train ticket price, train fare calculator, IRCTC fare, Tatkal fare, train fare inquiry, Indian Railways fare, train ticket cost" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="ChaloTrain" />
        <meta property="og:title" content="Train Fare Calculator — Check Train Ticket Price for Any Route | ChaloTrain" />
        <meta property="og:description" content="Check train ticket fare for any route. Compare General vs Tatkal fares across all classes with complete fare breakdown including GST and concessions." />
        <meta property="og:url" content="https://chalotrain.com/fare-inquiry" />
        <meta property="og:image" content="https://chalotrain.com/og-image.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:site" content="@chalotrain" />
        <meta name="twitter:title" content="Train Fare Calculator — Check Train Ticket Price for Any Route | ChaloTrain" />
        <meta name="twitter:description" content="Check train ticket fare for any route. Compare General vs Tatkal fares across all classes with complete fare breakdown." />
        <meta name="twitter:image" content="https://chalotrain.com/og-image.png" />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href="https://chalotrain.com/fare-inquiry" />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'Train Fare Calculator — ChaloTrain',
          url: 'https://chalotrain.com/fare-inquiry',
          applicationCategory: 'TravelApplication',
          operatingSystem: 'All',
          description: 'Calculate Indian Railways train ticket fares for any route. Compare General and Tatkal fares across all classes with detailed breakdown.',
          offers: { '@type': 'Offer', price: '0', priceCurrency: 'INR' },
          provider: { '@type': 'Organization', name: 'ChaloTrain', url: 'https://chalotrain.com' },
        })}</script>
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'BreadcrumbList',
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://chalotrain.com/' },
            { '@type': 'ListItem', position: 2, name: 'Fare Inquiry', item: 'https://chalotrain.com/fare-inquiry' },
          ],
        })}</script>
      </Helmet>

      <PageHero
        icon={IndianRupee}
        title="Fare Inquiry"
        subtitle="Compare fares across all classes, quotas and concessions with detailed breakdown."
        badge="Fare Calculator"
      />
      {/* sr-only h1 for SEO checkers — PageHero renders the visible heading */}
      <h1 className="sr-only">Train Fare Calculator — Check Train Ticket Price for Any Route</h1>

      <section className="py-10 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-2xl">

          {/* SEO Introduction */}
          <motion.div initial="hidden" animate="visible" variants={fadeUp} className="bg-white rounded-2xl border border-blue-100/60 p-6 mb-6 shadow-[0_2px_12px_hsl(221_79%_48%/0.06)]">
            <h2 className="text-xl font-bold text-slate-900 mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              Train Fare Calculator — Compare All Classes & Quotas
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Planning your train journey budget? ChaloTrain's Fare Inquiry tool helps you check exact train ticket prices across all classes and quotas. Get detailed fare breakdowns including base fare, reservation charges, GST, and any applicable concessions. Compare General vs Tatkal fares to make informed booking decisions.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed mb-3">
              Our comprehensive fare calculator shows prices for all travel classes — from premium First AC (1A) to economical Second Sitting (2S). See how much you'll save with senior citizen, student, or Divyaang concessions. Compare Tatkal and Premium Tatkal fares to understand last-minute booking costs. All fares include complete breakdowns with no hidden charges.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              <strong>How to use:</strong> Enter your train number, source and destination stations. Select your travel class (1A, 2A, 3A, SL, etc.), quota (General, Tatkal, etc.), and any applicable concession. Click "Get Fare" to see the complete fare breakdown and comparison across all classes. Use this to budget your journey and choose the best value option.
            </p>
          </motion.div>

          <motion.div initial="hidden" animate="visible" variants={fadeUp}
            className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-6"
          >
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="fare-train-no" className="block text-sm font-semibold text-slate-700 mb-1.5">Train Number</label>
                <div className="relative">
                  <Train size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                  <input id="fare-train-no" type="text" value={trainNo} onChange={(e) => setTrainNo(e.target.value)}
                    placeholder="e.g. 12301"
                    inputMode="numeric"
                    className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px]"
                  />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 sm:items-end">
                <div className="flex-1">
                  <label htmlFor="fare-from" className="block text-sm font-semibold text-slate-700 mb-1.5">From Station</label>
                  <input id="fare-from" type="text" value={from} onChange={(e) => setFrom(e.target.value)}
                    placeholder="Source station code"
                    autoComplete="off"
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px]"
                  />
                </div>
                <button type="button" onClick={swapStations}
                  aria-label="Swap source and destination stations"
                  className="self-end sm:self-auto w-full sm:w-10 h-11 sm:h-10 flex items-center justify-center gap-2 sm:gap-0 rounded-xl border border-slate-200 hover:bg-blue-50 hover:border-primary transition-colors text-slate-500 hover:text-primary shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
                >
                  <ArrowLeftRight size={16} aria-hidden="true" />
                  <span className="sm:hidden text-sm font-medium">Swap Stations</span>
                </button>
                <div className="flex-1">
                  <label htmlFor="fare-to" className="block text-sm font-semibold text-slate-700 mb-1.5">To Station</label>
                  <input id="fare-to" type="text" value={to} onChange={(e) => setTo(e.target.value)}
                    placeholder="Destination station code"
                    autoComplete="off"
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm min-h-[44px]"
                  />
                </div>
              </div>

              {/* Class Selector */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1.5" id="fare-class-label">Travel Class</label>
                <div className="flex flex-wrap gap-2" role="group" aria-labelledby="fare-class-label">
                  {CLASSES.map((cls) => (
                    <button key={cls} type="button" onClick={() => setSelectedClass(cls)}
                      aria-pressed={selectedClass === cls}
                      className={`px-3 py-2 rounded-lg text-sm font-semibold border transition-all min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 ${selectedClass === cls ? 'bg-primary text-white border-primary' : 'bg-white text-slate-600 border-slate-200 hover:border-primary hover:text-primary'}`}
                    >
                      {cls}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="fare-quota" className="block text-sm font-semibold text-slate-700 mb-1.5">Quota</label>
                  <select id="fare-quota" value={selectedQuota} onChange={(e) => setSelectedQuota(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm bg-white min-h-[44px]"
                  >
                    {QUOTA_OPTIONS.map(({ label, code }) => <option key={code} value={code}>{label}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="fare-concession" className="block text-sm font-semibold text-slate-700 mb-1.5">Concession</label>
                  <select id="fare-concession" value={concession} onChange={(e) => setConcession(e.target.value)}
                    className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all text-sm bg-white min-h-[44px]"
                  >
                    {CONCESSIONS.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              {error && !result && (
                <div className="flex items-center gap-2 text-red-600 bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm" role="alert">
                  <span>{error}</span>
                </div>
              )}

              <button type="submit" disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-3 bg-primary text-white font-semibold rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-60 min-h-[44px] focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50"
              >
                <Search size={18} aria-hidden="true" /> Get Fare Details
              </button>
            </form>
          </motion.div>

          <AnimatePresence mode="wait">
            {loading && (
              <motion.div key="loading" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <LoadingSpinner message="Calculating fare..." />
              </motion.div>
            )}

            {error && !loading && (
              <motion.div key="error" initial="hidden" animate="visible" exit="hidden" variants={fadeUp} className="mt-6">
                <ErrorMessage title="Unable to Fetch Fare" message={error} onRetry={handleRetry} />
              </motion.div>
            )}

            {result && !loading && !error && (
              <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                transition={{ duration: 0.4, ease: 'easeOut' as const }} className="space-y-4"
              >
                {/* Train Info Header */}
                <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white rounded-2xl p-6 text-center">
                  <div className="text-sm text-blue-200 mb-1">{result.trainNumber} • {result.trainName}</div>
                  <div className="text-sm text-blue-200 mb-3">{result.from} → {result.to} • {result.distance} km</div>
                  <div className="text-3xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
                    Fare Information
                  </div>
                </div>

                {/* Fare Table */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
                    <Info size={16} className="text-primary" />
                    <h3 className="font-semibold text-slate-800" style={{ fontFamily: 'var(--font-heading)' }}>Class-wise Fares</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-5 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Class</th>
                          <th className="px-5 py-3 text-right text-xs font-semibold text-slate-600 uppercase">General Fare</th>
                          <th className="px-5 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Tatkal Fare</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {result.fares.map((fareItem) => (
                          <tr key={fareItem.class} className="hover:bg-slate-50 transition-colors">
                            <td className="px-5 py-3 text-sm font-medium text-slate-800">{fareItem.class}</td>
                            <td className="px-5 py-3 text-sm text-slate-600 text-right">₹{fareItem.fare.toLocaleString('en-IN')}</td>
                            <td className="px-5 py-3 text-sm text-slate-600 text-right">₹{fareItem.tatkalFare.toLocaleString('en-IN')}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Related Tools */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <RelatedTools currentHref="/fare-inquiry" />
          </motion.div>

          {/* Social Share */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <SocialShareBar
              title="Check train fares on ChaloTrain — Compare all classes & quotas"
              url="https://chalotrain.com/fare-inquiry"
            />
          </motion.div>

          {/* FAQ */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-4">
            <FAQSection items={FAQ_ITEMS} />
          </motion.div>

          {/* Learn more */}
          <div className="container mx-auto px-4 pb-2 mt-3">
            <div className="max-w-2xl mx-auto">
              <p className="text-sm text-slate-500">
                Want to learn more?{' '}
                <Link to="/blog/train-ticket-cancellation-refund-rules" className="text-primary hover:underline font-medium">
                  Read our complete guide →
                </Link>
              </p>
            </div>
          </div>

          {/* Disclaimer */}
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="mt-6">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-center">
              <p className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> This website is not affiliated with IRCTC or Indian Railways and provides railway information for general purposes only. Please verify critical information from official sources.
              </p>
            </div>
          </motion.div>

        </div>
      </section>
    </>
  );
}
