import { RouteObject } from 'react-router-dom';
import { lazy } from 'react';
import HomePage from './pages/index';
import PNRStatusPage from './pages/pnr-status';
import LiveStatusPage from './pages/live-status';
import TrainSearchPage from './pages/train-search';
import SeatAvailabilityPage from './pages/seat-availability';
import TrainSchedulePage from './pages/train-schedule';
import FareInquiryPage from './pages/fare-inquiry';
import AboutPage from './pages/about';
import ContactPage from './pages/contact';
import PrivacyPage from './pages/privacy';
import TermsPage from './pages/terms';
import DisclaimerPage from './pages/disclaimer';
// Blog
import BlogIndexPage from './pages/blog/index';
import BlogPNRStatusPage from './pages/blog/how-to-check-pnr-status-online';
import BlogTatkalPage from './pages/blog/tatkal-ticket-booking-tips';
import BlogConfirmedTicketPage from './pages/blog/how-to-get-confirmed-train-ticket';
import BlogTrainDelayPage from './pages/blog/why-trains-run-late-in-india';
import BlogIRCTCGuidePage from './pages/blog/irctc-booking-guide-for-beginners';
import BlogRailwayClassesPage from './pages/blog/indian-railway-classes-guide';
import BlogCancellationPage from './pages/blog/train-ticket-cancellation-refund-rules';
import BlogBookingGuidePage from './pages/blog/how-to-book-train-tickets-online';
// New blog articles
import BlogPNRGuide from './pages/blog/how-to-check-pnr-status-online-guide';
import BlogIRCTCComplete from './pages/blog/irctc-complete-booking-guide';
import BlogTrainTips from './pages/blog/train-travel-tips-for-beginners';
import BlogReadTicket from './pages/blog/how-to-read-train-ticket';
import BlogSeatAvailability from './pages/blog/how-to-check-seat-availability';
import BlogFileTDR from './pages/blog/how-to-file-tdr';
import BlogDelhiMumbai from './pages/blog/best-trains-delhi-to-mumbai';
import BlogLiveStatus from './pages/blog/how-to-track-live-train-status';
import BlogTatkalComplete from './pages/blog/tatkal-ticket-booking-complete-guide';
import BlogTrainSchedule from './pages/blog/how-to-check-train-schedule';

// 404 routing by runtime:
// - DEV (preview container / local vite): dev-tools PageNotFound — development iframe vs standalone preview
// - PROD (publish build): pages/_404 — plain 404 for visitors
const NotFoundPage = import.meta.env.DEV
  ? lazy(() => import('../export-plugins/PageNotFound'))
  : lazy(() => import('./pages/_404'));

export const routes: RouteObject[] = [
  { path: '/', element: <HomePage /> },
  { path: '/pnr-status', element: <PNRStatusPage /> },
  { path: '/live-status', element: <LiveStatusPage /> },
  { path: '/train-search', element: <TrainSearchPage /> },
  { path: '/seat-availability', element: <SeatAvailabilityPage /> },
  { path: '/train-schedule', element: <TrainSchedulePage /> },
  { path: '/fare-inquiry', element: <FareInquiryPage /> },
  { path: '/about', element: <AboutPage /> },
  { path: '/contact', element: <ContactPage /> },
  { path: '/privacy', element: <PrivacyPage /> },
  { path: '/terms', element: <TermsPage /> },
  { path: '/disclaimer', element: <DisclaimerPage /> },
  // Blog index
  { path: '/blog', element: <BlogIndexPage /> },
  // Original 8 articles
  { path: '/blog/how-to-check-pnr-status-online', element: <BlogPNRStatusPage /> },
  { path: '/blog/tatkal-ticket-booking-tips', element: <BlogTatkalPage /> },
  { path: '/blog/how-to-get-confirmed-train-ticket', element: <BlogConfirmedTicketPage /> },
  { path: '/blog/why-trains-run-late-in-india', element: <BlogTrainDelayPage /> },
  { path: '/blog/irctc-booking-guide-for-beginners', element: <BlogIRCTCGuidePage /> },
  { path: '/blog/indian-railway-classes-guide', element: <BlogRailwayClassesPage /> },
  { path: '/blog/train-ticket-cancellation-refund-rules', element: <BlogCancellationPage /> },
  { path: '/blog/how-to-book-train-tickets-online', element: <BlogBookingGuidePage /> },
  // New 10 articles
  { path: '/blog/how-to-check-pnr-status-online-guide', element: <BlogPNRGuide /> },
  { path: '/blog/irctc-complete-booking-guide', element: <BlogIRCTCComplete /> },
  { path: '/blog/train-travel-tips-for-beginners', element: <BlogTrainTips /> },
  { path: '/blog/how-to-read-train-ticket', element: <BlogReadTicket /> },
  { path: '/blog/how-to-check-seat-availability', element: <BlogSeatAvailability /> },
  { path: '/blog/how-to-file-tdr', element: <BlogFileTDR /> },
  { path: '/blog/best-trains-delhi-to-mumbai', element: <BlogDelhiMumbai /> },
  { path: '/blog/how-to-track-live-train-status', element: <BlogLiveStatus /> },
  { path: '/blog/tatkal-ticket-booking-complete-guide', element: <BlogTatkalComplete /> },
  { path: '/blog/how-to-check-train-schedule', element: <BlogTrainSchedule /> },
  { path: '*', element: <NotFoundPage /> },
];

export type Path =
  | '/'
  | '/pnr-status'
  | '/live-status'
  | '/train-search'
  | '/seat-availability'
  | '/train-schedule'
  | '/fare-inquiry'
  | '/about'
  | '/contact'
  | '/privacy'
  | '/terms'
  | '/disclaimer'
  | '/blog'
  | '/blog/how-to-check-pnr-status-online'
  | '/blog/tatkal-ticket-booking-tips'
  | '/blog/how-to-get-confirmed-train-ticket'
  | '/blog/why-trains-run-late-in-india'
  | '/blog/irctc-booking-guide-for-beginners'
  | '/blog/indian-railway-classes-guide'
  | '/blog/train-ticket-cancellation-refund-rules'
  | '/blog/how-to-book-train-tickets-online'
  | '/blog/how-to-check-pnr-status-online-guide'
  | '/blog/irctc-complete-booking-guide'
  | '/blog/train-travel-tips-for-beginners'
  | '/blog/how-to-read-train-ticket'
  | '/blog/how-to-check-seat-availability'
  | '/blog/how-to-file-tdr'
  | '/blog/best-trains-delhi-to-mumbai'
  | '/blog/how-to-track-live-train-status'
  | '/blog/tatkal-ticket-booking-complete-guide'
  | '/blog/how-to-check-train-schedule';

export type Params = Record<string, string | undefined>;
