import express, { type NextFunction, type Request, type Response } from "express";
import { fileURLToPath } from "node:url";
import { dirname, extname, join } from "node:path";
import { readFileSync } from "node:fs";

// <api-imports>
import fare_inquiry_get_0 from "./api/fare-inquiry/GET";
import health_get_1 from "./api/health/GET";
import live_status_get_2 from "./api/live-status/GET";
import pnr_status_pnr_get_3 from "./api/pnr-status/[pnr]/GET";
import seat_availability_get_4 from "./api/seat-availability/GET";
import train_by_number_get_5 from "./api/train-by-number/GET";
import train_schedule_trainNumber_get_6 from "./api/train-schedule/[trainNumber]/GET";
import train_search_get_7 from "./api/train-search/GET";
// </api-imports>
import { seoRoutes } from "../lib/seo-routes";

function normalizeCommerceApiBaseUrlEnv() {
	if (process.env.GODADDY_API_BASE_URL) return;
	const hostOnly = process.env.VITE_GODADDY_API_HOST;
	if (!hostOnly) return;
	const normalizedHost = hostOnly.replace(/^https?:\/\//, "").trim();
	if (!normalizedHost) return;
	process.env.GODADDY_API_BASE_URL = `https://${normalizedHost}`;
}

normalizeCommerceApiBaseUrlEnv();

const app = express();

// Honour x-forwarded-* from the load balancer so req.protocol/req.hostname
// reflect the public-facing values. Express-maintained parsing respects the
// existing trust-proxy config; direct header reads would let a client spoof
// the sitemap origin in robots.txt.
app.set("trust proxy", true);

// ── Security headers ──────────────────────────────────────────────────────────
// Applied to every response before any route handler runs.
app.use((_req, res, next) => {
  // Prevent clickjacking
  res.set("X-Frame-Options", "SAMEORIGIN");
  // Stop MIME-type sniffing
  res.set("X-Content-Type-Options", "nosniff");
  // Basic XSS protection for older browsers
  res.set("X-XSS-Protection", "1; mode=block");
  // Referrer policy — send origin only on cross-origin requests
  res.set("Referrer-Policy", "strict-origin-when-cross-origin");
  // Permissions policy — disable unused browser features
  res.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
  // HSTS — enforce HTTPS for 1 year (only meaningful in production behind TLS)
  res.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  // Content-Security-Policy — allow same-origin + trusted CDNs used by the app
  res.set(
    "Content-Security-Policy",
    [
      "default-src 'self'",
      // Scripts: self + inline (React hydration) + Vite HMR in dev
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
      // Styles: self + inline (Tailwind)
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      // Fonts
      "font-src 'self' https://fonts.gstatic.com",
      // Images: self + data URIs
      "img-src 'self' data: blob: https:",
      // Connect: self only (all external calls are proxied via our own backend)
      "connect-src 'self'",
      // Media
      "media-src 'self' https:",
      // Frames: deny embedding third-party iframes
      "frame-src 'none'",
      // Object/embed
      "object-src 'none'",
      // Base URI
      "base-uri 'self'",
      // Form action
      "form-action 'self'",
    ].join("; "),
  );
  next();
});

// ── Simple in-memory rate limiter for /api routes ─────────────────────────────
// Limits each IP to 60 requests per minute across all API endpoints.
// Uses a sliding-window counter stored in a Map; entries are pruned on each hit.
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT_WINDOW_MS = 60_000; // 1 minute
const RATE_LIMIT_MAX       = 60;     // requests per window

app.use("/api", (req: Request, res: Response, next: NextFunction) => {
  const ip = (req.ip ?? req.socket.remoteAddress ?? "unknown").replace(/^::ffff:/, "");
  const now = Date.now();
  const entry = rateLimitMap.get(ip);

  if (!entry || entry.resetAt <= now) {
    // New window
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return next();
  }

  entry.count += 1;
  if (entry.count > RATE_LIMIT_MAX) {
    const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
    res
      .status(429)
      .set("Retry-After", String(retryAfter))
      .json({ error: "Too many requests", message: `Rate limit exceeded. Try again in ${retryAfter}s.` });
    return;
  }
  return next();
});

// Prune stale rate-limit entries every 5 minutes to prevent unbounded growth
setInterval(() => {
  const now = Date.now();
  for (const [ip, entry] of rateLimitMap) {
    if (entry.resetAt <= now) rateLimitMap.delete(ip);
  }
}, 5 * 60_000).unref();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// <api-registrations>
app.get("/api/fare-inquiry", fare_inquiry_get_0);
app.get("/api/health", health_get_1);
app.get("/api/live-status", live_status_get_2);
app.get("/api/pnr-status/:pnr", pnr_status_pnr_get_3);
app.get("/api/seat-availability", seat_availability_get_4);
app.get("/api/train-by-number", train_by_number_get_5);
app.get("/api/train-schedule/:trainNumber", train_schedule_trainNumber_get_6);
app.get("/api/train-search", train_search_get_7);
// </api-registrations>

// Error middleware must be registered AFTER the routes it protects; Express
// only passes errors to middleware defined later in the stack.
app.use("/api", (err: unknown, req: Request, res: Response, _next: NextFunction) => {
	// Always respond JSON on /api so clients parsing response.json() don't
	// receive Express's default HTML error page for non-Error throws.
	console.error("ssr.api.error", {
		url: req.url,
		error: err instanceof Error ? err.stack : String(err),
	});
	res.status(500).json({ error: "Internal server error" });
});

function baseUrl(req: Request): string {
	const env = process.env.PUBLIC_URL || process.env.SITE_URL;
	if (env) return env.replace(/\/+$/, "");
	return `${req.protocol}://${req.hostname}`;
}

function escapeXml(s: string): string {
	return s.replace(/[&<>"']/g, (c) =>
		({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[c]!,
	);
}

// ── WordPress / legacy URL cleanup ────────────────────────────────────────────
// These paths were indexed when the site ran on WordPress. Returning 410 Gone
// (rather than 404) tells Google the content is permanently removed and to
// drop the URL from the index immediately, rather than retrying indefinitely.
//
// Patterns covered:
//   /wp-admin/*, /wp-content/*, /wp-includes/*, /wp-login.php, /wp-cron.php,
//   /xmlrpc.php, /?p=N, /?page_id=N, /feed/, /category/*, /tag/*, /author/*,
//   /page/N/*, /index.php/*, /?s= (search), /?m= (month archive)
const WP_GONE_PATTERNS: RegExp[] = [
  /^\/wp-admin(\/|$)/,
  /^\/wp-content(\/|$)/,
  /^\/wp-includes(\/|$)/,
  /^\/wp-login\.php$/,
  /^\/wp-cron\.php$/,
  /^\/xmlrpc\.php$/,
  /^\/index\.php(\/|$)/,
  /^\/feed(\/|$)/,
  /^\/category(\/|$)/,
  /^\/tag(\/|$)/,
  /^\/author(\/|$)/,
  /^\/page\/\d+(\/|$)/,
  /^\/\?p=\d+/,
  /^\/\?page_id=\d+/,
  /^\/\?cat=\d+/,
  /^\/\?tag=/,
  /^\/\?author=\d+/,
  /^\/\?s=/,
  /^\/\?m=\d+/,
];

app.use((req: Request, res: Response, next: NextFunction) => {
  const queryStr = req.url.includes('?') ? req.url.slice(req.url.indexOf('?')) : '';
  const fullUrl = req.path + queryStr;
  const isWpUrl = WP_GONE_PATTERNS.some((re) => re.test(fullUrl));
  if (isWpUrl) {
    res
      .status(410)
      .set("Content-Type", "text/plain; charset=utf-8")
      .set("Cache-Control", "public, max-age=86400")
      .send("410 Gone — This page no longer exists.");
    return;
  }
  next();
});

app.get("/robots.txt", (req, res) => {
	const base = baseUrl(req);
	const body = [
		"User-agent: *",
		"Allow: /",
		// WordPress paths that no longer exist — tell crawlers not to waste crawl budget
		"Disallow: /wp-admin/",
		"Disallow: /wp-content/",
		"Disallow: /wp-includes/",
		"Disallow: /wp-login.php",
		"Disallow: /wp-cron.php",
		"Disallow: /xmlrpc.php",
		"Disallow: /?p=",
		"Disallow: /?page_id=",
		"Disallow: /?cat=",
		"Disallow: /?tag=",
		"Disallow: /?author=",
		"Disallow: /feed/",
		"Disallow: /category/",
		"Disallow: /tag/",
		"Disallow: /author/",
		"Disallow: /page/",
		"Disallow: /flights",
		"Disallow: /hotels",
		"Disallow: /hotel-details",
		"",
		`Sitemap: ${base}/sitemap.xml`,
		"",
	].join("\n");
	res.type("text/plain").set("Cache-Control", "public, max-age=3600").send(body);
});

app.get("/sitemap.xml", (req, res) => {
	const base = baseUrl(req);
	const urls = seoRoutes
		.filter((r) => typeof r.path === "string" && r.path.startsWith("/"))
		.map((r) => {
			const loc = `${base}${r.path}`;
			const parts = [`    <loc>${escapeXml(loc)}</loc>`];
			if (r.lastmod) parts.push(`    <lastmod>${escapeXml(r.lastmod)}</lastmod>`);
			if (r.changefreq) parts.push(`    <changefreq>${r.changefreq}</changefreq>`);
			if (r.priority !== undefined)
				parts.push(`    <priority>${r.priority.toFixed(1)}</priority>`);
			return `  <url>\n${parts.join("\n")}\n  </url>`;
		})
		.join("\n");
	const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
	res.type("application/xml").set("Cache-Control", "public, max-age=3600").send(body);
});

if (import.meta.env.PROD) {
	const __dirname = dirname(fileURLToPath(import.meta.url));
	const clientDir = join(__dirname, "client");

	app.use(
		express.static(clientDir, {
			index: false,
			setHeaders(res, filePath) {
				res.set(
					"Cache-Control",
					filePath.includes("/assets/")
						? "public, max-age=31536000, immutable"
						: "no-cache",
				);
			},
		}),
	);

	app.use((_req, res, next) => {
		res.set("Cache-Control", "no-cache");
		next();
	});

	let template: string;
	try {
		template = readFileSync(join(clientDir, "index.html"), "utf-8");
	} catch (err) {
		console.error("ssr.template.load-failed", {
			path: join(clientDir, "index.html"),
			error: err instanceof Error ? err.message : String(err),
		});
		process.exit(1);
	}
	if (!template.includes("<!--app-head-->") || !template.includes("<!--app-html-->")) {
		// Fail fast at boot, same as a template load failure above: without
		// markers, every .replace() call on the render path is a no-op and we
		// would serve a shell with no <head> content and no rendered body on
		// every request. Preferring process.exit over a degraded mode ensures
		// an operator notices and fixes the build rather than serving broken
		// SEO-invisible pages indefinitely.
		console.error("ssr.template.markers-missing", {
			hasHead: template.includes("<!--app-head-->"),
			hasHtml: template.includes("<!--app-html-->"),
		});
		process.exit(1);
	}
	const fallbackShell = template
		.replace("<!--app-head-->", "")
		.replace("<!--app-html-->", "");

	// Resolve the SSR module once into a stable render function. A failed
	// load is unrecoverable at runtime - exiting lets the container
	// scheduler restart with a clean slate rather than leaving the server
	// to serve silent 503s indefinitely against a single startup log.
	type RenderResult = {
		html: string;
		head: string;
		status: number;
		redirect?: string;
	};
	let renderFn: ((url: string) => Promise<RenderResult>) | null = null;
	const SSR_MODULE_LOAD_TIMEOUT_MS = 30_000;
	const loadTimeout = setTimeout(() => {
		if (renderFn !== null) return;
		console.error("ssr.module.load-timeout", {
			timeoutMs: SSR_MODULE_LOAD_TIMEOUT_MS,
		});
		process.exit(1);
	}, SSR_MODULE_LOAD_TIMEOUT_MS);
	loadTimeout.unref();
	import("../entry-server").then(
		(mod) => {
			clearTimeout(loadTimeout);
			renderFn = mod.render;
		},
		(err) => {
			clearTimeout(loadTimeout);
			console.error("ssr.module.load-failed", {
				error: err instanceof Error ? err.stack : String(err),
			});
			process.exit(1);
		},
	);

	app.get(/.*/, async (req, res, next) => {
		if (req.method !== "GET") return next();
		if (req.path.startsWith("/api")) return next();
		if (extname(req.path)) return next();
		const sendFallback = () =>
			res
				.status(503)
				.set("Content-Type", "text/html; charset=utf-8")
				.set("Cache-Control", "no-store")
				.send(fallbackShell);
		if (renderFn === null) {
			// Module not yet resolved; fall back without logging to avoid startup
			// noise before the first render is even possible. A terminal load
			// failure (import reject or 30s timeout) process.exit(1)s from the
			// loader above, so this branch is only the brief warmup window.
			return sendFallback();
		}
		try {
			const result = await renderFn(req.url);
			if (result.redirect) {
				// Redirect thrown from a loader/action surfaces as a Response.
				// Forward it so the browser actually navigates to the new URL
				// instead of seeing an empty shell with a stale status.
				res.redirect(result.status, result.redirect);
				return;
			}
			if (!result.html) {
				// A non-redirect Response was thrown from a loader (e.g.
				// `throw new Response(null, { status: 404 })`). renderToString
				// produced no markup, so we have a real status but no body.
				// Log so the case is observable in ops dashboards, and mark
				// no-store so CDNs don't cache an empty page as a valid hit.
				// User-visible 404 / error pages should come from a route
				// errorElement, not from this fallback path.
				console.error("ssr.render.error-response", {
					url: req.url,
					status: result.status,
				});
				res
					.status(result.status)
					.set("Content-Type", "text/html; charset=utf-8")
					.set("Cache-Control", "no-store")
					.send(fallbackShell);
				return;
			}
			// Function replacements disable String.replace's $-special sequences
			// ($&, $', $`, $$) so user-authored titles / JSON-LD like
			// "Save $& today" insert literally instead of being interpolated.
			const out = template
				.replace("<!--app-head-->", () => result.head)
				.replace("<!--app-html-->", () => result.html);
			res
				.status(result.status)
				.set("Content-Type", "text/html; charset=utf-8")
				.set("Cache-Control", "no-cache")
				.send(out);
		} catch (err) {
			// 503 surfaces the failure in CDN/monitoring without caching a broken
			// page as success. console.error (not warn) puts it at the right log
			// level for the observability pipeline to alert on.
			console.error("ssr.render.failed", {
				url: req.url,
				// Log the full stack — React's renderToString annotates it with
				// the failing component's call tree, which the message alone
				// discards.
				error: err instanceof Error ? err.stack : String(err),
			});
			sendFallback();
		}
	});

	const shutdown = async (signal: string) => {
		console.log(`Got ${signal}, shutting down gracefully...`);
		// Scope the ERR_MODULE_NOT_FOUND suppression to the import() only.
		// A closeConnection() failure that happens to carry the same code
		// (unlikely but possible for wrapped errors) must not be silently
		// swallowed - it indicates a real db-close failure worth logging.
		let mod: { closeConnection?: () => Promise<void> | void } | null = null;
		try {
			const dbClient = "./db/client" + ".js";
			mod = await import(/* @vite-ignore */ dbClient);
		} catch (error: unknown) {
			const code = (error as { code?: string } | null)?.code;
			if (code !== "ERR_MODULE_NOT_FOUND") {
				console.error("ssr.shutdown.db-import-failed", {
					error: error instanceof Error ? error.message : String(error),
				});
			}
		}
		if (mod && typeof mod.closeConnection === "function") {
			try {
				await mod.closeConnection();
				console.log("Database connections closed");
			} catch (error: unknown) {
				console.error("ssr.shutdown.db-close-failed", {
					error: error instanceof Error ? error.message : String(error),
				});
			}
		}
		process.exit(0);
	};

	(["SIGTERM", "SIGINT"] as const).forEach((signal) => {
		process.once(signal, () => {
			void shutdown(signal);
		});
	});

	const rawPort = process.env.PORT || "3000";
	const port = parseInt(rawPort, 10);
	if (!Number.isInteger(port) || port <= 0 || port > 65535) {
		// parseInt("abc") returns NaN; passing that to app.listen throws
		// synchronously before the server.on("error") handler below can catch
		// it. Fail fast with an actionable log rather than a cryptic crash.
		console.error("ssr.server.invalid-port", { rawPort });
		process.exit(1);
	}
	const host = process.env.HOST || "0.0.0.0";
	const server = app.listen(port, host, () => {
		console.log(`Server listening on http://${host}:${port}`);
	});
	server.on("error", (err: NodeJS.ErrnoException) => {
		console.error("ssr.server.listen-failed", {
			port,
			host,
			code: err.code,
			error: err.message,
		});
		process.exit(1);
	});
}

export default app;

// ── Exported helpers (used by tests) ─────────────────────────────────────────

export interface AdSenseConfig {
  publisherId: string | null;
  scriptHtml: string;
  adsTxt: string | null;
  appAdsTxt: string | null;
}

/**
 * Registers /ads.txt and /app-ads.txt routes on the given Express app.
 * When the corresponding text value is null the route returns 404.
 */
export function registerAdSenseTextRoutes(
  expressApp: import("express").Express,
  config: AdSenseConfig,
): void {
  const textRoute = (content: string | null) =>
    (_req: Request, res: Response) => {
      res.set("Content-Type", "text/plain; charset=utf-8");
      res.set("Cache-Control", "no-cache");
      if (content === null) {
        res.status(404).send("Not found");
      } else {
        res.status(200).send(content);
      }
    };
  expressApp.get("/ads.txt", textRoute(config.adsTxt));
  expressApp.get("/app-ads.txt", textRoute(config.appAdsTxt));
}

/**
 * Replaces <!--app-head--> and <!--app-html--> markers in the HTML template
 * and optionally appends the AdSense script tag after the head content.
 */
export function renderSsrDocument(
  template: string,
  result: { head: string; html: string },
  adsense: { scriptHtml: string },
): string {
  const headContent = adsense.scriptHtml
    ? `${result.head}\n${adsense.scriptHtml}`
    : result.head;
  return template
    .replace("<!--app-head-->", () => headContent)
    .replace("<!--app-html-->", () => result.html);
}
