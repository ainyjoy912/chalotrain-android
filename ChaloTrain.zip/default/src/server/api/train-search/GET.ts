/**
 * GET /api/train-search?from=NDLS&to=BCT&date=YYYY-MM-DD&quota=GN
 *
 * Calls irctc1.p.rapidapi.com trainBetweenStations and normalises the
 * response into the TrainSearchResponse shape expected by the frontend.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

const STATION_CODE_RE = /^[A-Z0-9]{2,7}$/;

// RapidAPI irctc1 trainBetweenStations actual response shape
interface RapidTrain {
  // Common field names observed in irctc1 API
  train_number?: string;
  trainNumber?: string;
  train_name?: string;
  trainName?: string;
  train_type?: string;
  trainType?: string;
  // Departure/arrival at from/to station
  from_std?: string;   // scheduled departure from source
  to_std?: string;     // scheduled arrival at destination
  departureTime?: string;
  arrivalTime?: string;
  duration?: string;
  // Running days: object like { monday: true, tuesday: false, ... }
  run_days?: Record<string, boolean>;
  runningDays?: Record<string, boolean>;
  // Available classes: array of strings or objects
  class_type?: Array<string | { classType?: string; available?: boolean }>;
  classesAvailable?: Array<{ classType?: string; available?: boolean }>;
  [key: string]: unknown;
}

interface RapidTrainSearchResponse {
  status: boolean;
  message?: string;
  data?: RapidTrain[];
}

const DAY_KEYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const DAY_SHORT = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default async function handler(req: Request, res: Response) {
  const { from, to, date, quota } = req.query;

  if (!from || typeof from !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Source station code is required.' });
  }
  if (!to || typeof to !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Destination station code is required.' });
  }
  if (!date || typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ error: 'Invalid parameter', message: 'Date must be in YYYY-MM-DD format.' });
  }

  const fromUC = from.toUpperCase();
  const toUC = to.toUpperCase();

  if (!STATION_CODE_RE.test(fromUC)) {
    return res.status(400).json({ error: 'Invalid station code', message: `Invalid source station code "${fromUC}".` });
  }
  if (!STATION_CODE_RE.test(toUC)) {
    return res.status(400).json({ error: 'Invalid station code', message: `Invalid destination station code "${toUC}".` });
  }

  const apiKey = String(getSecret('RAPIDAPI_KEY') ?? '');
  if (!apiKey) {
    return res.status(503).json({ error: 'Configuration error', message: 'RAPIDAPI_KEY is not configured.' });
  }

  // Convert YYYY-MM-DD → YYYYMMDD for RapidAPI
  const dateFormatted = date.replace(/-/g, '');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const url = `https://irctc1.p.rapidapi.com/api/v3/trainBetweenStations?fromStationCode=${encodeURIComponent(fromUC)}&toStationCode=${encodeURIComponent(toUC)}&dateOfJourney=${dateFormatted}`;

    const fetchRes: Awaited<ReturnType<typeof fetch>> = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': apiKey,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('Train search RapidAPI error', fetchRes.status, text);
      if (fetchRes.status === 429) {
        return res.status(429).json({ error: 'Rate limit', message: 'API rate limit reached. Please try again later.' });
      }
      return res.status(502).json({ error: 'Upstream error', message: `RapidAPI returned ${fetchRes.status}.` });
    }

    const json = (await fetchRes.json()) as RapidTrainSearchResponse;

    if (!json.status || !json.data) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'No trains found between these stations on this date.',
      });
    }

    const trains = json.data.map((t) => {
      // Normalise train number — try both snake_case and camelCase
      const trainNumber = String(t.train_number ?? t.trainNumber ?? '');
      const trainName   = String(t.train_name   ?? t.trainName   ?? '');
      const trainType   = String(t.train_type   ?? t.trainType   ?? '');
      const departure   = String(t.from_std     ?? t.departureTime ?? '--');
      const arrival     = String(t.to_std       ?? t.arrivalTime   ?? '--');
      const duration    = String(t.duration ?? '--');

      // Running days
      const runDaysObj = t.run_days ?? t.runningDays ?? {};
      const runDays = DAY_KEYS.map((k, i) =>
        runDaysObj[k] ? DAY_SHORT[i] : null
      ).filter(Boolean) as string[];

      // Available classes
      const availability: Record<string, string> = {};
      const classArr = t.class_type ?? t.classesAvailable ?? [];
      for (const c of classArr) {
        if (typeof c === 'string') {
          availability[c] = 'AVAILABLE';
        } else if (c && typeof c === 'object' && c.classType) {
          availability[c.classType] = c.available !== false ? 'AVAILABLE' : 'NOT AVAILABLE';
        }
      }

      return { trainNumber, trainName, trainType, departure, arrival, duration, daysOfWeek: runDays, availability };
    });

    return res.json({
      from: fromUC,
      to: toUC,
      date,
      quota: typeof quota === 'string' ? quota : 'GN',
      trains,
    });
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort') || msg.includes('signal')) {
      return res.status(504).json({ error: 'Timeout', message: 'Request timed out. Please try again.' });
    }
    console.error('train-search handler error:', err);
    return res.status(500).json({ error: 'Internal error', message: 'Failed to search trains. Please try again.' });
  }
}
