/**
 * GET /api/train-schedule/:trainNumber
 *
 * Calls irctc1.p.rapidapi.com getTrainRoute and normalises the response
 * into the TrainScheduleResponse shape expected by the frontend.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

interface RapidRouteStation {
  stationCode?: string;
  stationName?: string;
  arrivalTime?: string;
  departureTime?: string;
  haltTime?: string;
  platform?: string | number;
  distance?: number;
  dayCount?: number;
  zone?: string;
  [key: string]: unknown;
}

interface RapidRouteData {
  trainNumber?: string;
  trainName?: string;
  trainType?: string;
  stationList?: RapidRouteStation[];
  [key: string]: unknown;
}

interface RapidRouteResponse {
  status: boolean;
  message?: string;
  data?: RapidRouteData;
}

export default async function handler(req: Request, res: Response) {
  const { trainNumber } = req.params as { trainNumber: string };

  if (!trainNumber || !/^\d{5}$/.test(trainNumber)) {
    return res.status(400).json({
      error: 'Invalid parameter',
      message: 'Train number must be exactly 5 digits.',
    });
  }

  const apiKey = String(getSecret('RAPIDAPI_KEY') ?? '');
  if (!apiKey) {
    return res.status(503).json({ error: 'Configuration error', message: 'RAPIDAPI_KEY is not configured.' });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const url = `https://irctc1.p.rapidapi.com/api/v3/getTrainRoute?trainNo=${encodeURIComponent(trainNumber)}`;

    const fetchRes: Awaited<ReturnType<typeof fetch>> = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': apiKey,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('Train schedule RapidAPI error', fetchRes.status, text);
      if (fetchRes.status === 429) {
        return res.status(429).json({ error: 'Rate limit', message: 'API rate limit reached. Please try again later.' });
      }
      return res.status(502).json({ error: 'Upstream error', message: `RapidAPI returned ${fetchRes.status}.` });
    }

    const json = (await fetchRes.json()) as RapidRouteResponse;

    if (!json.status || !json.data) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'Train schedule not found.',
      });
    }

    const d = json.data;

    const stations = (d.stationList ?? []).map((s) => ({
      stationCode: s.stationCode ?? '',
      stationName: s.stationName ?? '',
      arrival: s.arrivalTime ?? '--',
      departure: s.departureTime ?? '--',
      halt: s.haltTime ?? '--',
      platform: s.platform != null ? String(s.platform) : undefined,
      distance: s.distance ?? 0,
      day: s.dayCount ?? 1,
      zone: s.zone ?? '',
    }));

    return res.json({
      trainNumber: d.trainNumber ?? trainNumber,
      trainName: d.trainName ?? '',
      trainType: d.trainType ?? '',
      stations,
      raw: d,
    });
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort') || msg.includes('signal')) {
      return res.status(504).json({ error: 'Timeout', message: 'Request timed out. Please try again.' });
    }
    console.error('train-schedule handler error:', err);
    return res.status(500).json({ error: 'Internal error', message: 'Failed to fetch train schedule. Please try again.' });
  }
}
