/**
 * GET /api/live-status?train=12345&date=YYYY-MM-DD
 *
 * Calls irctc1.p.rapidapi.com liveTrainStatus and normalises the response
 * into the LiveTrainStatusResponse shape expected by the frontend.
 *
 * The RapidAPI endpoint uses startDay (0 = today, 1 = yesterday, 2 = day before).
 * We convert the incoming YYYY-MM-DD date to a startDay offset.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

// Actual field names from irctc1 liveTrainStatus API
interface RapidStation {
  // Station identity
  station_code?: string;
  stationCode?: string;
  station_name?: string;
  stationName?: string;
  // Scheduled times
  scharr?: string;        // scheduled arrival
  schdep?: string;        // scheduled departure
  arrivalTime?: string;
  departureTime?: string;
  // Actual times
  actarr?: string;        // actual arrival
  actdep?: string;        // actual departure
  actualArrivalTime?: string;
  actualDepartureTime?: string;
  // Delay
  latemin?: number;       // delay in minutes
  delayInArrival?: number;
  delayInDeparture?: number;
  // Platform
  pfno?: string | number;
  platform?: string | number;
  // Status flags
  isCurrent?: boolean;
  has_arrived?: boolean;
  has_departed?: boolean;
  status?: string;
  [key: string]: unknown;
}

interface RapidLiveData {
  // Train identity
  train_number?: string;
  trainNo?: string;
  train_name?: string;
  trainName?: string;
  // Run date
  train_start_date?: string;
  runDate?: string;
  // Current position
  current_station_code?: string;
  currentStation?: string;
  // Delay
  delay?: number;
  // Station list
  trainStations?: RapidStation[];
  // Some versions wrap stations differently
  [key: string]: unknown;
}

interface RapidLiveResponse {
  status: boolean;
  message?: string;
  data?: RapidLiveData;
}

export default async function handler(req: Request, res: Response) {
  const { train, date } = req.query;

  if (!train || typeof train !== 'string' || !/^\d{5}$/.test(train)) {
    return res.status(400).json({ error: 'Invalid parameter', message: 'Train number must be exactly 5 digits.' });
  }
  if (!date || typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ error: 'Invalid parameter', message: 'Date must be in YYYY-MM-DD format.' });
  }

  // Convert date to startDay offset (0 = today, 1 = yesterday, 2 = day before)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const journeyDate = new Date(date);
  journeyDate.setHours(0, 0, 0, 0);
  const diffDays = Math.round((today.getTime() - journeyDate.getTime()) / 86400000);
  const startDay = Math.max(0, Math.min(2, diffDays));

  const apiKey = String(getSecret('RAPIDAPI_KEY') ?? '');
  if (!apiKey) {
    return res.status(503).json({ error: 'Configuration error', message: 'RAPIDAPI_KEY is not configured.' });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const url = `https://irctc1.p.rapidapi.com/api/v1/liveTrainStatus?trainNo=${encodeURIComponent(train)}&startDay=${startDay}`;

    const fetchRes: Awaited<ReturnType<typeof fetch>> = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': apiKey,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('Live status RapidAPI error', fetchRes.status, text);
      if (fetchRes.status === 429) {
        return res.status(429).json({ error: 'Rate limit', message: 'API rate limit reached. Please try again later.' });
      }
      return res.status(502).json({ error: 'Upstream error', message: `RapidAPI returned ${fetchRes.status}.` });
    }

    const json = (await fetchRes.json()) as RapidLiveResponse;

    if (!json.status || !json.data) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'Train not found or not running on this date.',
      });
    }

    const d = json.data;

    // Normalise train identity
    const trainNumber = String(d.train_number ?? d.trainNo ?? train);
    const trainName   = String(d.train_name   ?? d.trainName ?? '');
    const runningDate = String(d.train_start_date ?? d.runDate ?? date);
    const currentStation = d.current_station_code ?? d.currentStation ?? undefined;
    const delayMinutes = Number(d.delay ?? 0);

    // Normalise station list — try multiple possible field names
    const rawStations = (
      d.trainStations ??
      (d as Record<string, unknown>)['stations'] ??
      (d as Record<string, unknown>)['station_list'] ??
      (d as Record<string, unknown>)['stationList'] ??
      []
    ) as RapidStation[];
    const stations = rawStations.map((s) => {
      const hasDeparted = s.has_departed === true;
      const hasArrived  = s.has_arrived  === true;
      const isCurrent   = s.isCurrent    === true;

      let status: 'departed' | 'arrived' | 'upcoming';
      if (hasDeparted) status = 'departed';
      else if (hasArrived || isCurrent) status = 'arrived';
      else status = 'upcoming';

      return {
        stationCode:        String(s.station_code ?? s.stationCode ?? ''),
        stationName:        String(s.station_name ?? s.stationName ?? ''),
        scheduledArrival:   String(s.scharr  ?? s.arrivalTime  ?? '--'),
        scheduledDeparture: String(s.schdep  ?? s.departureTime ?? '--'),
        actualArrival:      s.actarr ?? s.actualArrivalTime   ?? undefined,
        actualDeparture:    s.actdep ?? s.actualDepartureTime ?? undefined,
        delayMinutes:       Number(s.latemin ?? s.delayInArrival ?? s.delayInDeparture ?? 0),
        platform:           s.pfno != null ? String(s.pfno) : (s.platform != null ? String(s.platform) : undefined),
        status,
      };
    });

    return res.json({
      trainNumber,
      trainName,
      runningDate,
      currentStation,
      delayMinutes,
      stations,
      raw: d,
    });
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort') || msg.includes('signal')) {
      return res.status(504).json({ error: 'Timeout', message: 'Request timed out. Please try again.' });
    }
    console.error('live-status handler error:', err);
    return res.status(500).json({ error: 'Internal error', message: 'Failed to fetch live status. Please try again.' });
  }
}
