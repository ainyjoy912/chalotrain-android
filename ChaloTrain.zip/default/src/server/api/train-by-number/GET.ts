/**
 * GET /api/train-by-number?q=NDLS
 *
 * Treats `q` as a station code and calls getTrainsByStation on
 * irctc1.p.rapidapi.com. Returns the raw `data` array from the API.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

interface RapidApiTrainResponse {
  status: boolean;
  message?: string;
  data?: unknown[];
}

export default async function handler(req: Request, res: Response) {
  const { q } = req.query;

  if (!q || typeof q !== 'string' || q.trim().length < 2) {
    return res.status(400).json({
      error: 'Missing parameter',
      message: 'Query parameter "q" is required (station code, min 2 chars).',
    });
  }

  const apiKey = getSecret('RAPIDAPI_KEY');
  if (!apiKey) {
    return res.status(503).json({
      error: 'Configuration error',
      message: 'RAPIDAPI_KEY secret is not configured.',
    });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);

  try {
    const url = `https://irctc1.p.rapidapi.com/api/v3/getTrainsByStation?stationCode=${encodeURIComponent(q.trim().toUpperCase())}`;

    const fetchRes = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': String(apiKey),
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('RapidAPI error', fetchRes.status, text);
      return res.status(502).json({
        error: 'Upstream error',
        message: `RapidAPI returned ${fetchRes.status}.`,
      });
    }

    const json = (await fetchRes.json()) as RapidApiTrainResponse;

    if (!json.status) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'No trains found for this station code.',
      });
    }

    return res.json({
      success: true,
      stationCode: q.trim().toUpperCase(),
      data: json.data ?? [],
    });
  } catch (err) {
    clearTimeout(timer);
    console.error('train-by-number handler error:', err);
    return res.status(500).json({
      error: 'Internal error',
      message: 'Failed to fetch train data. Please try again.',
    });
  }
}
