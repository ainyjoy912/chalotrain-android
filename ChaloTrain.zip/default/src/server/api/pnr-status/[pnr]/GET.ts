/**
 * GET /api/pnr-status/:pnr
 *
 * Calls irctc1.p.rapidapi.com getPNRStatus and normalises the response
 * into the PNRStatusResponse shape expected by the frontend.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

interface RapidPNRData {
  Pnr?: string;
  TrainNo?: string;
  TrainName?: string;
  SourceDnCode?: string;
  DestDnCode?: string;
  Doj?: string;
  ChartPrepared?: boolean;
  PassengerCount?: number;
  PassengerStatus?: Array<{
    Number?: number;
    BookingStatus?: string;
    CurrentStatus?: string;
    BookingCoachId?: string;
    BookingBerthNo?: number;
    CoachId?: string;
    BerthNo?: number;
    [key: string]: unknown;
  }>;
  [key: string]: unknown;
}

interface RapidPNRResponse {
  status: boolean;
  message?: string;
  data?: RapidPNRData;
}

export default async function handler(req: Request, res: Response) {
  const { pnr } = req.params as { pnr: string };

  if (!pnr || !/^\d{10}$/.test(pnr)) {
    return res.status(400).json({
      error: 'Invalid PNR',
      message: 'PNR number must be exactly 10 digits.',
    });
  }

  const apiKey = String(getSecret('RAPIDAPI_KEY') ?? '');
  if (!apiKey) {
    return res.status(503).json({ error: 'Configuration error', message: 'RAPIDAPI_KEY is not configured.' });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const url = `https://irctc1.p.rapidapi.com/api/v3/getPNRStatus?pnrNumber=${encodeURIComponent(pnr)}`;

    const fetchRes: Awaited<ReturnType<typeof fetch>> = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': apiKey,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('PNR RapidAPI error', fetchRes.status, text);
      if (fetchRes.status === 429) {
        return res.status(429).json({ error: 'Rate limit', message: 'API rate limit reached. Please try again later.' });
      }
      return res.status(502).json({ error: 'Upstream error', message: `RapidAPI returned ${fetchRes.status}.` });
    }

    const json = (await fetchRes.json()) as RapidPNRResponse;

    if (!json.status || !json.data) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'PNR not found or invalid.',
      });
    }

    const d = json.data;

    // Normalise passengers
    const passengers = (d.PassengerStatus ?? []).map((p) => ({
      passengerNumber: p.Number ?? 0,
      bookingStatus: p.BookingStatus ?? '',
      currentStatus: p.CurrentStatus ?? '',
      coach: p.CoachId ?? p.BookingCoachId ?? undefined,
      berth: p.BerthNo != null ? String(p.BerthNo) : (p.BookingBerthNo != null ? String(p.BookingBerthNo) : undefined),
    }));

    return res.json({
      pnr: d.Pnr ?? pnr,
      trainNumber: d.TrainNo ?? '',
      trainName: d.TrainName ?? '',
      from: d.SourceDnCode ?? '',
      to: d.DestDnCode ?? '',
      dateOfJourney: d.Doj ?? '',
      chartPrepared: d.ChartPrepared ?? false,
      passengers,
      raw: d,
    });
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort') || msg.includes('signal')) {
      return res.status(504).json({ error: 'Timeout', message: 'Request timed out. Please try again.' });
    }
    console.error('pnr-status handler error:', err);
    return res.status(500).json({ error: 'Internal error', message: 'Failed to fetch PNR status. Please try again.' });
  }
}
