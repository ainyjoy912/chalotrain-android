/**
 * GET /api/seat-availability?train=12301&from=HWH&to=NDLS&date=YYYY-MM-DD&class=3A&quota=GN
 *
 * Calls irctc1.p.rapidapi.com checkSeatAvailability and normalises the
 * response into the SeatAvailabilityResponse shape expected by the frontend.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

const STATION_CODE_RE = /^[A-Z0-9]{2,7}$/;

interface RapidSeatEntry {
  date?: string;
  availability?: string;
  [key: string]: unknown;
}

interface RapidSeatData {
  trainNumber?: string;
  trainName?: string;
  fromStation?: string;
  toStation?: string;
  classType?: string;
  quota?: string;
  availability?: RapidSeatEntry[];
  [key: string]: unknown;
}

interface RapidSeatResponse {
  status: boolean;
  message?: string;
  data?: RapidSeatData | RapidSeatEntry[];
}

export default async function handler(req: Request, res: Response) {
  const { train, from, to, date, class: classCode, quota } = req.query;

  if (!train || typeof train !== 'string' || !/^\d{5}$/.test(train)) {
    return res.status(400).json({ error: 'Invalid parameter', message: 'Train number must be exactly 5 digits.' });
  }
  if (!from || typeof from !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Source station code is required.' });
  }
  if (!to || typeof to !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Destination station code is required.' });
  }
  if (!date || typeof date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return res.status(400).json({ error: 'Invalid parameter', message: 'Date must be in YYYY-MM-DD format.' });
  }
  if (!classCode || typeof classCode !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Class code is required (e.g. SL, 3A, 2A).' });
  }
  if (!quota || typeof quota !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Quota is required (e.g. GN, TQ, PT).' });
  }

  const fromUC = from.toUpperCase();
  const toUC = to.toUpperCase();
  const classUC = classCode.toUpperCase();
  const quotaUC = quota.toUpperCase();

  if (!STATION_CODE_RE.test(fromUC)) {
    return res.status(400).json({ error: 'Invalid station code', message: `Invalid source station code "${fromUC}".` });
  }
  if (!STATION_CODE_RE.test(toUC)) {
    return res.status(400).json({ error: 'Invalid station code', message: `Invalid destination station code "${toUC}".` });
  }

  const apiKey = String(getSecret('RAPIDAPI_KEY') ?? '');
  if (!apiKey) {
    return res.status(503).json({ error: 'Configuration error', message: 'RAPIDAPI_KEY is not configured.' });
  }

  // Convert YYYY-MM-DD → YYYYMMDD for RapidAPI
  const dateFormatted = date.replace(/-/g, '');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    const url = `https://irctc1.p.rapidapi.com/api/v1/checkSeatAvailability?classType=${encodeURIComponent(classUC)}&fromStationCode=${encodeURIComponent(fromUC)}&quota=${encodeURIComponent(quotaUC)}&toStationCode=${encodeURIComponent(toUC)}&trainNo=${encodeURIComponent(train)}&date=${dateFormatted}`;

    const fetchRes: Awaited<ReturnType<typeof fetch>> = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': apiKey,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('Seat availability RapidAPI error', fetchRes.status, text);
      if (fetchRes.status === 429) {
        return res.status(429).json({ error: 'Rate limit', message: 'API rate limit reached. Please try again later.' });
      }
      return res.status(502).json({ error: 'Upstream error', message: `RapidAPI returned ${fetchRes.status}.` });
    }

    const json = (await fetchRes.json()) as RapidSeatResponse;

    if (!json.status || !json.data) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'No availability data found for this train/class/date combination.',
      });
    }

    // data can be an array of availability entries or an object with nested availability
    let availabilityList: Array<{ date: string; status: string }> = [];

    if (Array.isArray(json.data)) {
      availabilityList = json.data.map((entry) => ({
        date: String(entry.date ?? ''),
        status: String(entry.availability ?? 'N/A'),
      }));
    } else {
      const d = json.data as RapidSeatData;
      const entries = d.availability ?? [];
      availabilityList = entries.map((entry) => ({
        date: String(entry.date ?? ''),
        status: String(entry.availability ?? 'N/A'),
      }));
    }

    const dataObj = Array.isArray(json.data) ? {} : json.data as RapidSeatData;

    return res.json({
      trainNumber: dataObj.trainNumber ?? train,
      trainName: dataObj.trainName ?? '',
      from: fromUC,
      to: toUC,
      class: classUC,
      quota: quotaUC,
      availability: availabilityList,
      raw: json.data,
    });
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort') || msg.includes('signal')) {
      return res.status(504).json({ error: 'Timeout', message: 'Request timed out. Please try again.' });
    }
    console.error('seat-availability handler error:', err);
    return res.status(500).json({ error: 'Internal error', message: 'Failed to check seat availability. Please try again.' });
  }
}
