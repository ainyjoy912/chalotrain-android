/**
 * GET /api/fare-inquiry?train=12301&from=HWH&to=NDLS&class=3A&quota=GN
 *
 * Calls irctc1.p.rapidapi.com getTrainFare and normalises the response
 * into the FareInquiryResponse shape expected by the frontend.
 */

import type { Request, Response } from 'express';
import { getSecret } from '#airo/secrets';

const STATION_CODE_RE = /^[A-Z0-9]{2,7}$/;

interface RapidFareClass {
  classType?: string;
  fare?: number;
  tatkalFare?: number;
  [key: string]: unknown;
}

interface RapidFareData {
  trainNumber?: string;
  trainName?: string;
  fromStation?: string;
  toStation?: string;
  distance?: number;
  fareDetails?: RapidFareClass[];
  [key: string]: unknown;
}

interface RapidFareResponse {
  status: boolean;
  message?: string;
  data?: RapidFareData | RapidFareClass[];
}

export default async function handler(req: Request, res: Response) {
  const { train, from, to, class: classCode, quota } = req.query;

  if (!train || typeof train !== 'string' || !/^\d{5}$/.test(train)) {
    return res.status(400).json({ error: 'Invalid parameter', message: 'Train number must be exactly 5 digits.' });
  }
  if (!from || typeof from !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Source station code is required.' });
  }
  if (!to || typeof to !== 'string') {
    return res.status(400).json({ error: 'Missing parameter', message: 'Destination station code is required.' });
  }

  const fromUC = from.toUpperCase();
  const toUC = to.toUpperCase();
  const classUC = typeof classCode === 'string' ? classCode.toUpperCase() : '';
  const quotaUC = typeof quota === 'string' ? quota.toUpperCase() : 'GN';

  if (!STATION_CODE_RE.test(fromUC)) {
    return res.status(400).json({ error: 'Invalid station code', message: `Invalid source station code "${fromUC}".` });
  }
  if (!STATION_CODE_RE.test(toUC)) {
    return res.status(400).json({ error: 'Invalid station code', message: `Invalid destination station code "${toUC}".` });
  }

  const apiKey = String(getSecret('RAPIDAPI_KEY') ?? '');
  if (!apiKey) {
    return res.status(503).json({ error: 'Configuration error', message: 'RAPIDAPI_KEY is not configured.' });
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);

  try {
    // Build URL — classType and quota are optional for fare inquiry (returns all classes)
    let url = `https://irctc1.p.rapidapi.com/api/v3/getTrainFare?trainNo=${encodeURIComponent(train)}&fromStationCode=${encodeURIComponent(fromUC)}&toStationCode=${encodeURIComponent(toUC)}`;
    if (classUC) url += `&classType=${encodeURIComponent(classUC)}`;
    if (quotaUC) url += `&quota=${encodeURIComponent(quotaUC)}`;

    const fetchRes: Awaited<ReturnType<typeof fetch>> = await fetch(url, {
      method: 'GET',
      headers: new Headers({
        'x-rapidapi-host': 'irctc1.p.rapidapi.com',
        'x-rapidapi-key': apiKey,
      }),
      signal: controller.signal,
    });

    clearTimeout(timer);

    if (!fetchRes.ok) {
      const text = await fetchRes.text();
      console.error('Fare inquiry RapidAPI error', fetchRes.status, text);
      if (fetchRes.status === 429) {
        return res.status(429).json({ error: 'Rate limit', message: 'API rate limit reached. Please try again later.' });
      }
      return res.status(502).json({ error: 'Upstream error', message: `RapidAPI returned ${fetchRes.status}.` });
    }

    const json = (await fetchRes.json()) as RapidFareResponse;

    if (!json.status || !json.data) {
      return res.status(404).json({
        error: 'Not found',
        message: json.message ?? 'Fare information not found for this route.',
      });
    }

    // data can be an array of fare entries or an object with fareDetails
    let fares: Array<{ class: string; fare: number; tatkalFare: number }> = [];

    if (Array.isArray(json.data)) {
      fares = json.data.map((f) => ({
        class: f.classType ?? '',
        fare: f.fare ?? 0,
        tatkalFare: f.tatkalFare ?? 0,
      }));
    } else {
      const d = json.data as RapidFareData;
      fares = (d.fareDetails ?? []).map((f) => ({
        class: f.classType ?? '',
        fare: f.fare ?? 0,
        tatkalFare: f.tatkalFare ?? 0,
      }));
    }

    const dataObj = Array.isArray(json.data) ? {} : json.data as RapidFareData;

    return res.json({
      trainNumber: dataObj.trainNumber ?? train,
      trainName: dataObj.trainName ?? '',
      from: fromUC,
      to: toUC,
      distance: dataObj.distance ?? 0,
      fares,
      raw: json.data,
    });
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes('abort') || msg.includes('signal')) {
      return res.status(504).json({ error: 'Timeout', message: 'Request timed out. Please try again.' });
    }
    console.error('fare-inquiry handler error:', err);
    return res.status(500).json({ error: 'Internal error', message: 'Failed to fetch fare information. Please try again.' });
  }
}
