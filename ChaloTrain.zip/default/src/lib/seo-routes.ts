/**
 * Agent-editable registry of publicly-crawlable routes. Consumed by the
 * /sitemap.xml handler in src/server/entry.ts.
 *
 * Guidelines for maintaining this file:
 * - Add a new entry whenever you add a new publicly-crawlable page.
 * - Do not include dynamic-param routes like "/products/:id" directly.
 *   Instead, enumerate real values (e.g. "/products/desk-pro") or skip.
 * - `path` MUST start with "/".
 * - Priorities are between 0.0 and 1.0. Home = 1.0, main sections = 0.8,
 *   deep pages = 0.5.
 * - Dev-only or auth-required routes MUST NOT be listed.
 */

export interface SeoRoute {
	path: string;
	changefreq?:
		| "always"
		| "hourly"
		| "daily"
		| "weekly"
		| "monthly"
		| "yearly"
		| "never";
	priority?: number;
	lastmod?: string;
}

export const seoRoutes: SeoRoute[] = [
	// Core tools
	{ path: "/", changefreq: "daily", priority: 1.0, lastmod: "2026-06-24" },
	{ path: "/pnr-status", changefreq: "daily", priority: 0.9, lastmod: "2026-06-24" },
	{ path: "/live-status", changefreq: "daily", priority: 0.9, lastmod: "2026-06-24" },
	{ path: "/train-search", changefreq: "daily", priority: 0.9, lastmod: "2026-06-24" },
	{ path: "/seat-availability", changefreq: "daily", priority: 0.9, lastmod: "2026-06-24" },
	{ path: "/train-schedule", changefreq: "weekly", priority: 0.8, lastmod: "2026-06-24" },
	{ path: "/fare-inquiry", changefreq: "weekly", priority: 0.8, lastmod: "2026-06-24" },
	// Static pages
	{ path: "/about", changefreq: "monthly", priority: 0.6, lastmod: "2026-06-24" },
	{ path: "/contact", changefreq: "monthly", priority: 0.6, lastmod: "2026-06-24" },
	{ path: "/privacy", changefreq: "monthly", priority: 0.4, lastmod: "2026-06-24" },
	{ path: "/terms", changefreq: "monthly", priority: 0.4, lastmod: "2026-06-24" },
	{ path: "/disclaimer", changefreq: "monthly", priority: 0.4, lastmod: "2026-06-24" },
	// Blog index
	{ path: "/blog", changefreq: "weekly", priority: 0.8, lastmod: "2026-06-24" },
	// Original blog articles
	{ path: "/blog/how-to-check-pnr-status-online", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/tatkal-ticket-booking-tips", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/how-to-get-confirmed-train-ticket", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/why-trains-run-late-in-india", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/irctc-booking-guide-for-beginners", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/indian-railway-classes-guide", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/train-ticket-cancellation-refund-rules", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	{ path: "/blog/how-to-book-train-tickets-online", changefreq: "monthly", priority: 0.7, lastmod: "2026-04-01" },
	// New blog articles (May 2026)
	{ path: "/blog/how-to-check-pnr-status-online-guide", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/irctc-complete-booking-guide", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/train-travel-tips-for-beginners", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/how-to-read-train-ticket", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/how-to-check-seat-availability", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/how-to-file-tdr", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/best-trains-delhi-to-mumbai", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/how-to-track-live-train-status", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/tatkal-ticket-booking-complete-guide", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
	{ path: "/blog/how-to-check-train-schedule", changefreq: "monthly", priority: 0.7, lastmod: "2026-05-21" },
];
