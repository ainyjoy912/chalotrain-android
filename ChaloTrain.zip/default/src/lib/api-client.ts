/**
 * API Client for ChaloTrain Backend Integration
 *
 * Type-safe fetch wrappers for all 6 railway tool endpoints.
 * All requests are proxied through the Express backend — API keys
 * never reach the browser.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface PNRStatusResponse {
  pnr: string;
  trainNumber: string;
  trainName: string;
  from: string;
  to: string;
  dateOfJourney: string;
  chartPrepared: boolean;
  passengers: Array<{
    passengerNumber: number;
    name: string;
    age: number;
    gender: 'M' | 'F' | 'T';
    bookingStatus: string;
    currentStatus: string;
    coach?: string;
    berth?: string;
  }>;
}

export interface LiveTrainStatusResponse {
  trainNumber: string;
  trainName: string;
  runningDate: string;
  currentStation?: string;
  delayMinutes: number;
  stations: Array<{
    stationCode: string;
    stationName: string;
    scheduledArrival: string;
    scheduledDeparture: string;
    actualArrival?: string;
    actualDeparture?: string;
    delayMinutes: number;
    platform?: string;
    status: 'departed' | 'arrived' | 'upcoming';
  }>;
}

export interface TrainSearchResponse {
  from: string;
  to: string;
  date: string;
  trains: Array<{
    trainNumber: string;
    trainName: string;
    trainType: string;
    departure: string;
    arrival: string;
    duration: string;
    daysOfWeek: string[];
    availability: Record<string, string>; // class -> status (AVAILABLE, RAC, WL, etc.)
  }>;
}

export interface SeatAvailabilityResponse {
  trainNumber: string;
  trainName: string;
  from: string;
  to: string;
  class: string;
  quota: string;
  availability: Array<{
    date: string;
    status: string; // AVAILABLE-123, RAC-5, WL-45, REGRET
  }>;
}

export interface TrainScheduleResponse {
  trainNumber: string;
  trainName: string;
  trainType: string;
  stations: Array<{
    stationCode: string;
    stationName: string;
    arrival: string;
    departure: string;
    halt: string;
    platform?: string;
    distance: number;
    day: number;
    zone: string;
  }>;
}

export interface FareInquiryResponse {
  trainNumber: string;
  trainName: string;
  from: string;
  to: string;
  distance: number;
  fares: Array<{
    class: string;
    fare: number;
    tatkalFare: number;
  }>;
}

export interface TrainsByStationResponse {
  success: boolean;
  stationCode: string;
  data: Array<{
    trainNumber: string;
    trainName: string;
    trainType?: string;
    arrivalTime?: string;
    departureTime?: string;
    haltTime?: string;
    distance?: number;
    day?: number;
    source?: string;
    destination?: string;
    [key: string]: unknown;
  }>;
}

export interface APIError {
  error: string;
  message: string;
  statusCode?: number;
}

// ── API Functions ─────────────────────────────────────────────────────────────

/**
 * API Base URL - Configure in environment variables
 * Development: Set VITE_API_BASE_URL in .env.development
 * Production: Set API_BASE_URL in platform environment variables
 */
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

/**
 * Check PNR Status
 * @param pnr - 10-digit PNR number
 */
export async function checkPNRStatus(pnr: string): Promise<PNRStatusResponse> {
  const response = await fetch(`${API_BASE_URL}/pnr-status/${pnr}`);
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to fetch PNR status' }));
    throw new Error(error.message || 'Failed to fetch PNR status');
  }
  return response.json();
}

/**
 * Get Live Train Status
 * @param trainNumber - Train number
 * @param date - Journey date (YYYY-MM-DD)
 */
export async function getLiveTrainStatus(trainNumber: string, date: string): Promise<LiveTrainStatusResponse> {
  const response = await fetch(`${API_BASE_URL}/live-status?train=${trainNumber}&date=${date}`);
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to fetch live status' }));
    throw new Error(error.message || 'Failed to fetch live status');
  }
  return response.json();
}

/**
 * Search Trains Between Stations
 * @param from - Source station code
 * @param to - Destination station code
 * @param date - Journey date (YYYY-MM-DD)
 * @param quota - Booking quota (optional)
 */
export async function searchTrains(from: string, to: string, date: string, quota?: string): Promise<TrainSearchResponse> {
  const url = new URL(`${API_BASE_URL}/train-search`, window.location.origin);
  url.searchParams.set('from', from);
  url.searchParams.set('to', to);
  url.searchParams.set('date', date);
  if (quota) url.searchParams.set('quota', quota);
  const response = await fetch(url.toString());
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to search trains' }));
    throw new Error(error.message || 'Failed to search trains');
  }
  return response.json();
}

/**
 * Check Seat Availability
 * @param trainNumber - Train number
 * @param from - Source station code
 * @param to - Destination station code
 * @param date - Journey date (YYYY-MM-DD)
 * @param classCode - Travel class (1A, 2A, 3A, SL, etc.)
 * @param quota - Booking quota
 */
export async function checkSeatAvailability(
  trainNumber: string,
  from: string,
  to: string,
  date: string,
  classCode: string,
  quota: string
): Promise<SeatAvailabilityResponse> {
  const url = new URL(`${API_BASE_URL}/seat-availability`, window.location.origin);
  url.searchParams.set('train', trainNumber);
  url.searchParams.set('from', from);
  url.searchParams.set('to', to);
  url.searchParams.set('date', date);
  url.searchParams.set('class', classCode);
  url.searchParams.set('quota', quota);
  const response = await fetch(url.toString());
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to check availability' }));
    throw new Error(error.message || 'Failed to check availability');
  }
  return response.json();
}

/**
 * Get Train Schedule
 * @param trainNumber - Train number
 */
export async function getTrainSchedule(trainNumber: string): Promise<TrainScheduleResponse> {
  const response = await fetch(`${API_BASE_URL}/train-schedule/${trainNumber}`);
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to fetch schedule' }));
    throw new Error(error.message || 'Failed to fetch schedule');
  }
  return response.json();
}

/**
 * Get Fare Inquiry
 * @param trainNumber - Train number
 * @param from - Source station code
 * @param to - Destination station code
 * @param classCode - Travel class
 * @param quota - Booking quota
 */
export async function getFareInquiry(
  trainNumber: string,
  from: string,
  to: string,
  classCode: string,
  quota: string
): Promise<FareInquiryResponse> {
  const url = new URL(`${API_BASE_URL}/fare-inquiry`, window.location.origin);
  url.searchParams.set('train', trainNumber);
  url.searchParams.set('from', from);
  url.searchParams.set('to', to);
  url.searchParams.set('class', classCode);
  url.searchParams.set('quota', quota);
  const response = await fetch(url.toString());
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to fetch fare' }));
    throw new Error(error.message || 'Failed to fetch fare');
  }
  return response.json();
}

/**
 * Get Trains by Station Code
 * Calls /api/train-by-number?q=STATION_CODE → irctc1.p.rapidapi.com getTrainsByStation
 * @param stationCode - Station code (e.g. NDLS, KNP, HWH)
 */
export async function getTrainsByStation(stationCode: string): Promise<TrainsByStationResponse> {
  const url = new URL(`${API_BASE_URL}/train-by-number`, window.location.origin);
  url.searchParams.set('q', stationCode.trim().toUpperCase());
  const response = await fetch(url.toString());
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to fetch trains for station' }));
    throw new Error(error.message || 'Failed to fetch trains for station');
  }
  return response.json();
}

// ── Validation Helpers ────────────────────────────────────────────────────────

export function validatePNR(pnr: string): { valid: boolean; error?: string } {
  if (!pnr) return { valid: false, error: 'PNR number is required' };
  if (!/^\d{10}$/.test(pnr)) return { valid: false, error: 'PNR must be exactly 10 digits' };
  return { valid: true };
}

export function validateTrainNumber(trainNumber: string): { valid: boolean; error?: string } {
  if (!trainNumber) return { valid: false, error: 'Train number is required' };
  if (!/^\d{5}$/.test(trainNumber)) return { valid: false, error: 'Train number must be 5 digits' };
  return { valid: true };
}

export function validateStationCode(code: string): { valid: boolean; error?: string } {
  if (!code) return { valid: false, error: 'Station code is required' };
  // Indian station codes are 2–7 alphanumeric characters (e.g. NDLS, BCT, MAS, CSTM, ANVT)
  if (!/^[A-Z0-9]{2,7}$/.test(code.toUpperCase())) return { valid: false, error: 'Invalid station code (2–7 letters/digits, e.g. NDLS, BCT)' };
  return { valid: true };
}

export function validateDate(date: string): { valid: boolean; error?: string } {
  if (!date) return { valid: false, error: 'Date is required' };
  const dateObj = new Date(date);
  if (isNaN(dateObj.getTime())) return { valid: false, error: 'Invalid date format' };
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (dateObj < today) return { valid: false, error: 'Date cannot be in the past' };
  return { valid: true };
}
