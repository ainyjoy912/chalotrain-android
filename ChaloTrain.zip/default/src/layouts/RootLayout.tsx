import { type ReactElement } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';

import Footer from '@/layouts/parts/Footer';
import Header from '@/layouts/parts/Header';
import Website from '@/layouts/Website';
import WhatsAppFloat from '@/components/WhatsAppFloat';

const orgJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'ChaloTrain',
  url: 'https://chalotrain.com',
  logo: 'https://chalotrain.com/og-image.png',
  sameAs: [
    'https://instagram.com/chalotrainofficial',
    'https://x.com/chalotrain',
  ],
  contactPoint: {
    '@type': 'ContactPoint',
    email: 'chalotrain@chalotrain.com',
    contactType: 'customer support',
    availableLanguage: ['English', 'Hindi'],
  },
};

const websiteJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: 'ChaloTrain',
  url: 'https://chalotrain.com',
  description: "India's fastest railway information portal — PNR status, live train tracking, train search, seat availability, schedule and fare inquiry.",
  potentialAction: {
    '@type': 'SearchAction',
    target: { '@type': 'EntryPoint', urlTemplate: 'https://chalotrain.com/train-search?from={from}&to={to}' },
    'query-input': 'required name=from required name=to',
  },
};

/**
 * Root layout component that wraps all pages with consistent header and footer
 *
 * This component provides a centralized layout structure for the entire application,
 * ensuring consistent navigation and footer across all pages. It uses the Website
 * layout component and includes Header and Footer components.
 *
 * To customize the header or footer, directly edit the Header.tsx and Footer.tsx files
 * in the layouts/parts directory.
 *
 * @param children - Child routes to render (typically <Outlet /> from react-router-dom)
 *
 * @example
 * ```tsx
 * <RootLayout>
 *   <Outlet />
 * </RootLayout>
 * ```
 */
interface RootLayoutProps {
  children: ReactElement;
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <Website>
      <Helmet>
        <title>ChaloTrain — PNR Status, Live Train Tracking & Railway Information</title>
        <meta name="description" content="Check PNR status, live train running status, trains between stations, seat availability, train schedule and fare — free on ChaloTrain." />
        <meta name="robots" content="index, follow" />
        <script type="application/ld+json">{JSON.stringify(orgJsonLd)}</script>
        <script type="application/ld+json">{JSON.stringify(websiteJsonLd)}</script>
      </Helmet>
      <Header />
      {children}
      <Footer />
      <WhatsAppFloat />
    </Website>
  );
}
