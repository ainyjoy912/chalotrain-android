import { Link } from 'react-router-dom';
import { Train, MapPin, Phone, Mail } from 'lucide-react';

const InstagramIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
  </svg>
);
const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-[#070d1f] text-slate-400">

      {/* ── Main Grid ── */}
      <div className="container mx-auto px-4 pt-12 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">

          {/* Brand + Contact */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4" aria-label="ChaloTrain Home">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
                <Train size={16} className="text-white" />
              </div>
              <span className="text-lg font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                Chalo<span className="text-accent">Train</span>
              </span>
            </Link>
            <p className="text-sm text-slate-400 leading-relaxed mb-5">
              An independent railway information platform operated by ChaloTrain Technologies Private Limited. Not affiliated with IRCTC or Indian Railways.
            </p>
            <div className="flex flex-col gap-2 text-sm">
              <a href="mailto:chalotrain@chalotrain.com" className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
                <Mail size={13} className="text-accent shrink-0" />
                chalotrain@chalotrain.com
              </a>
              <a href="tel:+919170477270" className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
                <Phone size={13} className="text-accent shrink-0" />
                +91 91704 77270
              </a>
              <span className="flex items-start gap-2 text-slate-500">
                <MapPin size={13} className="text-accent shrink-0 mt-0.5" />
                <span className="leading-snug text-xs">C/o Saiyyad Haidar Ali, Data Bahar Shah Takiya, Ragaul Tahsil, Hamirpur, UP — 210507</span>
              </span>
            </div>
          </div>

          {/* Train Tools */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
              Train Tools
            </h4>
            <ul className="flex flex-col gap-2">
              {[
                { href: '/pnr-status',        label: 'PNR Status'             },
                { href: '/live-status',       label: 'Live Train Status'      },
                { href: '/train-search',      label: 'Train Between Stations' },
                { href: '/seat-availability', label: 'Seat Availability'      },
                { href: '/train-schedule',    label: 'Train Schedule'         },
                { href: '/fare-inquiry',      label: 'Fare Inquiry'           },
              ].map((item) => (
                <li key={item.href}>
                  <Link to={item.href} className="text-sm text-slate-400 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
              Company
            </h4>
            <ul className="flex flex-col gap-2 mb-6">
              {[
                { href: '/',        label: 'Home'       },
                { href: '/about',   label: 'About Us'   },
                { href: '/blog',    label: 'Blog'       },
                { href: '/contact', label: 'Contact Us' },
              ].map((item) => (
                <li key={item.href}>
                  <Link to={item.href} className="text-sm text-slate-400 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Follow Us */}
            <h4 className="text-white font-semibold mb-3 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
              Follow Us
            </h4>
            <div className="flex items-center gap-2">
              <a href="https://instagram.com/chalotrainofficial" target="_blank" rel="noopener noreferrer" aria-label="ChaloTrain on Instagram"
                className="w-9 h-9 flex items-center justify-center rounded-lg bg-white/6 border border-white/10 text-slate-400 hover:bg-gradient-to-br hover:from-purple-500 hover:to-pink-500 hover:text-white hover:border-transparent transition-all duration-200">
                <InstagramIcon />
              </a>
              <a href="https://wa.me/919170477270?text=Hi%20I%20need%20help%20with%20train%20info" target="_blank" rel="noopener noreferrer" aria-label="ChaloTrain on WhatsApp"
                className="w-9 h-9 flex items-center justify-center rounded-lg bg-white/6 border border-white/10 text-slate-400 hover:bg-[#25D366] hover:text-white hover:border-transparent transition-all duration-200">
                <WhatsAppIcon />
              </a>
            </div>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm" style={{ fontFamily: 'var(--font-heading)' }}>
              Legal
            </h4>
            <ul className="flex flex-col gap-2">
              {[
                { href: '/privacy',    label: 'Privacy Policy'   },
                { href: '/terms',      label: 'Terms of Service' },
                { href: '/disclaimer', label: 'Disclaimer'       },
              ].map((item) => (
                <li key={item.href}>
                  <Link to={item.href} className="text-sm text-slate-400 hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
              <li>
                <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer" className="text-sm text-slate-400 hover:text-white transition-colors">
                  Sitemap
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Independence disclaimer */}
        <div className="mt-8 p-4 bg-white/4 border border-white/6 rounded-xl">
          <p className="text-xs text-slate-500 leading-relaxed text-center">
            ChaloTrain is an independent railway information platform operated by <strong className="text-slate-400">ChaloTrain Technologies Private Limited</strong>. We are not affiliated with, endorsed by, or connected to IRCTC, Indian Railways, or any government body. All information is for general reference only. For official bookings and authoritative data, please use <a href="https://www.irctc.co.in" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-white underline">irctc.co.in</a>.
          </p>
        </div>

        {/* Bottom bar */}
        <div className="mt-6 pt-5 border-t border-white/6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-xs text-slate-600">© {year} ChaloTrain Technologies Private Limited. All rights reserved.</p>
          <div className="flex items-center gap-1 text-xs text-slate-600">
            <span>Made with</span>
            <span className="text-accent">♥</span>
            <span>for Indian Travelers</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
