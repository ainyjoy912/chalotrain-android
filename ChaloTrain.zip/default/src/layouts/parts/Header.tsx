import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Train, ChevronDown } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

// ── Social SVGs ───────────────────────────────────────────────────────────────
const InstagramIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-[15px] h-[15px]">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
  </svg>
);
const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-[15px] h-[15px]">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

const toolLinks = [
  { href: '/pnr-status',        label: 'PNR Status',             desc: 'Check booking confirmation', dot: 'bg-blue-500'   },
  { href: '/live-status',       label: 'Live Train Status',      desc: 'Track train running status', dot: 'bg-green-500'  },
  { href: '/train-search',      label: 'Train Between Stations', desc: 'Find trains on any route',   dot: 'bg-sky-500'    },
  { href: '/seat-availability', label: 'Seat Availability',      desc: 'Check class-wise seats',     dot: 'bg-violet-500' },
  { href: '/train-schedule',    label: 'Train Schedule',         desc: 'Full timetable & stops',     dot: 'bg-cyan-500'   },
  { href: '/fare-inquiry',      label: 'Fare Inquiry',           desc: 'Compare fares & classes',    dot: 'bg-orange-500' },
];

const navItems = [
  { href: '/',       label: 'Home'    },
  { href: '/blog',   label: 'Blog'    },
  { href: '/about',  label: 'About'   },
  { href: '/contact',label: 'Contact' },
];

export default function Header() {
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled]     = useState(false);
  const [toolsOpen, setToolsOpen]   = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    if (!toolsOpen) return;
    const handler = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setToolsOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [toolsOpen]);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileOpen(false);
    setToolsOpen(false);
  }, [location.pathname]);

  const isToolActive = toolLinks.some(t => location.pathname === t.href);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled
        ? 'bg-white/95 backdrop-blur-xl shadow-sm border-b border-slate-200'
        : 'bg-white/90 backdrop-blur-lg border-b border-slate-100'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex h-[60px] items-center justify-between gap-4">

          {/* ── Logo ── */}
          <Link to="/" className="flex items-center gap-2 shrink-0" aria-label="ChaloTrain Home">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
              <Train size={16} className="text-white" />
            </div>
            <span className="text-[1.15rem] font-bold tracking-tight leading-none" style={{ fontFamily: 'var(--font-heading)' }}>
              <span className="text-primary">Chalo</span><span className="text-accent">Train</span>
            </span>
          </Link>

          {/* ── Desktop Nav ── */}
          <nav className="hidden lg:flex items-center gap-0.5" aria-label="Main navigation">
            {navItems.map((item) => (
              <Link key={item.href} to={item.href}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-all duration-150 ${
                  location.pathname === item.href
                    ? 'text-primary bg-blue-50 font-semibold'
                    : 'text-slate-600 hover:text-primary hover:bg-slate-50'
                }`}
              >
                {item.label}
              </Link>
            ))}

            {/* Tools Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setToolsOpen(!toolsOpen)}
                aria-expanded={toolsOpen}
                aria-haspopup="true"
                className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg transition-all duration-150 ${
                  isToolActive || toolsOpen ? 'text-primary bg-blue-50 font-semibold' : 'text-slate-600 hover:text-primary hover:bg-slate-50'
                }`}
              >
                Tools
                <ChevronDown size={13} className={`transition-transform duration-200 ${toolsOpen ? 'rotate-180' : ''}`} />
              </button>

              {toolsOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-68 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden" role="menu">
                  <div className="px-3 py-2.5 bg-slate-50 border-b border-slate-100">
                    <div className="text-xs font-semibold text-slate-500">Railway Tools — All Free</div>
                  </div>
                  <div className="p-1.5">
                    {toolLinks.map((tool) => (
                      <Link key={tool.href} to={tool.href}
                        role="menuitem"
                        onClick={() => setToolsOpen(false)}
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-150 group ${
                          location.pathname === tool.href ? 'bg-blue-50' : 'hover:bg-slate-50'
                        }`}
                      >
                        <div className={`w-1.5 h-1.5 rounded-full ${tool.dot} shrink-0`} />
                        <div className="min-w-0">
                          <div className={`text-sm font-medium transition-colors ${location.pathname === tool.href ? 'text-primary' : 'text-slate-800 group-hover:text-primary'}`}>
                            {tool.label}
                          </div>
                          <div className="text-[11px] text-slate-400">{tool.desc}</div>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </nav>

          {/* ── Right: Social + CTA + Mobile toggle ── */}
          <div className="flex items-center gap-2">
            {/* Social icons — desktop only */}
            <div className="hidden md:flex items-center gap-0.5">
              <a href="https://instagram.com/chalotrainofficial" target="_blank" rel="noopener noreferrer" aria-label="ChaloTrain on Instagram"
                className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-pink-500 transition-colors">
                <InstagramIcon />
              </a>
              <a href="https://wa.me/919170477270?text=Hi%20I%20need%20help%20with%20train%20info" target="_blank" rel="noopener noreferrer" aria-label="ChaloTrain on WhatsApp"
                className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-green-500 transition-colors">
                <WhatsAppIcon />
              </a>
            </div>

            <Link to="/pnr-status"
              className="hidden md:inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white rounded-lg bg-primary hover:bg-primary/90 transition-colors"
            >
              <Train size={13} />
              Check PNR
            </Link>

            {/* Mobile hamburger */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-600"
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileOpen}
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* ── Mobile Drawer ── */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-slate-100 bg-white shadow-lg" role="dialog" aria-label="Mobile navigation">
          <nav className="container mx-auto px-4 py-3 flex flex-col gap-0.5" aria-label="Mobile navigation links">
            {/* Main nav links */}
            {navItems.map((item) => (
              <Link key={item.href} to={item.href}
                className={`px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                  location.pathname === item.href ? 'text-primary bg-blue-50 font-semibold' : 'text-slate-700 hover:text-primary hover:bg-slate-50'
                }`}
              >
                {item.label}
              </Link>
            ))}

            {/* Tools section — always expanded on mobile */}
            <div className="mt-1 pt-2 border-t border-slate-100">
              <div className="px-3 pb-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Railway Tools</div>
              <div className="grid grid-cols-2 gap-1">
                {toolLinks.map((tool) => (
                  <Link key={tool.href} to={tool.href}
                    className={`flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition-colors ${
                      location.pathname === tool.href ? 'text-primary font-semibold bg-blue-50' : 'text-slate-700 hover:text-primary hover:bg-slate-50'
                    }`}
                  >
                    <div className={`w-1.5 h-1.5 rounded-full ${tool.dot} shrink-0`} />
                    <span className="truncate">{tool.label}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* CTA + Social */}
            <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between gap-3">
              <Link to="/pnr-status"
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-bold text-white rounded-lg bg-primary hover:bg-primary/90 transition-colors"
              >
                <Train size={14} /> Check PNR Status
              </Link>
              <div className="flex items-center gap-1">
                <a href="https://instagram.com/chalotrainofficial" target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                  className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-400 hover:text-pink-500 hover:bg-slate-50 transition-colors">
                  <InstagramIcon />
                </a>
                <a href="https://wa.me/919170477270?text=Hi%20I%20need%20help%20with%20train%20info" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp"
                  className="w-9 h-9 flex items-center justify-center rounded-lg text-slate-400 hover:text-green-500 hover:bg-slate-50 transition-colors">
                  <WhatsAppIcon />
                </a>
              </div>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
