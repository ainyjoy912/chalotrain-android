/**
 * Generic debounced autocomplete hook with in-memory result caching.
 * Calls `fetcher(query)` after `delay` ms of inactivity.
 * Caches results per (cacheNs + query) key for `cacheTtlMs` (default 5 min)
 * to avoid redundant network calls when the user types the same prefix again.
 *
 * Pass a stable `cacheNs` (namespace) string to scope the cache per endpoint,
 * e.g. "flights-ac" or "hotels-ac". Defaults to "default".
 *
 * Returns { results, loading, error, query, setQuery, clear }.
 */
import { useState, useEffect, useRef, useCallback } from 'react';

// Module-level cache shared across all hook instances
const RESULT_CACHE = new Map<string, { data: unknown[]; expiresAt: number }>();

export function useAutocomplete<T>(
  fetcher: (q: string) => Promise<T[]>,
  delay = 220,
  cacheTtlMs = 5 * 60 * 1000,
  cacheNs = 'default',
) {
  const [query, setQuery]     = useState('');
  const [results, setResults] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);
  const timerRef    = useRef<ReturnType<typeof setTimeout> | null>(null);
  const loadTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef    = useRef<AbortController | null>(null);
  const fetcherRef  = useRef(fetcher);
  fetcherRef.current = fetcher;

  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (loadTimerRef.current) clearTimeout(loadTimerRef.current);

    if (!query || query.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }

    // Check cache — show cached results immediately (no loading flash)
    const cacheKey = `${cacheNs}|${query.toLowerCase()}`;
    const cached = RESULT_CACHE.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      setResults(cached.data as T[]);
      setLoading(false);
      return;
    }

    // Show loading indicator only after 80ms to avoid flicker on fast responses
    loadTimerRef.current = setTimeout(() => setLoading(true), 80);

    timerRef.current = setTimeout(async () => {
      if (abortRef.current) abortRef.current.abort();
      abortRef.current = new AbortController();
      setError(null);

      try {
        const data = await fetcherRef.current(query);
        RESULT_CACHE.set(cacheKey, { data, expiresAt: Date.now() + cacheTtlMs });
        setResults(data);
      } catch (e: unknown) {
        if ((e as { name?: string }).name !== 'AbortError') {
          setError('Could not load suggestions.');
          setResults([]);
        }
      } finally {
        if (loadTimerRef.current) clearTimeout(loadTimerRef.current);
        setLoading(false);
      }
    }, delay);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (loadTimerRef.current) clearTimeout(loadTimerRef.current);
    };
  }, [query, delay, cacheTtlMs, cacheNs]); // eslint-disable-line react-hooks/exhaustive-deps

  const clear = useCallback(() => {
    setQuery('');
    setResults([]);
    setError(null);
    setLoading(false);
    if (abortRef.current) abortRef.current.abort();
  }, []);

  return { query, setQuery, results, loading, error, clear };
}
